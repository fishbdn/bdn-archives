/**
 * 
 */
package com.francetelecom.protosig.model.exception;

import java.io.Serializable;

/**
 * 
 * This is the only exception that should go down to client side. It'll contain a user friendly message to display to
 * the user
 * 
 * @author mlaffargue
 * 
 */
@SuppressWarnings("serial")
public class ClientException extends Exception implements Serializable {
	/**
	 * Needed for GWT Serialization
	 */
	@SuppressWarnings("unused")
	private ClientException() {
	}

	/**
	 * @param message
	 *            the message
	 */
	public ClientException(String message) {
		super(message);
	}
}
