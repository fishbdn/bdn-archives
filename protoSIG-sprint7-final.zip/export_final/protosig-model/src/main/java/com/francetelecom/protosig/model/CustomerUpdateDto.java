package com.francetelecom.protosig.model;

import java.io.Serializable;
import java.util.Date;


public class CustomerUpdateDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7009672886668709855L;
	/**
	 * user name
	 */
	private String codeIdent;
	private String nd;
	private String level;
	private String stair;
	private String building;
	private String number;
	private String street;
	private String inseeCode;
	private String cityName;
	private String comment;
	private Date updateDate;
	
	private String door;
	private String group;
	private String numberComplement;
	private String streetComplement;
	
	public String getDoor() {
		return door;
	}
	public void setDoor(String door) {
		this.door = door;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getNumberComplement() {
		return numberComplement;
	}
	public void setNumberComplement(String numberComplement) {
		this.numberComplement = numberComplement;
	}
	public String getStreetComplement() {
		return streetComplement;
	}
	public void setStreetComplement(String streetComplement) {
		this.streetComplement = streetComplement;
	}
	public String getCodeIdent() {
		return codeIdent;
	}
	public void setCodeIdent(String codeIdent) {
		this.codeIdent = codeIdent;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getStair() {
		return stair;
	}
	public void setStair(String stair) {
		this.stair = stair;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getInseeCode() {
		return inseeCode;
	}
	public void setInseeCode(String inseeCode) {
		this.inseeCode = inseeCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getNd() {
		return nd;
	}
	public void setNd(String nd) {
		this.nd = nd;
	}
	
	
}
