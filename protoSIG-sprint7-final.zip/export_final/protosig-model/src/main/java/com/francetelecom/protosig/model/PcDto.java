package com.francetelecom.protosig.model;

import java.io.Serializable;


public class PcDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8268565175078471482L;

	/**
	 * id with generated value
	 */
	private Long id;

	/**
	 * PC name
	 */
	private String name;
	/**
	 * DR
	 */
	private String dr;
	/**
	 * PC category
	 */
	private String category;
	/**
	 * x coordinate
	 */
	private Double x;
	/**
	 * y coordinate
	 */
	private Double y;
	/**
	 * Postal address
	 */
	private String address;
	/**
	 * comment
	 */
	private String comment;
	
	/**
	 * Number of available pairs
	 */
	private int nbAvailablePairs;
	
	/**
	 * true if there is no available pair
	 */
	private boolean full;

	private String centreCode;
	private String zoneCode;
	private String pairs;
	private String descTech;
	
	// edit pc form
	private String number;
	private String street;
	private String city;
	
	// position before drag and drop
	private Double originalX;
	private Double originalY;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDr() {
		return dr;
	}

	public void setDr(String dr) {
		this.dr = dr;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getX() {
		return x;
	}

	public void setX(Double x) {
		this.x = x;
	}

	public Double getY() {
		return y;
	}

	public void setY(Double y) {
		this.y = y;
	}

	public boolean isFull() {
		return full;
	}

	public void setFull(boolean full) {
		this.full = full;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getNbAvailablePairs() {
		return nbAvailablePairs;
	}

	public void setNbAvailablePairs(int nbAvailablePairs) {
		this.nbAvailablePairs = nbAvailablePairs;
	}

	public String getCentreCode() {
		return centreCode;
	}

	public void setCentreCode(String centreCode) {
		this.centreCode = centreCode;
	}

	public String getZoneCode() {
		return zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}

	public String getPairs() {
		return pairs;
	}

	public void setPairs(String pairs) {
		this.pairs = pairs;
	}

	public String getDescTech() {
		return descTech;
	}

	public void setDescTech(String descTech) {
		this.descTech = descTech;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Double getOriginalX() {
		return originalX;
	}

	public void setOriginalX(Double originalX) {
		this.originalX = originalX;
	}

	public Double getOriginalY() {
		return originalY;
	}

	public void setOriginalY(Double originalY) {
		this.originalY = originalY;
	}


	
}
