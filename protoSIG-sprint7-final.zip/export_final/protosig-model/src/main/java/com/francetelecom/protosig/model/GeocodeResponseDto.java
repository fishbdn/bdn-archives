package com.francetelecom.protosig.model;

import java.io.Serializable;

public class GeocodeResponseDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8177635228772569066L;
	public enum ResponseResult {
		OK,
		CONFIDENCE,
		KO
	};
	
	/**
	 * longitude, in Lambert2 E coordinates 
	 */
	private Double x;
	/**
	 * latitude, in Lambert2 E coordinates
	 */
	private Double y;
	private ResponseResult result;
	
	public Double getX() {
		return x;
	}
	public void setX(Double x) {
		this.x = x;
	}
	public Double getY() {
		return y;
	}
	public void setY(Double y) {
		this.y = y;
	}
	public ResponseResult getResult() {
		return result;
	}
	public void setResult(ResponseResult result) {
		this.result = result;
	}
	
	
}
