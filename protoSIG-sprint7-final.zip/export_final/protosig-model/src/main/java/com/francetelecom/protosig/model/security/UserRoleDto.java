/**
 * 
 */
package com.francetelecom.protosig.model.security;

/**
 * Defines the role of the user
 * 
 * @author mlaffargue
 * 
 */
public enum UserRoleDto {
	USER("utilisateur"), ADMINISTRATOR("administrateur");

	private String key;

	private UserRoleDto(String key) {
		this.key = key;
	}

	@Override
	public String toString() {
		return key;
	}
}
