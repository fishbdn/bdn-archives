/**
 * 
 */
package com.francetelecom.protosig.model;

import java.io.Serializable;

/**
 * @author jcwilk
 * 
 */
public class UserDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3927096041897583599L;
	private String codeIdent;
	private String lastname;
	private String firstname;

	/**
	 * Constructor.
	 */
	public UserDto() {
	}

	public UserDto(String codeIdent, String lastname, String firstname) {
		super();
		this.codeIdent = codeIdent;
		this.lastname = lastname;
		this.firstname = firstname;
	}

	public String getCodeIdent() {
		return codeIdent;
	}

	public void setCodeIdent(String codeIdent) {
		this.codeIdent = codeIdent;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

}
