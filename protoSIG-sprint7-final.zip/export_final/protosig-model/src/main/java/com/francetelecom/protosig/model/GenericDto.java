package com.francetelecom.protosig.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * A class configured by a json file (jsonForms.json). 
 * 
 * Each field is associated with a path to its original value in the local storage.
 * 
 * Some fields can be displayed in InterventionDetailWidget.
 * 
 * Each field stores the value from local storage (old value) and the value from the edit form (new value).
 * 
 *  * @author jcwilk
 *
 */
public class GenericDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5175696333091026841L;
	// common fields
	public static final String FIELD_LEVEL="level";
	public static final String FIELD_BUILDING="building";
	public static final String FIELD_GROUP="group";
	public static final String FIELD_NUMBER="number";
	public static final String FIELD_NUMBER_COMPLEMENT="numberComplement";
	public static final String FIELD_STAIR="stair";
	public static final String FIELD_STREET="street";
	public static final String FIELD_CITY_CODE="cityCode";
	public static final String FIELD_CITY_NAME="cityName";
	public static final String FIELD_COMMENT="comment";

	// PC fields
	public static final String FIELD_PCNAME="pcname";
	public static final String FIELD_CATEG="pccat";
	public static final String FIELD_SPECIAL_DEVICE="specialDevice";
	public static final String FIELD_X="x";
	public static final String FIELD_Y="y";

	// customer fields 
	public static final String FIELD_DOOR="door";
	public static final String FIELD_CLIENT_NAME="clientName";
	public static final String FIELD_ND="nd";
	
	/**
	 * Definition of a generic field
	 * @author jcwilk
	 *
	 */
	public static final class FieldDef implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 503481315887355187L;
		private String code;
		private String path;
		private boolean detail;
		public FieldDef() {}
		public FieldDef(String code, String path, boolean isDetail) {
			this.code=code;
			this.path=path;
			this.detail=isDetail;
		}
		public String getCode() {
			return code;
		}
		public String getPath() {
			return path;
		}
		public boolean isDetail() {
			return detail;
		}
	}
	
	/**
	 * Contains values for a field
	 * @author jcwilk
	 *
	 */
	public static class Field implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = -7623255941858091016L;
		private String oldValue;
		private String newValue;
		private FieldDef definition;
		public Field() {}
		public Field(FieldDef def) {
			definition=def;
		}
		public String getOldValue() {
			return oldValue;
		}
		public void setOldValue(String oldValue) {
			this.oldValue = oldValue;
		}
		public String getNewValue() {
			return newValue;
		}
		public void setNewValue(String newValue) {
			this.newValue = newValue;
		}
		public FieldDef getDefinition() {
			return definition;
		}		
	}
	
	/**
	 * primary key
	 */
	private String id;
	/**
	 * Some additional data (customer : clientName, pc : empty)
	 */
	private String label;
	/**
	 * user id, filled by the GWT servlet
	 */
	private String codeIdent;
	
	/**
	 * Last update date
	 */
	private Date updateDate;
	
	// due to a GWT bug (http://code.google.com/p/google-web-toolkit/issues/detail?id=1054)
	// final fields are not serialized
	/**
	 * List of field definitions for this Dto.
	 * 
	 * Warning : final => not serialized => not available on server side
	 */
	private /* final */ List<FieldDef> fieldDefs=new LinkedList<FieldDef>();
	/**
	 * List of field values for this Dto
	 */
	private /* final */ List<Field> fields=new LinkedList<Field>();
	/**
	 * Map a field code to its value
	 */
	private /* final */ Map<String, Field> fieldMap=new HashMap<String,Field>();
	
	/**
	 * Define a new generic field
	 * @param code field code, used in jsonForms.json
	 * @param path path in local storage 
	 * @param isDetail field is displayed in InterventionDetailWidget
	 */
	public void addField(String code, String path, boolean isDetail) {
		// add field definition
		FieldDef fieldDef=new FieldDef(code,path,isDetail);
		fieldDefs.add(fieldDef);

		// add field
		Field field=new Field(fieldDef);
		fields.add(field);
		fieldMap.put(code, field);
	}
	
	/**
	 * Get the list of fields
	 * @return
	 */
	public final List<Field> getFields() {
		return fields;
	}

	/**
	 * Get a specific field
	 * @param code
	 * @return
	 */
	public Field getField(String code) {
		return fieldMap.get(code);
	}

	/**
	 * Get the list of field definitions
	 * @return
	 */
	public List<FieldDef> getFieldDefs() {
		return fieldDefs;
	}
	
	/**
	 * Get the field 'old' value (value from iTech local storage)
	 * @param fieldCode
	 * @return
	 */
	public String getOldValue(String fieldCode) {
		Field field=getField(fieldCode);
		if ( field == null ) {
			return null;
		}
		return field.getOldValue();
	}

	/**
	 * Get the field new value (from the EditXxxWidget)
	 * @param fieldCode
	 * @return
	 */
	public String getNewValue(String fieldCode) {
		Field field=getField(fieldCode);
		if ( field == null ) {
			return null;
		}
		return field.getNewValue();
	}
	
	/**
	 * Change the new value
	 * @param fieldCode
	 * @param value
	 */
	public void setNewValue(String fieldCode, String value) {
		Field field=getField(fieldCode);
		if ( field == null ) {
			return;
		}
		field.setNewValue(value);
	}

	/**
	 * Change the old value
	 * @param fieldCode
	 * @param value
	 */
	public void setOldValue(String fieldCode, String value) {
		Field field=getField(fieldCode);
		if ( field == null ) {
			addField(fieldCode,null,false);
			field=getField(fieldCode);
		}
		field.setOldValue(value);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCodeIdent() {
		return codeIdent;
	}

	public void setCodeIdent(String codeIdent) {
		this.codeIdent = codeIdent;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	
}
