/**
 * 
 */
package com.francetelecom.protosig.business;

import org.springframework.transaction.annotation.Transactional;

/**
 * @author jcwilk
 * 
 */
public interface RefDataBusiness {
	/**
	 * Converts an insee code into a postal code using the sig_city table
	 * @param inseeCode
	 * @return
	 */
	@Transactional(readOnly = true)
	String getPostalCodeFromInseeCode(String inseeCode);

}
