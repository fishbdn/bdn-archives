/**
 * 
 */
package com.francetelecom.protosig.business.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.bo.po.CustomerUpdatePO;
import com.francetelecom.protosig.business.AbstractProtoSigBusiness;
import com.francetelecom.protosig.business.CustomerBusiness;
import com.francetelecom.protosig.dao.CustomerUpdateDaoJpa;
import com.francetelecom.protosig.model.GenericDto;

/**
 * @author jcwilk
 * 
 */
@Service
public class CustomerBusinessImpl extends AbstractProtoSigBusiness implements
		CustomerBusiness {

	/** Le dozer mapper */
	@Resource
	private DozerBeanMapper dozerMapper;

	@Resource
	private CustomerUpdateDaoJpa customerUpdateDaoJpa;

	/**
	 * @see com.francetelecom.protosig.business.CustomerBusiness#saveUpdate(com.francetelecom.protosig.model.CustomerUpdateDto)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void saveUpdate(GenericDto update) {
		CustomerUpdatePO po = customerUpdateDaoJpa.find(update.getId()); 
		if ( po == null ) {
			po = new CustomerUpdatePO();
			po.setNd(update.getId());
		}
		populatePo(po,update);
		customerUpdateDaoJpa.persist(po);			
	}
	
	/**
	 * Update only the fields that have been modified
	 * @param po persistant object to update
	 * @param update generic bean from edit form
	 */
	private void populatePo(CustomerUpdatePO po, GenericDto update) {
		po.setCodeIdent(update.getCodeIdent());
		po.setClientName(update.getLabel());
		if (mustSaveField(update,GenericDto.FIELD_DOOR)) {
			po.setDoor(update.getNewValue(GenericDto.FIELD_DOOR));
			po.setDoorOld(update.getOldValue(GenericDto.FIELD_DOOR));
		}
		if (mustSaveField(update,GenericDto.FIELD_LEVEL)) {
			po.setLevel(update.getNewValue(GenericDto.FIELD_LEVEL));
			po.setLevelOld(update.getOldValue(GenericDto.FIELD_LEVEL));
		}
		if (mustSaveField(update,GenericDto.FIELD_BUILDING)) {
			po.setBuilding(update.getNewValue(GenericDto.FIELD_BUILDING));
			po.setBuildingOld(update.getOldValue(GenericDto.FIELD_BUILDING));
		}
		if (mustSaveField(update,GenericDto.FIELD_GROUP)) {
			po.setGroup(update.getNewValue(GenericDto.FIELD_GROUP));
			po.setGroupOld(update.getOldValue(GenericDto.FIELD_GROUP));
		}
		if (mustSaveField(update,GenericDto.FIELD_NUMBER)) {
			po.setNumber(update.getNewValue(GenericDto.FIELD_NUMBER));
			po.setNumberOld(update.getOldValue(GenericDto.FIELD_NUMBER));
		}
		if (mustSaveField(update,GenericDto.FIELD_NUMBER_COMPLEMENT)) {
			po.setNumberComplement(update.getNewValue(GenericDto.FIELD_NUMBER_COMPLEMENT));
			po.setNumberComplementOld(update.getOldValue(GenericDto.FIELD_NUMBER_COMPLEMENT));
		}
		if (mustSaveField(update,GenericDto.FIELD_COMMENT)) {
			po.setComment(update.getNewValue(GenericDto.FIELD_COMMENT));
			po.setCommentOld(update.getOldValue(GenericDto.FIELD_COMMENT));
		}
		if (mustSaveField(update,GenericDto.FIELD_STAIR)) {
			po.setStair(update.getNewValue(GenericDto.FIELD_STAIR));
			po.setStairOld(update.getOldValue(GenericDto.FIELD_STAIR));
		}
		if (mustSaveField(update,GenericDto.FIELD_STREET)) {
			po.setStreet(update.getNewValue(GenericDto.FIELD_STREET));
			po.setStreetOld(update.getOldValue(GenericDto.FIELD_STREET));
		}
		if (mustSaveField(update,GenericDto.FIELD_CITY_CODE)) {
			po.setInseeCode(update.getNewValue(GenericDto.FIELD_CITY_CODE));
			po.setInseeCodeOld(update.getOldValue(GenericDto.FIELD_CITY_CODE));
		}
		if (mustSaveField(update,GenericDto.FIELD_CITY_NAME)) {
			po.setCityName(update.getNewValue(GenericDto.FIELD_CITY_NAME));
			po.setCityNameOld(update.getOldValue(GenericDto.FIELD_CITY_NAME));
		}
	}

	/**
	 * Converts a customer persitant object into a genericDto
	 * @param po
	 * @return
	 */
	private GenericDto po2Dto(CustomerUpdatePO po) {
		GenericDto dto=new GenericDto();
		dto.setId(po.getNd());
		dto.setCodeIdent(po.getCodeIdent());
		dto.setUpdateDate(po.getUpdateDate());
		dto.setLabel(po.getClientName());
		// old values
		// setting the old value creates the field if it doesn't exist
		dto.setOldValue(GenericDto.FIELD_BUILDING, po.getBuildingOld());
		dto.setOldValue(GenericDto.FIELD_CITY_CODE, po.getInseeCodeOld());
		dto.setOldValue(GenericDto.FIELD_CITY_NAME, po.getCityNameOld());
		dto.setOldValue(GenericDto.FIELD_COMMENT, po.getCommentOld());
		dto.setOldValue(GenericDto.FIELD_DOOR, po.getDoorOld());
		dto.setOldValue(GenericDto.FIELD_GROUP, po.getGroupOld());
		dto.setOldValue(GenericDto.FIELD_LEVEL, po.getLevelOld());
		dto.setOldValue(GenericDto.FIELD_NUMBER, po.getNumberOld());
		dto.setOldValue(GenericDto.FIELD_NUMBER_COMPLEMENT, po.getNumberComplementOld());
		dto.setOldValue(GenericDto.FIELD_STAIR, po.getStairOld());
		dto.setOldValue(GenericDto.FIELD_STREET, po.getStreetOld());
		// new values
		dto.setNewValue(GenericDto.FIELD_BUILDING, po.getBuilding());
		dto.setNewValue(GenericDto.FIELD_CITY_CODE, po.getInseeCode());
		dto.setNewValue(GenericDto.FIELD_CITY_NAME, po.getCityName());
		dto.setNewValue(GenericDto.FIELD_COMMENT, po.getComment());
		dto.setNewValue(GenericDto.FIELD_DOOR, po.getDoor());
		dto.setNewValue(GenericDto.FIELD_GROUP, po.getGroup());
		dto.setNewValue(GenericDto.FIELD_LEVEL, po.getLevel());
		dto.setNewValue(GenericDto.FIELD_NUMBER, po.getNumber());
		dto.setNewValue(GenericDto.FIELD_NUMBER_COMPLEMENT, po.getNumberComplement());
		dto.setNewValue(GenericDto.FIELD_STAIR, po.getStair());
		dto.setNewValue(GenericDto.FIELD_STREET, po.getStreet());

		return dto;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<GenericDto> getUpdates() {
		List<CustomerUpdatePO> pos=customerUpdateDaoJpa.findAll();
		List<GenericDto> dtos=new ArrayList<GenericDto>(pos.size());
		for (CustomerUpdatePO po:pos) {
			dtos.add(po2Dto(po));
		}
		return dtos;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void clearUpdates() {
		customerUpdateDaoJpa.clear();
	}	
}
