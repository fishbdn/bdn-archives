package com.francetelecom.protosig.business;

import java.io.IOException;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.francetelecom.protosig.model.GenericDto;

/**
 * @author aiBenattahellah
 * 
 */
public abstract class AbstractProtoSigBusiness {

	/**
	 * Traces
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(AbstractProtoSigBusiness.class);

	/**
	 * Récupère le fichier de logs pour la couche business
	 */
	private static ResourceBundle resourceBundle;
	static {
		resourceBundle = null;
		try {
			resourceBundle = new PropertyResourceBundle(
					AbstractProtoSigBusiness.class
							.getResourceAsStream("/BusinessMessages.properties"));
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
	}
	public static ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * Check if a field has been modified
	 * @param update
	 * @param fieldCode
	 * @return
	 */
	protected boolean mustSaveField(GenericDto update, String fieldCode) {
		String oldValue=update.getOldValue(fieldCode);
		if ( oldValue != null && ! oldValue.equals(update.getNewValue(fieldCode))) {
			return true;
		}
		String newValue=update.getNewValue(fieldCode);
		if ( oldValue == null && newValue != null ) {
			return true;
		}
		return false;
	}
}
