/**
 * 
 */
package com.francetelecom.protosig.business.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.bo.po.PcPO;
import com.francetelecom.protosig.bo.po.PcUpdatePO;
import com.francetelecom.protosig.business.AbstractProtoSigBusiness;
import com.francetelecom.protosig.business.PcBusiness;
import com.francetelecom.protosig.dao.PcDaoJpa;
import com.francetelecom.protosig.dao.PcUpdateDaoJpa;
import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.PcDto;

/**
 * @author jcwilk
 * 
 */
@Service
public class PcBusinessImpl extends AbstractProtoSigBusiness implements
		PcBusiness {
	/**
	 * How many PC to send when looking for closest PC
	 */
	private static final int NB_PC_PER_QUERY = 15;

	/** Le dozer mapper */
	@Resource
	private DozerBeanMapper dozerMapper;

	@Resource
	private PcDaoJpa pcDaoJpa;
	@Resource
	private PcUpdateDaoJpa pcUpdateDaoJpa;

	/**
	 * @see com.francetelecom.protosig.business.PcBusiness#getClosest(java.lang.String,
	 *      java.lang.Double, java.lang.Double)
	 */
	@Override
	@Transactional(readOnly = true)
	public List<PcDto> getClosest(String dr, Double x, Double y) {
		// get PO from DAO
		List<PcPO> pos = pcDaoJpa.getClosest(dr, x, y, NB_PC_PER_QUERY);
		// convert PO to DTO
		List<PcDto> dtos = new ArrayList<PcDto>(pos.size());
		for (PcPO po : pos) {
			PcDto dto = dozerMapper.map(po, PcDto.class);
			populatePcDto(po, dto);
			dtos.add(dto);
		}
		return dtos;
	}

	void populatePcDto(PcPO po, PcDto dto) {
		int nbAvailable = getNbAvailablePairs(po.getPairs());
		// determin if pc has available pairs
		dto.setFull(nbAvailable == 0);
		dto.setNbAvailablePairs(nbAvailable);
		// concatenate address
		dto.setAddress((po.getNumber() == null ? "" : po.getNumber() + " ")
				+ (po.getStreet() == null ? "" : po.getStreet() + " ")
				+ (po.getCity() == null ? "" : po.getCity()));
	}

	/**
	 * Determin if a pc is full
	 * 
	 * @param pairList
	 *            ':' separated pair list
	 * @return
	 */
	private int getNbAvailablePairs(String pairList) {
		int ret = 0;
		if (pairList == null || "".equals(pairList)) {
			return ret;
		}
		String[] pairs = pairList.split(":");
		// look for an empty pair
		for (int i = 0; i < pairs.length; i++) {
			String pair = pairs[i];
			// pair format : amorce-number-status-substatus
			String[] pairFields = pair.split("-");
			if (pairFields.length == 4) {
				String pairStatus = pairFields[2];
				String pairSubStatus = pairFields[3];
				if (isPairStatusAvailable(pairStatus, pairSubStatus)) {
					ret++;
				}
			}
		}
		return ret;
	}

	/**
	 * Determin if a pair status represents an available pair
	 * 
	 * @param pairStatus
	 * @return
	 */
	private boolean isPairStatusAvailable(String pairStatus,
			String pairSubStatus) {
		return "D".equals(pairStatus)
				&& ("PU".equals(pairSubStatus) || "CC".equals(pairSubStatus));
	}

	/**
	 * @see com.francetelecom.protosig.business.PcBusiness#saveUpdate(com.francetelecom.protosig.model.PcUpdateDto)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void saveUpdate(GenericDto update) {
		PcUpdatePO po = pcUpdateDaoJpa.find(update.getId());
		if (po == null) {
			po = new PcUpdatePO();
			po.setId(update.getId());
		}
		populatePo(po, update);
		pcUpdateDaoJpa.persist(po);
	}

	/**
	 * Update only the fields that have been modified
	 * 
	 * @param po
	 *            persistant object to update
	 * @param update
	 *            generic bean from edit form
	 */
	private void populatePo(PcUpdatePO po, GenericDto update) {
		po.setCodeIdent(update.getCodeIdent());
		if (mustSaveField(update, GenericDto.FIELD_LEVEL)) {
			po.setLevel(update.getNewValue(GenericDto.FIELD_LEVEL));
			po.setLevelOld(update.getOldValue(GenericDto.FIELD_LEVEL));
		}
		if (mustSaveField(update, GenericDto.FIELD_BUILDING)) {
			po.setBuilding(update.getNewValue(GenericDto.FIELD_BUILDING));
			po.setBuildingOld(update.getOldValue(GenericDto.FIELD_BUILDING));
		}
		if (mustSaveField(update, GenericDto.FIELD_GROUP)) {
			po.setGroup(update.getNewValue(GenericDto.FIELD_GROUP));
			po.setGroupOld(update.getOldValue(GenericDto.FIELD_GROUP));
		}
		if (mustSaveField(update, GenericDto.FIELD_NUMBER)) {
			po.setNumber(update.getNewValue(GenericDto.FIELD_NUMBER));
			po.setNumberOld(update.getOldValue(GenericDto.FIELD_NUMBER));
		}
		if (mustSaveField(update, GenericDto.FIELD_STAIR)) {
			po.setStair(update.getNewValue(GenericDto.FIELD_STAIR));
			po.setStairOld(update.getOldValue(GenericDto.FIELD_STAIR));
		}
		if (mustSaveField(update, GenericDto.FIELD_COMMENT)) {
			po.setComment(update.getNewValue(GenericDto.FIELD_COMMENT));
			po.setCommentOld(update.getOldValue(GenericDto.FIELD_COMMENT));
		}
		if (mustSaveField(update, GenericDto.FIELD_STREET)) {
			po.setStreet(update.getNewValue(GenericDto.FIELD_STREET));
			po.setStreetOld(update.getOldValue(GenericDto.FIELD_STREET));
		}
		if (mustSaveField(update, GenericDto.FIELD_CITY_CODE)) {
			po.setInseeCode(update.getNewValue(GenericDto.FIELD_CITY_CODE));
			po.setInseeCodeOld(update.getOldValue(GenericDto.FIELD_CITY_CODE));
		}
		if (mustSaveField(update, GenericDto.FIELD_CITY_NAME)) {
			po.setCityName(update.getNewValue(GenericDto.FIELD_CITY_NAME));
			po.setCityNameOld(update.getOldValue(GenericDto.FIELD_CITY_NAME));
		}
	}

	/**
	 * @see com.francetelecom.protosig.business.PcBusiness#savePcLocation(java.lang.String,
	 *      java.lang.String, java.lang.Double, java.lang.Double)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void savePcLocation(String id, String codeIdent, Double oldX,
			Double oldY, Double x, Double y) {
		PcUpdatePO po = pcUpdateDaoJpa.find(id);
		if (po == null) {
			po = new PcUpdatePO();
			po.setId(id);
		}
		po.setCodeIdent(codeIdent);
		po.setX(x);
		po.setY(y);
		po.setxOld(oldX);
		po.setyOld(oldY);
		pcUpdateDaoJpa.persist(po);
	}

	/**
	 * Converts a PC persistant object into a genericDto
	 * 
	 * @param po
	 * @return
	 */
	private GenericDto po2Dto(PcUpdatePO po) {
		GenericDto dto = new GenericDto();
		dto.setId(po.getId());
		dto.setCodeIdent(po.getCodeIdent());
		dto.setUpdateDate(po.getUpdateDate());
		// old values
		// setting the old value creates the field if it doesn't exist
		dto.setOldValue(GenericDto.FIELD_BUILDING, po.getBuildingOld());
		dto.setOldValue(GenericDto.FIELD_CITY_CODE, po.getInseeCodeOld());
		dto.setOldValue(GenericDto.FIELD_CITY_NAME, po.getCityNameOld());
		dto.setOldValue(GenericDto.FIELD_COMMENT, po.getCommentOld());
		dto.setOldValue(GenericDto.FIELD_GROUP, po.getGroupOld());
		dto.setOldValue(GenericDto.FIELD_LEVEL, po.getLevelOld());
		dto.setOldValue(GenericDto.FIELD_NUMBER, po.getNumberOld());
		dto.setOldValue(GenericDto.FIELD_STAIR, po.getStairOld());
		dto.setOldValue(GenericDto.FIELD_STREET, po.getStreetOld());
		if (po.getxOld() != null) {
			dto.setOldValue(GenericDto.FIELD_X, String.valueOf(po.getxOld()));
		}
		if (po.getyOld() != null) {
			dto.setOldValue(GenericDto.FIELD_Y, String.valueOf(po.getyOld()));
		}
		// new values
		dto.setNewValue(GenericDto.FIELD_BUILDING, po.getBuilding());
		dto.setNewValue(GenericDto.FIELD_CITY_CODE, po.getInseeCode());
		dto.setNewValue(GenericDto.FIELD_CITY_NAME, po.getCityName());
		dto.setNewValue(GenericDto.FIELD_COMMENT, po.getComment());
		dto.setNewValue(GenericDto.FIELD_GROUP, po.getGroup());
		dto.setNewValue(GenericDto.FIELD_LEVEL, po.getLevel());
		dto.setNewValue(GenericDto.FIELD_NUMBER, po.getNumber());
		dto.setNewValue(GenericDto.FIELD_STAIR, po.getStair());
		dto.setNewValue(GenericDto.FIELD_STREET, po.getStreet());
		if (po.getX() != null) {
			dto.setNewValue(GenericDto.FIELD_X, String.valueOf(po.getX()));
		}
		if (po.getY() != null) {
			dto.setNewValue(GenericDto.FIELD_Y, String.valueOf(po.getY()));
		}

		return dto;
	}

	@Override
	@Transactional(readOnly = true)
	public List<GenericDto> getUpdates() {
		List<PcUpdatePO> pos = pcUpdateDaoJpa.findAll();
		List<GenericDto> dtos = new ArrayList<GenericDto>(pos.size());
		for (PcUpdatePO po : pos) {
			dtos.add(po2Dto(po));
		}
		return dtos;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void clearUpdates() {
		pcUpdateDaoJpa.clear();
	}
}
