/**
 * 
 */
package com.francetelecom.protosig.business;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.model.GenericDto;

/**
 * @author jcwilk
 * 
 */
public interface CustomerBusiness {
	/**
	 * Save a customer update to the database
	 * @param update
	 */
	@Transactional(propagation=Propagation.REQUIRED)
	void saveUpdate(GenericDto update);
	
	/**
	 * Return all updates from the database
	 * @return
	 */
	@Transactional(readOnly = true)
	List<GenericDto> getUpdates();
	/**
	 * Remove all updates from the database
	 */
	@Transactional(propagation=Propagation.REQUIRED)
	void clearUpdates();
}
