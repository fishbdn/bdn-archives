/**
 * 
 */
package com.francetelecom.protosig.business.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.business.AbstractProtoSigBusiness;
import com.francetelecom.protosig.business.RefDataBusiness;
import com.francetelecom.protosig.dao.CityDaoJpa;

/**
 * @author jcwilk
 * 
 */
@Service
public class RefDataBusinessImpl extends AbstractProtoSigBusiness implements
		RefDataBusiness {

	protected static final Logger LOGGER = LoggerFactory.getLogger(RefDataBusinessImpl.class);
	
	@Resource
	private CityDaoJpa cityDaoJpa;

	/**
	 * @see com.francetelecom.protosig.business.RefDataBusiness#getPostalCodeFromInseeCode(java.lang.String)
	 */
	@Override
	@Transactional(readOnly = true)
	public String getPostalCodeFromInseeCode(String inseeCode) {
		String result=cityDaoJpa.getPostalCodeFromInseeCode(inseeCode);
		if ( result == null ) {
			LOGGER.info("Code postal inconnu pour code insee "+inseeCode);
		}
		return result;
	}

}
