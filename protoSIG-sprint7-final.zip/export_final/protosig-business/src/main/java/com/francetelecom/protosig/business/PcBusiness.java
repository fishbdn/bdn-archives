/**
 * 
 */
package com.francetelecom.protosig.business;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.PcDto;

/**
 * @author jcwilk
 * 
 */
public interface PcBusiness {
	/**
	 * Retrieve the closest PC from given coordinates
	 * @param dr search only pc for this dr
	 * @param x,y search pc close to position x,y
	 * @return the list of PC
	 */
	@Transactional(readOnly = true)
	List<PcDto> getClosest(String dr, Double x, Double y);
	
	/**
	 * Save a pc update to the database
	 * @param update
	 */
	@Transactional(propagation=Propagation.REQUIRED)
	void saveUpdate(GenericDto update);
	
	/**
	 * Update the pc location in database
	 * @param id pc id (dr+name)
	 * @param codeIdent user ident
	 * @param xOld,yOld old location
	 * @param x,y new location
	 */
	@Transactional(propagation=Propagation.REQUIRED)
	void savePcLocation(String id, String codeIdent, Double xOld, Double yOld, Double x, Double y);
	
	/**
	 * Return all updates from the database
	 * @return
	 */
	@Transactional(readOnly = true)
	List<GenericDto> getUpdates();
	/**
	 * Remove all updates from the database
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	void clearUpdates();
}
