package com.francetelecom.protosig.ws;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

/**
 * Class for the setting of the password and username for the web service.
 * 
 * @author lFoucher
 * 
 */
public class ClientPasswordCallback implements CallbackHandler {

	// Username et Password initialisés par spring
	private String usernameParam;
	private String passwordParam;

	/**
	 * 
	 * @return usernameParam
	 */
	public String getUsernameParam() {
		return usernameParam;
	}

	/**
	 * 
	 * @param usernameParam
	 */
	public void setUsernameParam(String usernameParam) {
		this.usernameParam = usernameParam;
	}

	/**
	 * 
	 * @return passwordParam
	 */
	public String getPasswordParam() {
		return passwordParam;
	}

	/**
	 * 
	 * @param passwordParam
	 */
	public void setPasswordParam(String passwordParam) {
		this.passwordParam = passwordParam;
	}

	@Override
	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {

		WSPasswordCallback pc = (WSPasswordCallback) callbacks[0];

		// set the password for our message.
		pc.setIdentifier(getUsernameParam());
		pc.setPassword(getPasswordParam());
	}

}
