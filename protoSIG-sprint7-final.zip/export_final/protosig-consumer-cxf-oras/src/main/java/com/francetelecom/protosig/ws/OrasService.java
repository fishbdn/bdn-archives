package com.francetelecom.protosig.ws;

import com.francetelecom.protosig.model.GeocodeResponseDto;

public interface OrasService {
	GeocodeResponseDto geocode(String streetNumber, String streetName, String postalCode, String cityName);
}
