package com.francetelecom.protosig.ws.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.xml.ws.Holder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.francetelecom.protosig.model.GeocodeResponseDto;
import com.francetelecom.protosig.model.GeocodeResponseDto.ResponseResult;
import com.francetelecom.protosig.ws.OrasService;
import com.orange.interfaces.managelocationcustomerdatamanagement.CheckCriteriaAddressViewForCheckAddressRequest;
import com.orange.interfaces.managelocationcustomerdatamanagement.CityREQChA;
import com.orange.interfaces.managelocationcustomerdatamanagement.GeographicCoordinatesRESChA;
import com.orange.interfaces.managelocationcustomerdatamanagement.PostalAddressViewForCheckAddressRequest;
import com.orange.interfaces.managelocationcustomerdatamanagement.PostalAddressViewForCheckAddressResponse;
import com.orange.interfaces.managelocationcustomerdatamanagement.StreetREQChA;
import com.orange.interfaces.managelocationcustomerdatamanagement.v2.ManageLocationCustomerDataManagement;

@Service("orasService")
public class OrasServiceImpl implements OrasService {

	private static final String LAMBERT_SYSTEM = "Lambert2 E";
	private static final String ADDRESS_ORIGIN = "service";
	private static final String NUMBER_IN_STREET_ACCURACY_CODE = "2";
	private static final String DEFAULT_CHECK_TYPE="CORRECTING ADDRESS";
	private static final String DEFAULT_TYPOGRAPHY="RICH CASE LETTER";

	@Resource
	ManageLocationCustomerDataManagement orasWs;

	protected static final Logger LOGGER = LoggerFactory
			.getLogger(OrasServiceImpl.class);

	@Override
	public GeocodeResponseDto geocode(String streetNumber, String streetName,
			String postalCode, String cityName) {
		GeocodeResponseDto result = new GeocodeResponseDto();
		result.setResult(ResponseResult.KO);
		PostalAddressViewForCheckAddressRequest request = new PostalAddressViewForCheckAddressRequest();
		// set mandatory criteria
		CheckCriteriaAddressViewForCheckAddressRequest requestCriteria = new CheckCriteriaAddressViewForCheckAddressRequest();
		requestCriteria.setCheckType(DEFAULT_CHECK_TYPE);
		requestCriteria.setTypography(DEFAULT_TYPOGRAPHY);
		requestCriteria.setReturnGeographicCoordinates(true);
		requestCriteria.setFormattedPostalAddressView(false);
		requestCriteria.setLOCALInteractive(false);
		requestCriteria.setLOCALReturnCedex(false);
		Holder<List<PostalAddressViewForCheckAddressResponse>> response = new Holder<List<PostalAddressViewForCheckAddressResponse>>();
		// populate request
		request.setPostalCode(postalCode);
		CityREQChA city = new CityREQChA();
		city.setCityName(cityName);
		request.setCity(city);
		StreetREQChA street = new StreetREQChA();
		street.setStreetName(streetName);
		street.setStreetNumber(streetNumber);
		request.setStreet(street);
		try {
			// call web service
			orasWs.checkAddress(request, requestCriteria, response);
			// build response
			List<PostalAddressViewForCheckAddressResponse> addressList = response.value;
			if (addressList != null && addressList.size() > 0) {
				List<GeographicCoordinatesRESChA> coords = addressList.get(0)
						.getGeographicCoordinates();
				// look for WGS 84 coordinates for the address
				for (GeographicCoordinatesRESChA geo : coords) {
					if (ADDRESS_ORIGIN.equals(geo.getOrigin())
							&& LAMBERT_SYSTEM.equals(geo.getGeocodingSystems())) {
						String accuracy = geo.getAccuracy();
						result.setX(Double.parseDouble(geo.getGeocodeX()));
						result.setY(Double.parseDouble(geo.getGeocodeY()));
						if (NUMBER_IN_STREET_ACCURACY_CODE.equals(accuracy)) {
							result.setResult(ResponseResult.OK);
							// stop loop on first accurate result
							break;
						} else {
							// low confidence on position
							result.setResult(ResponseResult.CONFIDENCE);
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Erreur appel web service ORAS", e);
		}
		return result;
	}

}
