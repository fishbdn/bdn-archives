package com.francetelecom.protosig.listener;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Set;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomContextListener implements ServletContextListener {
	@Override
	public void contextInitialized(ServletContextEvent event) {
		Logger logger = LoggerFactory.getLogger(getClass());
		logger.debug("Context initialized : "
				+ event.getServletContext().getContextPath());
	}

	@SuppressWarnings("deprecation")
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		Logger logger = LoggerFactory.getLogger(getClass());
		// This manually deregisters JDBC driver, which prevents Tomcat from
		// complaining about memory leaks
		Enumeration<Driver> drivers = DriverManager.getDrivers();
		while (drivers.hasMoreElements()) {
			Driver driver = drivers.nextElement();
			try {
				DriverManager.deregisterDriver(driver);
				logger.debug(String.format("deregistering jdbc driver: %s",
						driver));
			} catch (SQLException e) {
				logger.error(
						String.format("Error deregistering driver %s", driver),
						e);
			}
		}

		Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
		Thread[] threadArray = threadSet.toArray(new Thread[threadSet.size()]);
		for (Thread t : threadArray) {
			if (t.getName().contains("Abandoned connection cleanup thread")) {
				logger.warn("Forcibly stopping thread to avoid memory leak: "
						+ t.getName());
				synchronized (t) {
					// Force the Thread to stop
					t.stop(); 
				}
			}
		}
		// Wait for Threads to stop
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			logger.debug(e.getMessage(), e);
		}
	}
}
