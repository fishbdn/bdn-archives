package com.francetelecom.protosig.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.francetelecom.protosig.model.UserDto;
import com.francetelecom.protosig.presentation.server.SessionAttribute;

public class CustomSessionListener implements HttpSessionListener {
	private static Logger logger = LoggerFactory
			.getLogger(CustomSessionListener.class);

	@Override
	public void sessionCreated(HttpSessionEvent event) {
		UserDto user = (UserDto) event.getSession().getAttribute(
				SessionAttribute.USER);
		if (user != null) {
			logger.info("Session created for : " + user.getCodeIdent());
		} else {
			logger.error("User not in session");
		}
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		UserDto user = (UserDto) event.getSession().getAttribute(
				SessionAttribute.USER);
		if (user != null) {
			logger.info("Session destroyed for : " + user.getCodeIdent());
		} else {
			logger.error("User not in session");
		}
	}
}
