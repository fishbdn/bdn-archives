/**
 * 
 */
package com.francetelecom.protosig.filter;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.francetelecom.clara.security.MissingUserPropertyException;
import com.francetelecom.protosig.model.UserDto;
import com.francetelecom.protosig.model.security.UserRoleDto;
import com.francetelecom.protosig.presentation.server.SessionAttribute;

/**
 * @author mlaffargue
 * 
 */
public class SessionFilter implements Filter {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SessionFilter.class);

	/**
	 * Redirection en cas d'erreur GASSI
	 */
	private static final String ERROR_PAGE = "/gassi/pages/error.jsp";

	private static final String PROP_FIRSTNAME = "ftusergivenname";
	private static final String PROP_LASTNAME = "ftusersn";

	/**
	 * Le context de servlet
	 */
	private ServletContext context;

	@Override
	public void destroy() {

	}

	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpSession session = httpRequest.getSession();
		UserDto userBean = (UserDto) session
				.getAttribute(SessionAttribute.USER);

		com.francetelecom.clara.security.User userGassi = null;
		LOGGER.debug("doFilter()");
		if (userBean == null) {
			// Initialize session
			try {
				LOGGER.debug("Get User from GASSI");
				// Call GASSI
				userGassi = com.francetelecom.clara.security.SecurityManager
						.getContextInstance(this.context).getUser(httpRequest);

				// Get user from DB
				if (userGassi != null) {
					LOGGER.debug("GASSI User : " + userGassi.getId());
					String rolesString = "";

					ArrayList<UserRoleDto> roles = new ArrayList<UserRoleDto>();
					for (Object role : userGassi.getRoles()) {
						rolesString += role + "/";
						// Check the roles
						if (UserRoleDto.USER.toString().equals("" + role)) {
							roles.add(UserRoleDto.USER);
						} else if (UserRoleDto.ADMINISTRATOR.toString().equals(
								"" + role)) {
							roles.add(UserRoleDto.ADMINISTRATOR);
						}
					}
					if (roles.isEmpty()) { 
						// The user hasn't the good roles
						userBean = null;
						session.setAttribute(SessionAttribute.ROLES, null);
						LOGGER.error("The user "
								+ userGassi.getId()
								+ "doesn't have the required role. Found roles : "
								+ rolesString + UserRoleDto.USER.toString());
						error(request, response);
					} else {
						session.setAttribute(SessionAttribute.ROLES, roles);

						userBean = new UserDto(userGassi.getId(),
								userGassi.getProperty(PROP_LASTNAME),
								userGassi.getProperty(PROP_FIRSTNAME));
						session.setAttribute(SessionAttribute.USER, userBean);
					}
				} else {
					LOGGER.debug("User not found in GASSI");
					error(request, response);
				}
			} catch (MissingUserPropertyException e) {
				LOGGER.debug("Missing property trying to retrieve GASSI user : "
						+ e);
				error(request, response);
			}
		}

		filterChain.doFilter(request, response);
	}

	/**
	 * An error occured
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             the io exception
	 */
	private void error(ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher(ERROR_PAGE).forward(request, response);
	}

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		context = filterConfig.getServletContext();

		WebApplicationContext webApplicationContext = WebApplicationContextUtils
				.getWebApplicationContext(context);
		AutowireCapableBeanFactory autowireCapableBeanFactory = webApplicationContext
				.getAutowireCapableBeanFactory();
		autowireCapableBeanFactory.autowireBean(this);
	}
}
