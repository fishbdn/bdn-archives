package com.francetelecom.protosig.presentation.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DecoratedPopupPanel;
import com.google.gwt.user.client.ui.Widget;

public class ChoosePositionMethodWidget extends DecoratedPopupPanel {

	private static ChoosePositionMethodWidgetUiBinder uiBinder = GWT
			.create(ChoosePositionMethodWidgetUiBinder.class);

	interface ChoosePositionMethodWidgetUiBinder extends
			UiBinder<Widget, ChoosePositionMethodWidget> {
	}
	
	// CHECKSTYLE:OFF
	@UiField
	protected Button gpsButton;
	@UiField
	protected Button handButton;
	// CHECKSTYLE:ON	

	public ChoosePositionMethodWidget(ClickHandler gpsHandler,ClickHandler handHandler) {
		setWidget(uiBinder.createAndBindUi(this));
		
		gpsButton.addClickHandler(gpsHandler);
		handButton.addClickHandler(handHandler);
	}

}
