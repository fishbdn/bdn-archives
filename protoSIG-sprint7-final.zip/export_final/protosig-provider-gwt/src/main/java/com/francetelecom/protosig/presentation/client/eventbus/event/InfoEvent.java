package com.francetelecom.protosig.presentation.client.eventbus.event;

/**
 * Displays a temporary information message
 * @author jcwilk
 *
 */
public class InfoEvent extends MessageEvent {
	public InfoEvent(String message) {
		super(Severity.INFO,message);
	}
}
