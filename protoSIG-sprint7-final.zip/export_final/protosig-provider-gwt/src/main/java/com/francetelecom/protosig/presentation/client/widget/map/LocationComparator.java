package com.francetelecom.protosig.presentation.client.widget.map;

import java.io.Serializable;
import java.util.Comparator;

import com.francetelecom.protosig.presentation.client.widget.map.model.Location;

/**
 * Location comparator (on longitude)
 * 
 * @author JLZB1407
 * 
 */
public class LocationComparator implements Comparator<Location>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4915969015134755770L;

	@Override
	public int compare(Location o1, Location o2) {
		if (hasSameY(o1,o2)) {
			return 0;
		} else if ((hasYCoord(o1) && hasYCoord(o2) && o1.getY() > o2.getY())
				|| !hasYCoord(o2)) {
			return -1;
		} else {
			return 1;
		}
	}

	private static boolean hasSameY(Location o1, Location o2) {
		if (hasYCoord(o1) && hasYCoord(o2) && o1.getY() == o2.getY()) {
			return true;
		}
		if (!hasYCoord(o1) && !hasYCoord(o2)) {
			return true;
		}
		return false;
	}
	
	private static boolean hasYCoord(Location location) {
		return (location != null && location.getY() != 0);
	}
}
