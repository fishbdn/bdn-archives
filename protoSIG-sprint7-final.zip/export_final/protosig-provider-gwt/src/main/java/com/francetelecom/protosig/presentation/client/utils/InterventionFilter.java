package com.francetelecom.protosig.presentation.client.utils;

import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IIntervention;

/**
 * Selects interventions for the SIG prototype
 * @author jcwilk
 *
 */
public final class InterventionFilter {
	/**
	 * hidden constructor
	 */
	private InterventionFilter() {}
	
	private static final String INTERVENTION_TYPE_FTTH="FTTH";
	private static final String INTERVENTION_TYPE_GROUP="G";
	private static final String INTERVENTION_TYPE_GROUPED="IG";
	/**
	 * Return true if the intervention should be active in the SIG prototype
	 * @param inter
	 * @return
	 */
	public static boolean isInterventionOk(IIntervention inter) {
		// don't activate interventions without working order
		if ( inter.getMissingWo() ) {
			return false;
		}
		// don't activate FTTH intervention
		if ( INTERVENTION_TYPE_FTTH.equals(inter.getInterventionType()) ) {
			return false;
		}
		// don't activate group interventions
		if ( INTERVENTION_TYPE_GROUP.equals(inter.getInterventionType()) ) {
			return false;
		}
		if ( INTERVENTION_TYPE_GROUPED.equals(inter.getInterventionType()) ) {
			return false;
		}
		return true;
	}
}
