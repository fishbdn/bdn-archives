package com.francetelecom.protosig.presentation.client.eventbus.event;


/**
 * Displays a temporary message 
 * @author jcwilk
 *
 */
public class MessageEvent extends GenericEvent<String> {
	protected enum Severity {
		INFO(GenericEvent.Type.INFO),WARN(GenericEvent.Type.WARN),ERROR(GenericEvent.Type.ERROR);
		private GenericEvent.Type eventType;
		private Severity(GenericEvent.Type eventType) {
			this.eventType=eventType;
		}
		public GenericEvent.Type getEventType() {
			return eventType;
		}		
	};
	/**
	 * @param type Event.Type.INFO/WARN/ERROR
	 * @param message
	 */
	public MessageEvent(Severity severity,String message) {
		super(severity.getEventType(),message);
	}

}
