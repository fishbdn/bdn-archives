package com.francetelecom.protosig.presentation.client.eventbus.event;



/**
 * Event triggered when the geocoding result for an intervention is known
 * @author jcwilk
 *
 */
public class InterventionGeocodingEvent extends GenericEvent<Integer> {
	public enum Level {
		// intervention geocoding success
		OK,
		// intervention geocoding confidence is low
		LOW_CONFIDENCE,
		// intervention geocoding didn't answer
		NO_ANSWER
	};
	
	private final Level level;
	public InterventionGeocodingEvent(Integer interventionIndex, Level level) {
		super(GenericEvent.Type.INTER_GEO, interventionIndex);
		this.level=level;
	}
	public Level getLevel() {
		return level;
	}
	
}
