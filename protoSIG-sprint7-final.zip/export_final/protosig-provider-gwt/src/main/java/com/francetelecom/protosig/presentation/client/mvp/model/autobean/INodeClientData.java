package com.francetelecom.protosig.presentation.client.mvp.model.autobean;

import java.util.Map;

/**
 * Noeud pouvant etre stocké en local sur le navigateur du client
 * 
 * @author xdkp2718
 * 
 */
public interface INodeClientData {

	/**
	 * Retourner la map des données (feuilles).
	 * 
	 * @return Map<String, String>
	 * 
	 * @since Apr 15, 2011
	 * 
	 */
	Map<String, String> getData();

	/**
	 * Positionner la map des données (feuilles).
	 * 
	 * @param data
	 *            Map<String, String>
	 * 
	 * @since Apr 15, 2011
	 * 
	 */
	void setData(Map<String, String> data);

	/**
	 * Retourner la map des noeuds fils.
	 * 
	 * @return Map<String, IWorkOrderBlockNodeStorable>
	 * 
	 * @since Apr 15, 2011
	 * 
	 */
	Map<String, INodeClientData> getChildBlock();

	/**
	 * Positionner la map des noeuds fils.
	 * 
	 * @param childBlock
	 *            Map<String, IWorkOrderBlockNodeStorable>
	 * 
	 * @since Apr 15, 2011
	 * 
	 */
	void setChildBlock(Map<String, INodeClientData> childBlock);

}