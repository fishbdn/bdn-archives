/**************************************************************************************************************************************************
 * Copyright (c) 2007 Francetelecom R&D.  All rights reserved.
 * =================================================================
 * Redistribution and use in source or binary forms, with or without
 * modifications, are under the permission of Francetelecom R&D.
 *=====================================================================
 * Contact: gil.lebrun@orange-ftgroup.com
 * Author : Jean-Marie Devos  
 ****************************************************************************************************************************************************/

package com.francetelecom.protosig.presentation.client.widget.map;

/**
 * 
 * @author Phiz
 * 
 *         http://www.forumsig.org/showthread.php?t=7418
 */
public final class GeoTranslator {
	/**
	 * Prevent someone to instanciate this class
	 */
	private GeoTranslator() {
	}

	/**
	 * 
	 * @param px
	 * @param py
	 * @return array [longitude, latitude]
	 */
	public static double[] convertLambert2eToWGS84(double px, double py) {
		/*
		 * Quelques constantes ...
		 */

		final double n = 0.7289686274;
		final double c = 11745793.39; // En mètres
		final double xS = 600000; // En mètres
		final double yS = 8199695.768; // En mètres
		// double l0 = 0.04079234433198; //correspond � la longitude en radian
		// de Paris (2�20'14.025" E) par rapport � Greenwich
		final double l0 = 0.0; // correspond � la longitude en radian de Paris
		// (2�20'14.025" E) par rapport � Greenwich
		double e = 0.08248325676; // e du NTF (on le change après pour passer en
		// WGS)
		final double eps = Math.pow(10, -10); // précision

		/***********************************************************
		 * coordonnées dans la projection de Lambert 2 à convertir *
		 ************************************************************/
		final double x = px;
		final double y = py;

		/*
		 * Conversion Lambert 2 -> NTF géographique : ALG0004
		 */

		double l;
		double len;
		double phi;
		double phi0;
		double phii;
		double phiprec;
		double radius;
		double g;

		// Pour test : jeu de test d'ign. Cf. Algo 0004
		/*
		 * if(TEST) { X = 1029705.083; Y = 272723.849; n = 0.760405966; l0 =
		 * 0.04079234433198; c = 11603796.9767; Ys = 5657616.674; }
		 */// fin test

		radius = Math.sqrt(((x - xS) * (x - xS)) + ((y - yS) * (y - yS)));
		g = Math.atan((x - xS) / (yS - y));

		l = l0 + (g / n);
		len = -(1 / n) * Math.log(Math.abs(radius / c));

		phi0 = 2 * Math.atan(Math.exp(len)) - (Math.PI / 2.0);
		phiprec = phi0;
		phii = 2
				* Math.atan((Math.pow(((1 + e * Math.sin(phiprec)) / (1 - e
						* Math.sin(phiprec))), e / 2.0) * Math.exp(len)))
				- (Math.PI / 2.0);

		while (!(Math.abs(phii - phiprec) < eps)) {
			phiprec = phii;
			phii = 2
					* Math.atan((Math.pow(((1 + e * Math.sin(phiprec)) / (1 - e
							* Math.sin(phiprec))), e / 2.0) * Math.exp(len)))
					- (Math.PI / 2.0);
		}

		phi = phii;

		/*
		 * Conversion NTF géographique -> NTF cartésien : ALG0009
		 */

		double norm;
		double xCart;
		double yCart;
		double aCart;

		double a = 6378249.2;
		double h = 100; // En mètres

		double xWGS84;
		double yWGS84;
		double zWGS84;

		norm = a
				/ (Math.pow((1 - (e * e) * (Math.sin(phi) * Math.sin(phi))),
						0.5));
		xCart = (norm + h) * Math.cos(phi) * Math.cos(l);
		yCart = (norm + h) * Math.cos(phi) * Math.sin(l);
		aCart = ((norm * (1 - (e * e))) + h) * Math.sin(phi);

		/*
		 * Conversion NTF cartésien -> WGS84 cartésien : ALG0013
		 */

		// Il s'agit d'une simple translation
		xWGS84 = xCart - 168;
		yWGS84 = yCart - 60;
		zWGS84 = aCart + 320;

		/*
		 * Conversion WGS84 cartésien -> WGS84 géographique : ALG0012
		 */

		double p;
		double phi840;
		double phi84prec;
		double phi84i;
		double phi84;
		final double l840 = 0.04079234433; // 0.04079234433 pour passer dans un
		// référentiel par rapport au
		// méridien
		// de Greenwich, sinon mettre 0
		double l84;
		e = 0.08181919106; // On change e pour le mettre dans le système WGS84
		// au lieu de NTF
		a = 6378137.0;

		// Pour test : jeu de tests d'IGN. Cf. Algo 0012
		/*
		 * if(TEST) { XWGS84 = 6376064.695; YWGS84 = 111294.623; ZWGS84 =
		 * 128984.725; l840 = 0; e = 0.08248325679; }
		 */// Fin tests

		p = Math.sqrt((xWGS84 * xWGS84) + (yWGS84 * yWGS84));

		l84 = l840 + Math.atan(yWGS84 / xWGS84);

		phi840 = Math.atan(zWGS84
				/ (p * (1 - ((a * e * e))
						/ Math.sqrt((xWGS84 * xWGS84) + (yWGS84 * yWGS84)
								+ (zWGS84 * zWGS84)))));

		phi84prec = phi840;

		// phi84i = Math.atan((ZWGS84 / P) * Math.pow(1 - ((a * e * e *
		// Math.cos(phi84prec))
		// / (P * Math.sqrt(1 - e * e *
		// (Math.sin(phi84prec)*Math.sin(phi84prec))))), -1));
		phi84i = Math
				.atan((zWGS84 / p)
						/ (1 - ((a * e * e * Math.cos(phi84prec)) / (p * Math
								.sqrt(1
										- e
										* e
										* (Math.sin(phi84prec) * Math
												.sin(phi84prec)))))));

		while (!(Math.abs(phi84i - phi84prec) < eps)) {
			phi84prec = phi84i;
			// phi84i = Math.atan((ZWGS84 / P) * Math.pow(1 - ((a * e * e *
			// Math.cos(phi84prec))
			// / (P * Math.sqrt(1 - ((e*e) *
			// (Math.sin(phi84prec)*Math.sin(phi84prec)))))), -1));
			phi84i = Math.atan((zWGS84 / p)
					/ (1 - ((a * e * e * Math.cos(phi84prec)) / (p * Math
							.sqrt(1 - ((e * e) * (Math.sin(phi84prec) * Math
									.sin(phi84prec))))))));

		}

		phi84 = phi84i;

		// return new double[]{phi84, l84};
		return new double[] { l84 / DEG2RAD, phi84 / DEG2RAD };
	}

	private static final double DEG2RAD = Math.PI / 180.0;

	/**
	 * Convert WGS84 coords to Lambert2e
	 * @param lambda_w
	 * @param phi_w
	 * @return [longitude, latitude]
	 */
	public final static double[] convertWGS84ToLambert2e(double lambda_w, double phi_w) {
		lambda_w = lambda_w * DEG2RAD;
		phi_w = phi_w * DEG2RAD;

		/**************************************************************************************************************/
		/**
		 * 1) coordonnées géographiques WGS84 (phi_w,lambda_w) -> coordonnées
		 * cartésiennes WGS84 (X_w,Y_w,Z_w)
		 **/
		/**************************************************************************************************************/

		// J'ai utilisé 2 formules données par l'IGN dans un de leur document
		// ainsi que deux constantes de
		// l'ellipsoide de référence du système WGS84 (les deux demi-axes) :

		double a_w = 6378137.0;
		double b_w = 6356752.314;

		// d'où
		double e2_w = (a_w * a_w - b_w * b_w) / (a_w * a_w);

		// et on a la grande normale de l'ellipsoide WGS84
		double N = a_w / Math.sqrt(1 - e2_w * Math.pow(Math.sin(phi_w), 2));

		// ainsi on obtient
		double X_w = N * Math.cos(phi_w) * Math.cos(lambda_w);
		double Y_w = N * Math.cos(phi_w) * Math.sin(lambda_w);
		double Z_w = N * (1 - e2_w) * Math.sin(phi_w);

		/**************************************************************************************************************/
		/**
		 * 2) coordonnées cartésiennes WGS84 (X_w,Y_w,Z_w) -> coordonnées
		 * cartésiennes NTF (X_n,Y_n,Z_n)
		 **/
		/**************************************************************************************************************/

		// Là il n'y a qu'un translation à effectuer :

		// on a donc
		double dX = 168.0;
		double dY = 60.0;
		double dZ = -320.0;

		// et...
		double X_n = X_w + dX;
		double Y_n = Y_w + dY;
		double Z_n = Z_w + dZ;

		/**************************************************************************************************************/
		/**
		 * 3) coordonnées cartésiennes NTF (X_n,Y_n,Z_n) -> coordonnées
		 * géographiques NTF (phi_n,lambda_n)
		 **/
		/**************************************************************************************************************/

		// J'ai utilisé 1 formule donnée par l'IGN toujours dans le même
		// document ainsi que deux constantes de l'ellipsoide
		// de référence du système NTF, Clarke 1880 :

		double a_n = 6378249.2;
		double b_n = 6356515.0;

		// d'où
		double e2_n = (a_n * a_n - b_n * b_n) / (a_n * a_n);

		// on définit une tolérance de convergence
		double epsilon = Math.pow(10, -10);

		// puis on amorce une boucle de calcul
		double p0 = Math.atan(Z_n
				/ Math.sqrt(X_n * X_n + Y_n * Y_n)
				* (1 - (a_n * e2_n)
						/ (Math.sqrt(X_n * X_n + Y_n * Y_n + Z_n * Z_n))));
		double p1 = Math.atan((Z_n / Math.sqrt(X_n * X_n + Y_n * Y_n))
				/ (1 - (a_n * e2_n * Math.cos(p0))
						/ (Math.sqrt((X_n * X_n + Y_n * Y_n)
								* (1 - e2_n * Math.pow(Math.sin(p0), 2))))));

		while (!(Math.abs(p1 - p0) < epsilon)) {

			p0 = p1;
			p1 = Math
					.atan((Z_n / Math.sqrt(X_n * X_n + Y_n * Y_n))
							/ (1 - (a_n * e2_n * Math.cos(p0))
									/ (Math.sqrt((X_n * X_n + Y_n * Y_n)
											* (1 - e2_n
													* Math.pow(Math.sin(p0), 2))))));

		}

		double phi_n = p1;
		double lambda_n = Math.atan(Y_n / X_n);

		/**********************************************************************************************************************/
		/**
		 * 4) coordonnées géographiques NTF (phi_n,lambda_n) coordonnées
		 * projetées en Lambert II étendu (X_l2e, Y_l2e)
		 **/
		/**********************************************************************************************************************/

		// J'utilise les formules de projection et les constantes fournies par
		// l'IGN dans un autre document :

		// avant tout on définit quelques constantes
		double n = 0.7289686274;
		double c = 11745793.39;
		double Xs = 600000.0;
		double Ys = 8199695.768;

		double e_n = Math.sqrt(e2_n);
		double lambda0 = 0.04079234433198; // correspond à la longitude en
											// radian de Paris (2°20'14.025" E)
											// par rapport à Greenwich
		// puis on calcule la latitude isométrique
		double L = Math.log(Math.tan(Math.PI / 4 + phi_n / 2)
				* Math.pow(
						((1 - e_n * Math.sin(phi_n)) / (1 + e_n
								* Math.sin(phi_n))), (e_n / 2)));

		// enfin on projette

		double X_l2e = Xs + c * Math.exp((-n * L))
				* Math.sin(n * (lambda_n - lambda0));
		double Y_l2e = Ys - c * Math.exp((-n * L))
				* Math.cos(n * (lambda_n - lambda0));

		double[] tabXY = new double[2];

		tabXY[0] = X_l2e;
		tabXY[1] = Y_l2e;

		return tabXY;
	}
}