package com.francetelecom.protosig.presentation.client.mvp.model.autobean;

import java.util.List;

public interface IIntervention {

	/**
	 * 
	 * @return le noeud intervention dont les valeurs ont été affectées aux
	 *         attributs de cet objet
	 */
	INodeClientData getNode();

	/**
	 * 
	 * @param pIntervention
	 *            le noeud intervention dont les valeurs ont été affectées aux
	 *            attributs de cet objet
	 */
	void setNode(INodeClientData pIntervention);
	
	/**
	 * 
	 * @return code base permettant l'identication de l'intervention
	 */
	String getCodeBase();

	/**
	 * 
	 * @param codeBase
	 *            code base permettant l'identication de l'intervention
	 */
	void setCodeBase(String codeBase);

	/**
	 * 
	 * @return l'identifiant de l'intervention mère si cette intervention est
	 *         une fille, null sinon
	 */
	String getMotherId();

	/**
	 * 
	 * @param id
	 *            identifiant de l'intervention mère
	 */
	void setMotherId(String id);

	/**
	 * @return identifiant de l'intervention
	 */
	String getId();

	/**
	 * @param id
	 *            identifiant de l'intervention
	 */
	void setId(String id);

	/**
	 * @return référence ethec
	 */
	String getEtechReference();

	/**
	 * @param etechReference
	 *            référence ethec
	 */
	void setEtechReference(String etechReference);

	/**
	 * @return le commentaire d'affectation
	 */
	String getAssignmentComment();

	/**
	 * @param assignmentComment
	 *            le commentaire d'affectation
	 */
	void setAssignmentComment(String assignmentComment);

	/**
	 * @return the activity
	 */
	String getActivity();

	/**
	 * @param activity
	 *            the activity to set
	 */
	void setActivity(String activity);

	/**
	 * @return the product
	 */
	String getProduct();

	/**
	 * @param product
	 *            the product to set
	 */
	void setProduct(String product);

	/**
	 * @return the centerZone
	 */
	String getCenter();

	/**
	 * @param pCenter
	 *            the centerZone to set
	 */
	void setCenter(String pCenter);

	/**
	 * @return the centerZone
	 */
	String getZone();

	/**
	 * @param pZone
	 *            the centerZone to set
	 */
	void setZone(String pZone);

	/**
	 * @return the nroName
	 */
	String getNroName();

	/**
	 * @param nroName
	 *            the nroName to set
	 */
	void setNroName(String nroName);

	/**
	 * @return the clientName
	 */
	String getClientName();

	/**
	 * @param clientName
	 *            the clientName to set
	 */
	void setClientName(String clientName);

	/**
	 * @return the dateMeeting
	 */
	Long getDateMeeting();

	/**
	 * @param dateMeeting
	 *            the dateMeeting to set
	 */
	void setDateMeeting(Long dateMeeting);

	/**
	 * @return the interventionState
	 */
	String getInterventionState();

	/**
	 * @param interventionState
	 *            the interventionState to set
	 */
	void setInterventionState(String interventionState);

	/**
	 * @return the timeStart
	 */
	Long getTimeStart();

	/**
	 * @param timeStart
	 *            the timeStart to set
	 */
	void setTimeStart(Long timeStart);

	/**
	 * @return the timeStop
	 */
	Long getTimeStop();

	/**
	 * @param timeStop
	 *            the timeStop to set
	 */
	void setTimeStop(Long timeStop);

	/**
	 * @return Le type de l'OT.
	 * 
	 */
	String getND();

	/**
	 * @param pNd
	 *            Le type de l'OT à affecter.
	 */
	void setND(String pNd);

	/**
	 * @return the daughterClosed
	 */
	boolean getDaughterClosed();

	/**
	 * @param daughterClosed
	 *            the daughterClosed to set
	 */
	void setDaughterClosed(boolean daughterClosed);

	boolean getMissingWo();

	/**
	 * 
	 * @param absOt
	 * 
	 * @since May 19, 2011
	 * 
	 */
	void setMissingWo(boolean absOt);

	/**
	 * @return the interventionType
	 */
	String getInterventionType();

	/**
	 * @param interventionType
	 *            the interventionType to set
	 */
	void setInterventionType(String interventionType);

	/**
	 * @return the closable
	 */
	boolean getClosable();

	/**
	 * @param closable
	 *            the closable to set
	 */
	void setClosable(boolean closable);

	/**
	 * 
	 * @return la liste des interventions d'une intervention mère, null sinon
	 */
	List<IIntervention> getChildTechnicalInterventionList();

	/**
	 * 
	 * @param list
	 *            liste des interventions d'une intervention mère, null sinon
	 */
	void setChildTechnicalInterventionList(List<IIntervention> list);

	void setMargin(String margin);

	String getMargin();

	void setReInterventionType(String pReType);

	String getReInterventionType();

	void setReInterventionRank(String pReRank);

	String getReInterventionRank();

	Long getContractDate();

	void setContractDate(Long time);

	Boolean getIsMother();

	void setIsMother(Boolean value);
}