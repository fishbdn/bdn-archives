package com.francetelecom.protosig.presentation.client.eventbus.event;

/**
 * Event triggered to display the detail of an intervention on the map
 * @author jcwilk
 *
 */
public class DetailInterventionEvent extends GenericEvent<Long> {
	private final Long deviceIndex;
	/**
	 * Display detail about an element on the map
	 * @param interventionIndex the intervention index or -1L
	 * @param deviceIndex the device index or -1L
	 */
	public DetailInterventionEvent(Long interventionIndex, Long deviceIndex) {
		super(GenericEvent.Type.INTER_DETAIL, interventionIndex);
		this.deviceIndex=deviceIndex;
	}
	
	public Long getDeviceIndex() {
		return deviceIndex;
	}
	
}
