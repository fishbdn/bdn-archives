package com.francetelecom.protosig.presentation.client.mvp.view.impl;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.mvp.view.ErrorView;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class ErrorViewImpl extends Composite implements ErrorView {

	private final Label textContent;
	private final DisclosurePanel detailPanel;

	private int stackSize = 0;
	private static final int MIN_STACK_LINES=10;
	private static final int MAX_STACK_LINES=50;

	public ErrorViewImpl() {
		// home page text content settings
		textContent = new Label();
		detailPanel = new DisclosurePanel(Application.CONSTANTS.error_detail());
		detailPanel.setAnimationEnabled(true);

		initWidget(getDisplay());
	}

	private Widget getDisplay() {

		// content panel configurationH
		FlowPanel panel = new FlowPanel();
		panel.getElement().setId("content");
		panel.add(textContent);
		panel.add(detailPanel);

		textContent.setStyleName("error-message");
		detailPanel.setStyleName("error-detail");

		return panel;
	}

	@Override
	public void setError(Throwable caught) {
		textContent.setText(Application.CONSTANTS.error_internal());
		detailPanel.setOpen(false);
		VerticalPanel detailContent = new VerticalPanel();
		detailPanel.setContent(detailContent);
		stackSize = 0;
		displayStack(caught, detailContent, false);
		detailPanel.setVisible(true);
	}

	private void displayStack(Throwable caught, Panel detailContent,
			boolean causedby) {

		stackSize++;

		if (causedby) {
			Label causedByLabel = new Label("Caused by :" + caught.toString());
			causedByLabel.setStyleName("error-title");
			detailContent.add(causedByLabel);
		} else {
			Label titleDetail = new Label(caught.toString());
			titleDetail.setStyleName("error-title");
			detailContent.add(titleDetail);
		}

		if (caught.getStackTrace() != null) {
			for (StackTraceElement elem : caught.getStackTrace()) {
				detailContent.add(new Label(elem.toString()));
			}
		}

		if (stackSize < MAX_STACK_LINES && caught.getCause() != null
				&& !caught.getCause().equals(caught)) {
			displayStack(caught.getCause(), detailContent, true);
		} else if (!(stackSize < MIN_STACK_LINES)) {
			Label causedByLabel = new Label("[...]");
			causedByLabel.setStyleName("error-title");
			detailContent.add(causedByLabel);
		}
	}
}
