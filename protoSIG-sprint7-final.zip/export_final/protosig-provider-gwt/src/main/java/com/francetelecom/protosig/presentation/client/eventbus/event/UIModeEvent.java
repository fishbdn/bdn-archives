package com.francetelecom.protosig.presentation.client.eventbus.event;

import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.ui.SiteUI;

/**
 * Defines the main UI mode
 * 
 * MAP : agenda in left row + map in right row
 * EDIT_CUSTOMER : full screen customer edit form
 * EDIT_PC : full screen pc edit form
 * 
 * @author jcwilk
 * 
 */
public class UIModeEvent extends GenericEvent<SiteUI.Mode> {
	private final InterventionBean intervention;
	private final NetworkDeviceBean pc;
	private final PcDto pcDto;

	/**
	 * Set the UI Mode
	 * @param mode 
	 * @param currentIntervention null if mode == MAP
	 * @param pc only if mode == EDIT_PC
	 */
	public UIModeEvent(SiteUI.Mode mode, InterventionBean currentIntervention,
			NetworkDeviceBean pc) {
		super(GenericEvent.Type.UI_MODE, mode);
		this.intervention = currentIntervention;
		this.pc = pc;
		this.pcDto=null;
	}

	public UIModeEvent(PcDto pcDto) {
		super(GenericEvent.Type.UI_MODE,SiteUI.Mode.EDIT_CLOSE_PC);
		this.intervention=null;
		this.pc=null;
		this.pcDto=pcDto;
	}
	
	public InterventionBean getIntervention() {
		return intervention;
	}

	public NetworkDeviceBean getPc() {
		return pc;
	}

	public PcDto getPcDto() {
		return pcDto;
	}

}
