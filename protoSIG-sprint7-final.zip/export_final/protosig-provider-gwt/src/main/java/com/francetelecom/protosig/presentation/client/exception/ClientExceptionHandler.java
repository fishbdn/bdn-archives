package com.francetelecom.protosig.presentation.client.exception;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.ErrorEvent;
import com.francetelecom.protosig.presentation.client.mvp.place.ErrorPlace;
import com.google.gwt.core.client.GWT.UncaughtExceptionHandler;

public class ClientExceptionHandler implements UncaughtExceptionHandler {

	@Override
	public void onUncaughtException(Throwable e) {
		if (e instanceof ClientFunctionalException) {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new ErrorEvent(Application.CONSTANTS.getString(e.getMessage())));
		} else {
			// unexpected error. Display stack trace
			Application.CLIENT_FACTORY.getPlaceController().goTo(
					new ErrorPlace(e));
		}
	}

}
