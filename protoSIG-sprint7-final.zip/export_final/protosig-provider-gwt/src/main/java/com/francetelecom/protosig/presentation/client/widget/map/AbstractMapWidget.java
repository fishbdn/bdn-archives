package com.francetelecom.protosig.presentation.client.widget.map;

import com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.francetelecom.protosig.presentation.client.widget.map.model.MapBox;
import com.francetelecom.protosig.presentation.client.widget.map.model.PushpinType;
import com.francetelecom.protosig.presentation.client.widget.map.model.Resource;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTMLPanel;

/**
 * Map Interface
 * 
 * @author JLZB1407
 * 
 */
public abstract class AbstractMapWidget extends Composite {

	/**
	 * Geocoding API associated with this map implementation
	 * 
	 * @return
	 */
	public abstract IGeocoding getGeocoding();

	public abstract String getMapId();

	/**
	 * Add a new pushpin
	 * 
	 * @param pushpin
	 */
	public abstract void add(Pushpin pushpin);

	/**
	 * Remove an previously added pushpin
	 * 
	 * @param pushpin
	 */
	public abstract void remove(Pushpin pushpin);
	
	/**
	 * Move a pushpin on the map (doesn't update pushpin.location, only the javascript side)
	 * @param pushpin
	 * @param newLoc
	 */
	public abstract void move(Pushpin pushpin, Location newLoc);

	/**
	 * Enable drag and drop on this pushpin :
	 * 
	 * pushpin text is removed
	 * 
	 * pushpin icon xxx.yyy is replaced by xxx_drag.yyy
	 * 
	 * @param pushpin
	 */
	public abstract void enableDragDrop(Pushpin pushpin);

	/**
	 * Disable last activated pushpin drag and drop
	 * 
	 * @param cancel
	 *            if true, cancel the pushpin movement
	 */
	public abstract void disableDragAndDrop(boolean cancel);

	/**
	 * Remove all pushpins on the map
	 */
	public abstract void clearPushpins();

	public abstract void clearInfoBox();

	public abstract void addInfoBox(Pushpin pushpin);

	/**
	 * scroll the map center to the location
	 * 
	 * @param location
	 */
	public abstract void setView(Location location);

	/**
	 * Set the new map box bounds
	 * 
	 * @param box
	 */
	public abstract void setView(MapBox box);

	/**
	 * Change the zoom level
	 * 
	 * @param zoom
	 */
	public abstract void setZoom(int zoom);

	/**
	 * Adapt the view to existing pushpins
	 */
	public abstract void setAutoView();
	
	/**
	 * Change the view to include given point
	 * @param x
	 * @param y
	 */
	public abstract void updateView(double x, double y);

	/**
	 * Start to record new pushpins
	 */
	public abstract void startView();

	/**
	 * Adapt the view to all the pushpins created since startView()
	 */
	public abstract void endView();

	public abstract void register(IViewChangeHandler handler);

	public abstract void unregister(IViewChangeHandler handler);

	public abstract Resource getBox();

	public abstract HTMLPanel getMapPanel();

	public interface IViewChangeHandler {

		void onViewChanged(Resource resource);
	}

	public interface IPushpin {

		PushpinType getType();

		Location getLocation();

		String getImagePath();

		String getTextPin();
	}

	public abstract void addDirect(Pushpin pushpin);

	public abstract void selectPushpin(Pushpin pushpin);

}
