package com.francetelecom.protosig.presentation.client.eventbus.event;


/**
 * Displays a temporary warning message
 * @author jcwilk
 *
 */
public class WarnEvent extends MessageEvent {
	public WarnEvent(String message) {
		super(Severity.WARN,message);
	}
}
