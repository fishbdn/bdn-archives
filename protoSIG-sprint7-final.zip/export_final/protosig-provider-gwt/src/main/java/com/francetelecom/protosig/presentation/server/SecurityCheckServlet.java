/**
 * 
 */
package com.francetelecom.protosig.presentation.server;

import java.util.List;

import com.francetelecom.protosig.model.UserDto;
import com.francetelecom.protosig.model.exception.ClientException;
import com.francetelecom.protosig.model.security.UserRoleDto;
import com.google.gwt.user.client.rpc.IncompatibleRemoteServiceException;
import com.google.gwt.user.client.rpc.RpcTokenException;
import com.google.gwt.user.client.rpc.SerializationException;
import com.google.gwt.user.server.rpc.RPC;
import com.google.gwt.user.server.rpc.RPCRequest;

/**
 * This class will be an entry point for any Security check before calling the
 * server RPC
 * 
 * @author mlaffargue
 * 
 */
public class SecurityCheckServlet extends
		SpringBeanInjectionRemoteServiceServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2300886094482476226L;

	@Override
	public String processCall(String payload) throws SerializationException {
		// First, check for possible XSRF situation
		checkPermutationStrongName();
		try {
			RPCRequest rpcRequest = RPC.decodeRequest(payload, this.getClass(),
					this);
			onAfterRequestDeserialized(rpcRequest);

			// Check common security rules
			if (getUserFromSession() == null
					|| getUserRolesFromSession() == null
					|| getUserRolesFromSession().size() == 0) {
				log("Bad user session");
				return RPC.encodeResponseForFailure(rpcRequest.getMethod(),
						new ClientException(
								"Problème avec la session [Security check]"));
			}

			return RPC.invokeAndEncodeResponse(this, rpcRequest.getMethod(),
					rpcRequest.getParameters(),
					rpcRequest.getSerializationPolicy(), rpcRequest.getFlags());
		} catch (IncompatibleRemoteServiceException ex) {
			log("An IncompatibleRemoteServiceException was thrown while processing this call.",
					ex);
			return RPC.encodeResponseForFailure(null, ex);
		} catch (RpcTokenException tokenException) {
			log("An RpcTokenException was thrown while processing this call.",
					tokenException);
			return RPC.encodeResponseForFailure(null, tokenException);
		}
	}

	/**
	 * Retrieve user from session
	 * 
	 * @return the user
	 */
	public UserDto getUserFromSession() {
		return (UserDto) getThreadLocalRequest().getSession().getAttribute(
				SessionAttribute.USER);
	}

	/**
	 * Retrieve the user roles from session
	 * 
	 * @return the user roles
	 */
	@SuppressWarnings("unchecked")
	public List<UserRoleDto> getUserRolesFromSession() {
		return (List<UserRoleDto>) getThreadLocalRequest().getSession()
				.getAttribute(SessionAttribute.ROLES);
	}
}
