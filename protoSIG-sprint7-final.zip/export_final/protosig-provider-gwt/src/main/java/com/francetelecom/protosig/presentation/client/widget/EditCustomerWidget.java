package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.UIModeEvent;
import com.francetelecom.protosig.presentation.client.factory.GenericReflectiveDtoFactory;
import com.francetelecom.protosig.presentation.client.factory.GenericReflectiveDtoFactory.GenericDtoType;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.rpc.GenericMessageCallback;
import com.francetelecom.protosig.presentation.client.ui.SiteUI;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class EditCustomerWidget extends Composite {

	private static EditCustomerWidgetUiBinder uiBinder = GWT
			.create(EditCustomerWidgetUiBinder.class);

	interface EditCustomerWidgetUiBinder extends
			UiBinder<Widget, EditCustomerWidget> {
	}

	// CHECKSTYLE:OFF
	@UiField
	protected TextBox clientNameValue;
	@UiField
	protected TextBox ndValue;
	@UiField
	protected TextBox doorValue;
	@UiField
	protected TextBox levelValue;
	@UiField
	protected TextBox stairValue;
	@UiField
	protected TextBox groupValue;
	@UiField
	protected TextBox buildingValue;
	@UiField
	protected TextBox numberValue;
	@UiField
	protected TextBox numberComplementValue;
	@UiField
	protected TextBox streetValue;
	@UiField
	protected TextBox cityCodeValue;
	@UiField
	protected TextBox cityNameValue;
	@UiField
	protected TextArea commentValue;
	@UiField
	protected Button cancelButton;
	@UiField
	protected Button saveButton;

	// CHECKSTYLE:ON

	private GenericDto dto;
	
	private class SaveClickHandler implements ClickHandler {
		@Override
		public void onClick(ClickEvent event) {
			// save updates to the database
			setUpdates();
			Application.CLIENT_FACTORY.getSigService().saveCustomerUpdate(
					dto,
					new GenericMessageCallback<Void>(Application.CONSTANTS
							.customer_updated(), Application.CONSTANTS
							.customer_updated_error()));
			// go back to map mode
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new UIModeEvent(SiteUI.Mode.MAP, null, null));

		}
	};

	public EditCustomerWidget() {
		initWidget(uiBinder.createAndBindUi(this));
		// set buttons callbacks
		cancelButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				// go back to map mode
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new UIModeEvent(SiteUI.Mode.MAP, null, null));
			}
		});
		saveButton.addClickHandler(new SaveClickHandler());
	}

	/**
	 * Create a dto containing values from the form
	 * 
	 * @return
	 */
	private void setUpdates() {
		dto.setLabel(clientNameValue.getText());
		dto.setNewValue(GenericDto.FIELD_BUILDING,buildingValue.getText());
		dto.setNewValue(GenericDto.FIELD_CITY_NAME,cityNameValue.getText());
		dto.setNewValue(GenericDto.FIELD_COMMENT,commentValue.getText());
		dto.setNewValue(GenericDto.FIELD_CITY_CODE,cityCodeValue.getText());
		dto.setNewValue(GenericDto.FIELD_LEVEL,levelValue.getText());
		dto.setNewValue(GenericDto.FIELD_NUMBER,numberValue.getText());
		dto.setNewValue(GenericDto.FIELD_NUMBER_COMPLEMENT,numberComplementValue.getText());
		dto.setNewValue(GenericDto.FIELD_STAIR,stairValue.getText());
		dto.setNewValue(GenericDto.FIELD_STREET,streetValue.getText());
		dto.setNewValue(GenericDto.FIELD_GROUP,groupValue.getText());
		dto.setNewValue(GenericDto.FIELD_DOOR,doorValue.getText());
	}

	/**
	 * Reset the form for a new customer
	 * 
	 * @param intervention
	 */
	public void setIntervention(InterventionBean intervention) {
		dto = GenericReflectiveDtoFactory.create(GenericDtoType.CUSTOMER, intervention, null);
		// init fields labels
		clientNameValue.setText(dto.getOldValue(GenericDto.FIELD_CLIENT_NAME));
		ndValue.setText(dto.getOldValue(GenericDto.FIELD_ND));
		doorValue.setText(dto.getOldValue(GenericDto.FIELD_DOOR));
		levelValue.setText(dto.getOldValue(GenericDto.FIELD_LEVEL));
		stairValue.setText(dto.getOldValue(GenericDto.FIELD_STAIR));
		groupValue.setText(dto.getOldValue(GenericDto.FIELD_GROUP));
		buildingValue.setText(dto.getOldValue(GenericDto.FIELD_BUILDING));
		numberValue.setText(dto.getOldValue(GenericDto.FIELD_NUMBER));
		numberComplementValue.setText(dto.getOldValue(GenericDto.FIELD_NUMBER_COMPLEMENT));
		streetValue.setText(dto.getOldValue(GenericDto.FIELD_STREET));
		cityCodeValue.setText(dto.getOldValue(GenericDto.FIELD_CITY_CODE));
		cityNameValue.setText(dto.getOldValue(GenericDto.FIELD_CITY_NAME));
		commentValue.setText(dto.getOldValue(GenericDto.FIELD_COMMENT));
	}

}
