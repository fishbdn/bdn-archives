package com.francetelecom.protosig.presentation.client.utils.localstorage.impl;

import java.util.LinkedList;

import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IAgenda;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.ISigAutoBeanFactory;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.ISigData;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.ISigInterventionData;
import com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.google.gwt.core.client.GWT;
import com.google.gwt.storage.client.Storage;
import com.google.web.bindery.autobean.shared.AutoBean;
import com.google.web.bindery.autobean.shared.AutoBeanCodex;

public class LocalStorageImpl implements ILocalStorage {
	private Storage storage = null;
	/**
	 * storage key for the agenda from iTech
	 */
	protected static final String AGENDA_STORAGE_KEY = "AGENDA";
	/**
	 * storage key for the SIG specific data
	 */
	protected static final String SIG_STORAGE_KEY = "SIG";
	
	private static final String NULL_STRING="null";
	
	private final ISigAutoBeanFactory factory=GWT.create(ISigAutoBeanFactory.class);
	
	public LocalStorageImpl() throws ClientFunctionalException {
		storage = Storage.getLocalStorageIfSupported();
		if (storage == null) {
			throw new ClientFunctionalException(
					ClientFunctionalException.NO_HTML5);
		}
	}

	/**
	 * Decode agenda from json in local storage
	 * @return
	 * @throws ClientFunctionalException 
	 */
	@Override
	public IAgenda getAgenda() throws ClientFunctionalException {
		String jsonAgenda = storage.getItem(AGENDA_STORAGE_KEY);
		if (jsonAgenda == null || NULL_STRING.equals(jsonAgenda)) {
			throw new ClientFunctionalException(ClientFunctionalException.NO_LOCAL_STORAGE);
		}
		AutoBean<IAgenda> agenda = AutoBeanCodex.decode(factory, IAgenda.class, jsonAgenda);
		return agenda.as();
	}
	
	/**
	 * Decode intervention detail from json in local storage
	 * @param idIntervention
	 * @param codeBase
	 * @return
	 * @throws ClientFunctionalException
	 */
	@Override
	public INodeClientData getDetailIntervention(String idIntervention, String codeBase) throws ClientFunctionalException {
		String jsonDetail=storage.getItem(idIntervention+"."+codeBase);
		if ( jsonDetail == null ) {
			throw new ClientFunctionalException(ClientFunctionalException.NO_LOCAL_STORAGE);
		}
		AutoBean<INodeClientData> intervention=AutoBeanCodex.decode(factory, INodeClientData.class, jsonDetail);
		return intervention.as();
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage#saveCustomerPos(com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean)
	 */
	@Override
	public void saveCustomerPos(InterventionBean inter) {
		String sigJson=storage.getItem(SIG_STORAGE_KEY);
		ISigData data;
		AutoBean<ISigData> sigDataAutoBean;
		if ( sigJson != null && ! NULL_STRING.equals(sigJson) ) {
			// read data from the local storage
			sigDataAutoBean = AutoBeanCodex.decode(factory, ISigData.class, sigJson);
		} else {
			// create a new data from scratch
			sigDataAutoBean = factory.sigData();
			sigDataAutoBean.as().setInterventionList(new LinkedList<ISigInterventionData>());
		}
		data=sigDataAutoBean.as();
		// Check if intervention already exists
		ISigInterventionData interData = null; 
		for (ISigInterventionData curInter:data.getInterventionList()) {
			if ( inter.getEtechReference().equals(curInter.getReference()) ) {
				interData=curInter;
				break;
			}
		}
		if ( interData == null ) {
			// create a new intervention data
			interData = factory.sigInterventionData().as();
			interData.setReference(inter.getEtechReference());
			data.getInterventionList().add(interData);
		}
		Location customerLocation=inter.getLocation();
		interData.setCustomerX(customerLocation.getX());
		interData.setCustomerY(customerLocation.getY());
		// update json in local storage
		sigJson = AutoBeanCodex.encode(sigDataAutoBean).getPayload();
		storage.setItem(SIG_STORAGE_KEY, sigJson);
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage#savePcPos(com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean, com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean)
	 */
	@Override
	public void savePcPos(InterventionBean inter, NetworkDeviceBean pc) {
		String sigJson=storage.getItem(SIG_STORAGE_KEY);
		ISigData data;
		AutoBean<ISigData> sigDataAutoBean;
		if ( sigJson != null && ! NULL_STRING.equals(sigJson) ) {
			// read data from the local storage
			sigDataAutoBean = AutoBeanCodex.decode(factory, ISigData.class, sigJson);
		} else {
			// create a new data from scratch
			sigDataAutoBean = factory.sigData();
			sigDataAutoBean.as().setInterventionList(new LinkedList<ISigInterventionData>());
		}
		data=sigDataAutoBean.as();
		// Check if intervention already exists
		ISigInterventionData interData = null; 
		for (ISigInterventionData curInter:data.getInterventionList()) {
			if ( inter.getEtechReference().equals(curInter.getReference()) ) {
				interData=curInter;
				break;
			}
		}
		if ( interData == null ) {
			// create a new intervention data
			interData = factory.sigInterventionData().as();
			interData.setReference(inter.getEtechReference());
			data.getInterventionList().add(interData);
		}
		Location pcLocation=pc.getLocation();
		interData.setPCX(pcLocation.getX());
		interData.setPCY(pcLocation.getY());
		// update json in local storage
		sigJson = AutoBeanCodex.encode(sigDataAutoBean).getPayload();
		storage.setItem(SIG_STORAGE_KEY, sigJson);		
	}

	/**
	 * Get intervention data from SIG local storage
	 * @param inter
	 * @return null if not found
	 */
	private ISigInterventionData getInterventionData(InterventionBean inter) {
		// read data from local storage 
		String sigJson=storage.getItem(SIG_STORAGE_KEY);
		if ( sigJson == null || NULL_STRING.equals(sigJson) ) {
			return null;
		}
		// parse it
		AutoBean<ISigData> sigDataAutoBean = AutoBeanCodex.decode(factory, ISigData.class, sigJson);
		ISigData data=sigDataAutoBean.as();
		if ( data.getInterventionList() == null ) {
			return null;
		}
		// Check if intervention exists
		for (ISigInterventionData curInter:data.getInterventionList()) {
			if ( inter.getEtechReference().equals(curInter.getReference()) ) {
				return curInter;
			}
		}
		// not found
		return null;
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage#updateIntervention(com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean)
	 */
	@Override
	public void updateIntervention(InterventionBean inter) {
		ISigInterventionData curInter = getInterventionData(inter);
		if ( curInter != null && curInter.getCustomerX() != null ) {
			// customer was moved
			inter.setOriginalX(inter.getLocation().getX());
			inter.setOriginalY(inter.getLocation().getY());
			inter.getLocation().setX(curInter.getCustomerX());
			inter.getLocation().setY(curInter.getCustomerY());
		}
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage#updatePC(com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean, com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean)
	 */
	@Override
	public void updatePC(InterventionBean inter, NetworkDeviceBean device) {
		ISigInterventionData curInter = getInterventionData(inter);
		if ( curInter != null && curInter.getPCX() != null ) {
			// pc was moved
			device.setOriginalX(device.getLocation().getX());
			device.setOriginalY(device.getLocation().getY());
			device.getLocation().setX(curInter.getPCX());
			device.getLocation().setY(curInter.getPCY());					
		}
	}

	public Storage getStorage() {
		return storage;
	}

}
