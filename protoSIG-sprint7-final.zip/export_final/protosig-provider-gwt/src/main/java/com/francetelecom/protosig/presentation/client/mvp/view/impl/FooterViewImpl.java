package com.francetelecom.protosig.presentation.client.mvp.view.impl;

import com.francetelecom.protosig.presentation.client.mvp.view.FooterView;
import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.ui.Widget;

/**
 * Basic Desktop {@link FooterView} implementation.
 */
public class FooterViewImpl extends AbstractViewImpl implements FooterView {

	interface FooterUiBinder extends UiBinder<Widget, FooterViewImpl> {
	}

	private static FooterUiBinder uiBinder = GWT.create(FooterUiBinder.class);

	/**
	 * Constructor.
	 */
	public FooterViewImpl() {
		initWidget(uiBinder.createAndBindUi(this));
	}

}
