package com.francetelecom.protosig.presentation.client.widget.map.impl.bing;

import java.util.HashMap;
import java.util.Map;

import com.francetelecom.protosig.presentation.client.widget.map.IGeocoding;
import com.francetelecom.protosig.presentation.client.widget.map.IGeocodingCallback;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.google.gwt.core.shared.GWT;

/**
 * Bing geocoding implementation
 * 
 * @author jcwilk
 * 
 */
public class Geocoding implements IGeocoding {

	public static final String URL_REST_V1 = "http://dev.virtualearth.net/REST/v1/Locations/${0}?output=json&key=${1}&jsonp=";
	/**
	 * Confidence values for high confidence
	 */
	private static final String CONFIDENCE_HIGH="High";
	/**
	 * Entity type values 
	 */
	private static final String ENTITY_TYPE_ADDRESS="Address";
	
	/**
	 * Callback associated with each geocoding request
	 */
	private final Map<Long,IGeocodingCallback> userCallbacks=new HashMap<Long,IGeocodingCallback>();
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void geocode(final Long id, String address, final IGeocodingCallback callback) {

		String url = URL_REST_V1.replace("${1}", Authorization.AUTH_KEY);
		url = url.replace("${0}", address);
		userCallbacks.put(id, callback);
		nativeGeocode(this,id,url);
	}

	/**
	 * Cross-site ajax call usin json with padding. 
	 * @see https://developers.google.com/web-toolkit/doc/2.4/tutorial/Xsite
	 * @param index (cannot use long in JSNI)
	 * @param url
	 */
	public static native void nativeGeocode(Geocoding me, double index, String url) /*-{
	// Create a script element.
	var callback = "callback" + index;
	var script = document.createElement("script");
	script.setAttribute("src", url+callback);
	script.setAttribute("type", "text/javascript");
	// Define the callback function on the window object.
	window[callback] = function(result) {
		if (result &&
			result.resourceSets &&
			result.resourceSets.length > 0 &&
			result.resourceSets[0].resources &&
			result.resourceSets[0].resources.length > 0) {
			window[callback+"done"] = true;
			var x=result.resourceSets[0].resources[0].point.coordinates[1];
			var y=result.resourceSets[0].resources[0].point.coordinates[0];
			var confidence=result.resourceSets[0].resources[0].confidence;
			var entityType=result.resourceSets[0].resources[0].entityType;
	   		me.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Geocoding::onSuccessCallback(DDDLjava/lang/String;Ljava/lang/String;)(index,x,y,confidence,entityType);           		
		}
	}
	// wait 10 sec and clean-up
	setTimeout(function() {
		if (!window[callback + "done"]) {
    		me.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Geocoding::onErrorCallback(D)(index);
    	}
		// Cleanup. Remove script and callback elements.
		document.body.removeChild(script);
		delete window[callback];
		delete window[callback + "done"];
	}, 10000);
	// Attach the script element to the document body.
	document.body.appendChild(script);	   	   
   	}-*/;

	/**
	 * Called by javascript when geocoding succeeded
	 * @param dindex request index
	 * @param x result's longitude
	 * @param y result's latitude
	 * @param confidence confidence value (Hig/Medium/Low)
	 * @param entityType entity (http://msdn.microsoft.com/en-us/library/ff728811.aspx) 
	 */
	public void onSuccessCallback(double dindex, double x, double y, String confidence, String entityType) {
		IGeocodingCallback userCallback=userCallbacks.get((long)dindex);
		GWT.log("geocoding success " + (int)(dindex) + " : " + confidence + "/"+entityType);
		if ( userCallback != null ) {
			boolean confidenceOk=CONFIDENCE_HIGH.equals(confidence) && ENTITY_TYPE_ADDRESS.equals(entityType);
			userCallback.onSuccess((long)dindex, new Location(x,y),confidenceOk);
			userCallbacks.remove(userCallback);
		}
	}
	/**
	 * Called by javascript when geocoding didn't succeed
	 * @param dindex
	 */
	public void onErrorCallback(double dindex) {
		IGeocodingCallback userCallback=userCallbacks.get((long)dindex);
		GWT.log("geocoding error " + (int)(dindex) );
		if ( userCallback != null ) {
			userCallback.onError((long)dindex);
			userCallbacks.remove(userCallback);
		}
	}
}
