package com.francetelecom.protosig.presentation.client.rpc;

import java.util.List;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.GeocodeResponseDto;
import com.francetelecom.protosig.model.PcDto;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Asynchronous interface for SigService
 * @author jcwilk
 *
 */
public interface SigServiceAsync {
	void getPostalCodeFromInseeCode(String inseeCode, AsyncCallback<String> cbk);
	void geocode(String streetNumber, String streetName, String inseeCode, String cityName, AsyncCallback<GeocodeResponseDto> cbk);
	void getClosestPC(String dr, Double x, Double y, AsyncCallback<List<PcDto>> cbk);
	void savePcUpdate(GenericDto update, AsyncCallback<Void> cbk);
	void savePcLocation(String id, Double oldx, Double oldy, Double x, Double y, AsyncCallback<Void> cbk);
	void saveCustomerUpdate(GenericDto update, AsyncCallback<Void> cbk);	
}
