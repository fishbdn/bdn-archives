package com.francetelecom.protosig.presentation.client.widget.map;

import java.util.List;

import com.francetelecom.protosig.presentation.client.widget.map.model.PositionBean;

/**
 * Infobox Factory. Used to build pushpin tooltip.
 * 
 * @author JLZB1407
 * 
 */
public class InfoBoxFactory<T extends PositionBean> {

	public InfoBoxFactory() {
	}

	public InfoBoxWidget<T> createInfoBox(List<T> beanList) {
		throw new IllegalArgumentException("type de Localizable non supporté");
	}

}
