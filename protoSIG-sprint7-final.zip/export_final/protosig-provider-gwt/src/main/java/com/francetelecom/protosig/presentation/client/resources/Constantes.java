package com.francetelecom.protosig.presentation.client.resources;

/**
 * Interface to represent the constants contained in resource bundle:
 * 	'D:/JCW/workspace42/protosig/protosig-provider-gwt/src/main/java/com/francetelecom/protosig/presentation/client/resources/Constantes.properties'.
 */
public interface Constantes extends com.google.gwt.i18n.client.ConstantsWithLookup {
  
  /**
   * Translated "Proto SIG".
   * 
   * @return translated "Proto SIG"
   */
  @DefaultStringValue("Proto SIG")
  @Key("app.title")
  String app_title();

  /**
   * Translated "<< Retour".
   * 
   * @return translated "<< Retour"
   */
  @DefaultStringValue("<< Retour")
  @Key("button.back")
  String button_back();

  /**
   * Translated "Annuler".
   * 
   * @return translated "Annuler"
   */
  @DefaultStringValue("Annuler")
  @Key("button.cancel")
  String button_cancel();

  /**
   * Translated "Fermer".
   * 
   * @return translated "Fermer"
   */
  @DefaultStringValue("Fermer")
  @Key("button.close")
  String button_close();

  /**
   * Translated "Créer".
   * 
   * @return translated "Créer"
   */
  @DefaultStringValue("Créer")
  @Key("button.create")
  String button_create();

  /**
   * Translated "Supprimer".
   * 
   * @return translated "Supprimer"
   */
  @DefaultStringValue("Supprimer")
  @Key("button.delete")
  String button_delete();

  /**
   * Translated "Détails".
   * 
   * @return translated "Détails"
   */
  @DefaultStringValue("Détails")
  @Key("button.detail")
  String button_detail();

  /**
   * Translated "Télécharger".
   * 
   * @return translated "Télécharger"
   */
  @DefaultStringValue("Télécharger")
  @Key("button.download")
  String button_download();

  /**
   * Translated "Modifier".
   * 
   * @return translated "Modifier"
   */
  @DefaultStringValue("Modifier")
  @Key("button.edit")
  String button_edit();

  /**
   * Translated "Suivant".
   * 
   * @return translated "Suivant"
   */
  @DefaultStringValue("Suivant")
  @Key("button.next")
  String button_next();

  /**
   * Translated "Valider".
   * 
   * @return translated "Valider"
   */
  @DefaultStringValue("Valider")
  @Key("button.ok")
  String button_ok();

  /**
   * Translated "Précédent".
   * 
   * @return translated "Précédent"
   */
  @DefaultStringValue("Précédent")
  @Key("button.previous")
  String button_previous();

  /**
   * Translated "Enregistrer".
   * 
   * @return translated "Enregistrer"
   */
  @DefaultStringValue("Enregistrer")
  @Key("button.save")
  String button_save();

  /**
   * Translated "Rechercher".
   * 
   * @return translated "Rechercher"
   */
  @DefaultStringValue("Rechercher")
  @Key("button.search")
  String button_search();

  /**
   * Translated "TAM".
   * 
   * @return translated "TAM"
   */
  @DefaultStringValue("TAM")
  @Key("button.tam")
  String button_tam();

  /**
   * Translated "Modifier".
   * 
   * @return translated "Modifier"
   */
  @DefaultStringValue("Modifier")
  @Key("button.update")
  String button_update();

  /**
   * Translated "La position géographique du client a bien été modifiée en base".
   * 
   * @return translated "La position géographique du client a bien été modifiée en base"
   */
  @DefaultStringValue("La position géographique du client a bien été modifiée en base")
  @Key("customer.moved")
  String customer_moved();

  /**
   * Translated "Les modifications du client ont été sauvées en base. Elle seront visibles dans 42C d'ici quelques jours.".
   * 
   * @return translated "Les modifications du client ont été sauvées en base. Elle seront visibles dans 42C d'ici quelques jours."
   */
  @DefaultStringValue("Les modifications du client ont été sauvées en base. Elle seront visibles dans 42C d'ici quelques jours.")
  @Key("customer.updated")
  String customer_updated();

  /**
   * Translated "Erreur lors de la sauvegarde des modifications du client en base".
   * 
   * @return translated "Erreur lors de la sauvegarde des modifications du client en base"
   */
  @DefaultStringValue("Erreur lors de la sauvegarde des modifications du client en base")
  @Key("customer.updated.error")
  String customer_updated_error();

  /**
   * Translated "Faites glisser l'icône sur la carte pour modifier la position du client. Appuyez sur Enregistrer pour valider la nouvelle position.".
   * 
   * @return translated "Faites glisser l'icône sur la carte pour modifier la position du client. Appuyez sur Enregistrer pour valider la nouvelle position."
   */
  @DefaultStringValue("Faites glisser l'icône sur la carte pour modifier la position du client. Appuyez sur Enregistrer pour valider la nouvelle position.")
  @Key("customerMove.text")
  String customerMove_text();

  /**
   * Translated "Mise à jour position client".
   * 
   * @return translated "Mise à jour position client"
   */
  @DefaultStringValue("Mise à jour position client")
  @Key("customerMove.title")
  String customerMove_title();

  /**
   * Translated "dd/MM/yyyy".
   * 
   * @return translated "dd/MM/yyyy"
   */
  @DefaultStringValue("dd/MM/yyyy")
  @Key("datePattern")
  String datePattern();

  /**
   * Translated "dd/MM/yyyy HH:mm:ss".
   * 
   * @return translated "dd/MM/yyyy HH:mm:ss"
   */
  @DefaultStringValue("dd/MM/yyyy HH:mm:ss")
  @Key("dateTimePattern")
  String dateTimePattern();

  /**
   * Translated "Format de données incorrect".
   * 
   * @return translated "Format de données incorrect"
   */
  @DefaultStringValue("Format de données incorrect")
  @Key("error.badInputData")
  String error_badInputData();

  /**
   * Translated "L'utilisation des boutons Précédent et Suivant du navigateur est � proscrire. Merci d'utiliser les boutons prévus à cet effet sur les IHMs.".
   * 
   * @return translated "L'utilisation des boutons Précédent et Suivant du navigateur est � proscrire. Merci d'utiliser les boutons prévus à cet effet sur les IHMs."
   */
  @DefaultStringValue("L'utilisation des boutons Précédent et Suivant du navigateur est � proscrire. Merci d'utiliser les boutons prévus à cet effet sur les IHMs.")
  @Key("error.browser.navigation.button")
  String error_browser_navigation_button();

  /**
   * Translated "Détails".
   * 
   * @return translated "Détails"
   */
  @DefaultStringValue("Détails")
  @Key("error.detail")
  String error_detail();

  /**
   * Translated "Une erreur technique est survenue.".
   * 
   * @return translated "Une erreur technique est survenue."
   */
  @DefaultStringValue("Une erreur technique est survenue.")
  @Key("error.internal")
  String error_internal();

  /**
   * Translated "Votre navigateur ne supporte pas HTML5".
   * 
   * @return translated "Votre navigateur ne supporte pas HTML5"
   */
  @DefaultStringValue("Votre navigateur ne supporte pas HTML5")
  @Key("error.noHtml5")
  String error_noHtml5();

  /**
   * Translated "Impossible d'accéder aux données du portail iTech".
   * 
   * @return translated "Impossible d'accéder aux données du portail iTech"
   */
  @DefaultStringValue("Impossible d'accéder aux données du portail iTech")
  @Key("error.noLocalStorage")
  String error_noLocalStorage();

  /**
   * Translated "com rh".
   * 
   * @return translated "com rh"
   */
  @DefaultStringValue("com rh")
  @Key("footer.comRh")
  String footer_comRh();

  /**
   * Translated "contactez-nous".
   * 
   * @return translated "contactez-nous"
   */
  @DefaultStringValue("contactez-nous")
  @Key("footer.contact")
  String footer_contact();

  /**
   * Translated "interne Groupe France Telecom".
   * 
   * @return translated "interne Groupe France Telecom"
   */
  @DefaultStringValue("interne Groupe France Telecom")
  @Key("footer.internal")
  String footer_internal();

  /**
   * Translated "haut de page".
   * 
   * @return translated "haut de page"
   */
  @DefaultStringValue("haut de page")
  @Key("footer.topOfPage")
  String footer_topOfPage();

  /**
   * Translated "Adresse".
   * 
   * @return translated "Adresse"
   */
  @DefaultStringValue("Adresse")
  @Key("form.address")
  String form_address();

  /**
   * Translated "Bâtiment".
   * 
   * @return translated "Bâtiment"
   */
  @DefaultStringValue("Bâtiment")
  @Key("form.building")
  String form_building();

  /**
   * Translated "Code commune".
   * 
   * @return translated "Code commune"
   */
  @DefaultStringValue("Code commune")
  @Key("form.cityCode")
  String form_cityCode();

  /**
   * Translated "Libellé commune".
   * 
   * @return translated "Libellé commune"
   */
  @DefaultStringValue("Libellé commune")
  @Key("form.cityName")
  String form_cityName();

  /**
   * Translated "Nom du client".
   * 
   * @return translated "Nom du client"
   */
  @DefaultStringValue("Nom du client")
  @Key("form.clientName")
  String form_clientName();

  /**
   * Translated "Commentaire d'adresse".
   * 
   * @return translated "Commentaire d'adresse"
   */
  @DefaultStringValue("Commentaire d'adresse")
  @Key("form.comment")
  String form_comment();

  /**
   * Translated "Centre".
   * 
   * @return translated "Centre"
   */
  @DefaultStringValue("Centre")
  @Key("form.const.centre")
  String form_const_centre();

  /**
   * Translated "dispo".
   * 
   * @return translated "dispo"
   */
  @DefaultStringValue("dispo")
  @Key("form.const.dispo")
  String form_const_dispo();

  /**
   * Translated "type".
   * 
   * @return translated "type"
   */
  @DefaultStringValue("type")
  @Key("form.const.type")
  String form_const_type();

  /**
   * Translated "zone/tete".
   * 
   * @return translated "zone/tete"
   */
  @DefaultStringValue("zone/tete")
  @Key("form.const.zone")
  String form_const_zone();

  /**
   * Translated "Complément adresse client".
   * 
   * @return translated "Complément adresse client"
   */
  @DefaultStringValue("Complément adresse client")
  @Key("form.customerStreetComplement")
  String form_customerStreetComplement();

  /**
   * Translated "Nom Point de coupure".
   * 
   * @return translated "Nom Point de coupure"
   */
  @DefaultStringValue("Nom Point de coupure")
  @Key("form.cutPoint")
  String form_cutPoint();

  /**
   * Translated "Porte".
   * 
   * @return translated "Porte"
   */
  @DefaultStringValue("Porte")
  @Key("form.door")
  String form_door();

  /**
   * Translated "Ensemble".
   * 
   * @return translated "Ensemble"
   */
  @DefaultStringValue("Ensemble")
  @Key("form.group")
  String form_group();

  /**
   * Translated "Etage".
   * 
   * @return translated "Etage"
   */
  @DefaultStringValue("Etage")
  @Key("form.level")
  String form_level();

  /**
   * Translated "ND".
   * 
   * @return translated "ND"
   */
  @DefaultStringValue("ND")
  @Key("form.nd")
  String form_nd();

  /**
   * Translated "N° Voie".
   * 
   * @return translated "N° Voie"
   */
  @DefaultStringValue("N° Voie")
  @Key("form.number")
  String form_number();

  /**
   * Translated "Complément n° voie".
   * 
   * @return translated "Complément n° voie"
   */
  @DefaultStringValue("Complément n° voie")
  @Key("form.numberComplement")
  String form_numberComplement();

  /**
   * Translated "Commentaire".
   * 
   * @return translated "Commentaire"
   */
  @DefaultStringValue("Commentaire")
  @Key("form.pcComment")
  String form_pcComment();

  /**
   * Translated "Descriptif technique".
   * 
   * @return translated "Descriptif technique"
   */
  @DefaultStringValue("Descriptif technique")
  @Key("form.pcDescTech")
  String form_pcDescTech();

  /**
   * Translated "Catégorie de PC".
   * 
   * @return translated "Catégorie de PC"
   */
  @DefaultStringValue("Catégorie de PC")
  @Key("form.pccat")
  String form_pccat();

  /**
   * Translated "Point de coupure PC".
   * 
   * @return translated "Point de coupure PC"
   */
  @DefaultStringValue("Point de coupure PC")
  @Key("form.pcname")
  String form_pcname();

  /**
   * Translated "Ref.".
   * 
   * @return translated "Ref."
   */
  @DefaultStringValue("Ref.")
  @Key("form.reference")
  String form_reference();

  /**
   * Translated "Point de coupure RE".
   * 
   * @return translated "Point de coupure RE"
   */
  @DefaultStringValue("Point de coupure RE")
  @Key("form.rename")
  String form_rename();

  /**
   * Translated "Dispositifs spéciaux".
   * 
   * @return translated "Dispositifs spéciaux"
   */
  @DefaultStringValue("Dispositifs spéciaux")
  @Key("form.specialDevice")
  String form_specialDevice();

  /**
   * Translated "Point de coupure SR".
   * 
   * @return translated "Point de coupure SR"
   */
  @DefaultStringValue("Point de coupure SR")
  @Key("form.srname")
  String form_srname();

  /**
   * Translated "Escalier".
   * 
   * @return translated "Escalier"
   */
  @DefaultStringValue("Escalier")
  @Key("form.stair")
  String form_stair();

  /**
   * Translated "Libellé voie".
   * 
   * @return translated "Libellé voie"
   */
  @DefaultStringValue("Libellé voie")
  @Key("form.street")
  String form_street();

  /**
   * Translated "Complément adresse".
   * 
   * @return translated "Complément adresse"
   */
  @DefaultStringValue("Complément adresse")
  @Key("form.streetComplement")
  String form_streetComplement();

  /**
   * Translated "Adresse".
   * 
   * @return translated "Adresse"
   */
  @DefaultStringValue("Adresse")
  @Key("form.title.address")
  String form_title_address();

  /**
   * Translated "PC voisin".
   * 
   * @return translated "PC voisin"
   */
  @DefaultStringValue("PC voisin")
  @Key("form.title.closepc")
  String form_title_closepc();

  /**
   * Translated "Coordonnées".
   * 
   * @return translated "Coordonnées"
   */
  @DefaultStringValue("Coordonnées")
  @Key("form.title.coords")
  String form_title_coords();

  /**
   * Translated "Client".
   * 
   * @return translated "Client"
   */
  @DefaultStringValue("Client")
  @Key("form.title.customer")
  String form_title_customer();

  /**
   * Translated "Mise à jour des coordonnées du client".
   * 
   * @return translated "Mise à jour des coordonnées du client"
   */
  @DefaultStringValue("Mise à jour des coordonnées du client")
  @Key("form.title.editcustomer")
  String form_title_editcustomer();

  /**
   * Translated "Mise à jour des coordonnées du PC".
   * 
   * @return translated "Mise à jour des coordonnées du PC"
   */
  @DefaultStringValue("Mise à jour des coordonnées du PC")
  @Key("form.title.editpc")
  String form_title_editpc();

  /**
   * Translated "PC".
   * 
   * @return translated "PC"
   */
  @DefaultStringValue("PC")
  @Key("form.title.pc")
  String form_title_pc();

  /**
   * Translated "RE".
   * 
   * @return translated "RE"
   */
  @DefaultStringValue("RE")
  @Key("form.title.re")
  String form_title_re();

  /**
   * Translated "SR".
   * 
   * @return translated "SR"
   */
  @DefaultStringValue("SR")
  @Key("form.title.sr")
  String form_title_sr();

  /**
   * Translated "Caractéristiques techniques".
   * 
   * @return translated "Caractéristiques techniques"
   */
  @DefaultStringValue("Caractéristiques techniques")
  @Key("form.title.tech")
  String form_title_tech();

  /**
   * Translated "Permission de géolocalisation refusée.".
   * 
   * @return translated "Permission de géolocalisation refusée."
   */
  @DefaultStringValue("Permission de géolocalisation refusée.")
  @Key("geolocRefused")
  String geolocRefused();

  /**
   * Translated "Chargement...".
   * 
   * @return translated "Chargement..."
   */
  @DefaultStringValue("Chargement...")
  @Key("header.loading")
  String header_loading();

  /**
   * Translated "se déconnecter".
   * 
   * @return translated "se déconnecter"
   */
  @DefaultStringValue("se déconnecter")
  @Key("header.logout")
  String header_logout();

  /**
   * Translated "Contact".
   * 
   * @return translated "Contact"
   */
  @DefaultStringValue("Contact")
  @Key("img.alt.contact")
  String img_alt_contact();

  /**
   * Translated "Chargement".
   * 
   * @return translated "Chargement"
   */
  @DefaultStringValue("Chargement")
  @Key("img.alt.loading")
  String img_alt_loading();

  /**
   * Translated "Logo Orange".
   * 
   * @return translated "Logo Orange"
   */
  @DefaultStringValue("Logo Orange")
  @Key("img.alt.logoOrange")
  String img_alt_logoOrange();

  /**
   * Translated "Requis".
   * 
   * @return translated "Requis"
   */
  @DefaultStringValue("Requis")
  @Key("img.alt.required")
  String img_alt_required();

  /**
   * Translated "Haut de page".
   * 
   * @return translated "Haut de page"
   */
  @DefaultStringValue("Haut de page")
  @Key("img.alt.topPage")
  String img_alt_topPage();

  /**
   * Translated "Attention".
   * 
   * @return translated "Attention"
   */
  @DefaultStringValue("Attention")
  @Key("img.alt.warning")
  String img_alt_warning();

  /**
   * Translated "Attention, problème dans le géocodage de l'adresse de ce client".
   * 
   * @return translated "Attention, problème dans le géocodage de l'adresse de ce client"
   */
  @DefaultStringValue("Attention, problème dans le géocodage de l'adresse de ce client")
  @Key("intervention.confidence")
  String intervention_confidence();

  /**
   * Translated "Adresse client manquante pour intervention".
   * 
   * @return translated "Adresse client manquante pour intervention"
   */
  @DefaultStringValue("Adresse client manquante pour intervention")
  @Key("intervention.noaddress")
  String intervention_noaddress();

  /**
   * Translated "Code postal inconnu pour l'intervention".
   * 
   * @return translated "Code postal inconnu pour l'intervention"
   */
  @DefaultStringValue("Code postal inconnu pour l'intervention")
  @Key("intervention.nocp")
  String intervention_nocp();

  /**
   * Translated "Chemin de fer introuvable pour l'intervention".
   * 
   * @return translated "Chemin de fer introuvable pour l'intervention"
   */
  @DefaultStringValue("Chemin de fer introuvable pour l'intervention")
  @Key("intervention.nodetail")
  String intervention_nodetail();

  /**
   * Translated "Impossible de localiser l'adresse client pour l'intervention".
   * 
   * @return translated "Impossible de localiser l'adresse client pour l'intervention"
   */
  @DefaultStringValue("Impossible de localiser l'adresse client pour l'intervention")
  @Key("intervention.nogeoloc")
  String intervention_nogeoloc();

  /**
   * Translated "Erreur de configuration des formulaires".
   * 
   * @return translated "Erreur de configuration des formulaires"
   */
  @DefaultStringValue("Erreur de configuration des formulaires")
  @Key("json.error")
  String json_error();

  /**
   * Translated "Aucun PC proche trouvé".
   * 
   * @return translated "Aucun PC proche trouvé"
   */
  @DefaultStringValue("Aucun PC proche trouvé")
  @Key("no.close.pc")
  String no_close_pc();

  /**
   * Translated "Impossible de trouver votre position actuelle".
   * 
   * @return translated "Impossible de trouver votre position actuelle"
   */
  @DefaultStringValue("Impossible de trouver votre position actuelle")
  @Key("nogeoloc")
  String nogeoloc();

  /**
   * Translated "La position géographique du PC a bien été modifiée en base".
   * 
   * @return translated "La position géographique du PC a bien été modifiée en base"
   */
  @DefaultStringValue("La position géographique du PC a bien été modifiée en base")
  @Key("pc.moved")
  String pc_moved();

  /**
   * Translated "Les modifications du pc ont été sauvées en base. Elle seront visibles dans 42C d'ici quelques jours.".
   * 
   * @return translated "Les modifications du pc ont été sauvées en base. Elle seront visibles dans 42C d'ici quelques jours."
   */
  @DefaultStringValue("Les modifications du pc ont été sauvées en base. Elle seront visibles dans 42C d'ici quelques jours.")
  @Key("pc.updated")
  String pc_updated();

  /**
   * Translated "Erreur lors de la sauvegarde des modifications du PC en base".
   * 
   * @return translated "Erreur lors de la sauvegarde des modifications du PC en base"
   */
  @DefaultStringValue("Erreur lors de la sauvegarde des modifications du PC en base")
  @Key("pc.updated.error")
  String pc_updated_error();

  /**
   * Translated "Faites glisser l'icône sur la carte pour modifier la position du PC. Appuyez sur Enregistrer pour valider la nouvelle position.\n\nLa modification sera reportée dans 42C d'ici quelques jours.".
   * 
   * @return translated "Faites glisser l'icône sur la carte pour modifier la position du PC. Appuyez sur Enregistrer pour valider la nouvelle position.\n\nLa modification sera reportée dans 42C d'ici quelques jours."
   */
  @DefaultStringValue("Faites glisser l'icône sur la carte pour modifier la position du PC. Appuyez sur Enregistrer pour valider la nouvelle position.\n\nLa modification sera reportée dans 42C d'ici quelques jours.")
  @Key("pcMove.text")
  String pcMove_text();

  /**
   * Translated "Mise à jour position PC".
   * 
   * @return translated "Mise à jour position PC"
   */
  @DefaultStringValue("Mise à jour position PC")
  @Key("pcMove.title")
  String pcMove_title();

  /**
   * Translated "Confirmation".
   * 
   * @return translated "Confirmation"
   */
  @DefaultStringValue("Confirmation")
  @Key("popin.confirmation.title")
  String popin_confirmation_title();

  /**
   * Translated "Déconnexion".
   * 
   * @return translated "Déconnexion"
   */
  @DefaultStringValue("Déconnexion")
  @Key("popin.deconnexion.title")
  String popin_deconnexion_title();

  /**
   * Translated "Attention".
   * 
   * @return translated "Attention"
   */
  @DefaultStringValue("Attention")
  @Key("popin.error.title")
  String popin_error_title();

  /**
   * Translated "Attention".
   * 
   * @return translated "Attention"
   */
  @DefaultStringValue("Attention")
  @Key("popin.warning.title")
  String popin_warning_title();

  /**
   * Translated "Utiliser votre position actuelle à l'aide du GPS".
   * 
   * @return translated "Utiliser votre position actuelle à l'aide du GPS"
   */
  @DefaultStringValue("Utiliser votre position actuelle à l'aide du GPS")
  @Key("posMethod.gps")
  String posMethod_gps();

  /**
   * Translated "Positionner manuellement sur la carte".
   * 
   * @return translated "Positionner manuellement sur la carte"
   */
  @DefaultStringValue("Positionner manuellement sur la carte")
  @Key("posMethod.hand")
  String posMethod_hand();

  /**
   * Translated "Choisissez la méthode".
   * 
   * @return translated "Choisissez la méthode"
   */
  @DefaultStringValue("Choisissez la méthode")
  @Key("posMethod.title")
  String posMethod_title();

  /**
   * Translated "page d'erreur".
   * 
   * @return translated "page d'erreur"
   */
  @DefaultStringValue("page d'erreur")
  @Key("title.error")
  String title_error();

  /**
   * Translated "Bienvenue sur le Proto SIG !".
   * 
   * @return translated "Bienvenue sur le Proto SIG !"
   */
  @DefaultStringValue("Bienvenue sur le Proto SIG !")
  @Key("title.welcome")
  String title_welcome();
}
