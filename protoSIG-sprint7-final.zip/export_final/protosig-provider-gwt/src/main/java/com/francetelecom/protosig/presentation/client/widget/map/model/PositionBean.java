package com.francetelecom.protosig.presentation.client.widget.map.model;

import java.io.Serializable;

/**
 * PositionBean
 * 
 * @author JLZB1407
 * 
 */
public class PositionBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3127735357393019392L;

	/**
	 * empty id value
	 */
	public static final String ID_EMPTY = null;

	/**
	 * mandatory technical id
	 * 
	 */
	private Long id;

	/**
	 * Position on the map
	 */
	private Location location;

	/**
	 * user readable output
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("bean : ");
		sb.append("id=").append(id);

		return (sb.toString());
	}

	@Override
	public boolean equals(Object object) {
		return getId() != null ? object != null
				&& getClass() == object.getClass()
				&& getId().equals(((PositionBean) object).getId()) : super
				.equals(object);
	}

	@Override
	public int hashCode() {
		return getId() != null ? getId().hashCode() : super.hashCode();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public PositionBean() {
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

}
