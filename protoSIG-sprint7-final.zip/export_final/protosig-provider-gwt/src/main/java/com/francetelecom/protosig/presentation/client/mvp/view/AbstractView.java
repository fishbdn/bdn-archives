package com.francetelecom.protosig.presentation.client.mvp.view;

import com.google.gwt.user.client.ui.IsWidget;

/**
 * Base class for all views.
 * 
 */
public interface AbstractView extends IsWidget {
}
