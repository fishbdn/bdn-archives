package com.francetelecom.protosig.presentation.client.exception;

import com.francetelecom.protosig.model.exception.ClientException;

/**
 * A client-side exception resulting in a message displayed to the user
 * 
 * @author jcwilk
 * 
 */
public class ClientFunctionalException extends ClientException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 214219794085800433L;

	/* error codes. associated message must be defined in Constantes */
	public static final String BAD_INPUT_DATA = "error_badInputData";
	public static final String NO_HTML5 = "error_noHtml5";
	public static final String NO_LOCAL_STORAGE = "error_noLocalStorage";

	/**
	 * Constructor
	 * 
	 * @param errorCode
	 */
	public ClientFunctionalException(String errorCode) {
		super(errorCode);
	}

}
