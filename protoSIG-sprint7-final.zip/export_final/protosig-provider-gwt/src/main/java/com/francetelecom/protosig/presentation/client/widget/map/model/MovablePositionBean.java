package com.francetelecom.protosig.presentation.client.widget.map.model;

import java.io.Serializable;

/**
 * A bean that can be moved (and must store its original position to display a ghost pushpin)
 * @author jcwilk
 *
 */
public class MovablePositionBean extends PositionBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6485802160168143047L;
	/**
	 * Original position on the map
	 */
	private Location originalLocation;
	private Location lambertLocation;


	public Location getOriginalLocation() {
		return originalLocation;
	}

	public void setOriginalLocation(Location originalLocation) {
		this.originalLocation = originalLocation;
	}
	public Double getOriginalX() {
		return originalLocation == null ? null : originalLocation.getX();
	}
	public Double getOriginalY() {
		return originalLocation == null ? null : originalLocation.getY();
	}
	public void setOriginalX(Double x) {
		if ( originalLocation == null ) {
			originalLocation = new Location(0,0);
		}
		originalLocation.setX(x);
	}
	public void setOriginalY(Double y) {
		if ( originalLocation == null ) {
			originalLocation = new Location(0,0);
		}
		originalLocation.setY(y);
	}

	public Location getLambertLocation() {
		return lambertLocation;
	}


	public void setLambertLocation(Location lambertLocation) {
		this.lambertLocation = lambertLocation;
	}
}
