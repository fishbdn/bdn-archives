package com.francetelecom.protosig.presentation.client.mvp.model.autobean;

import com.google.web.bindery.autobean.shared.AutoBean;
import com.google.web.bindery.autobean.shared.AutoBeanFactory;

/**
 * Factory for automated json decoding using google AutoBeanCodex
 * @author jcwilk
 *
 */
public interface ISigAutoBeanFactory extends AutoBeanFactory {
	AutoBean<IAgenda> agenda();
	AutoBean<IIntervention> intervention(); 
	AutoBean<INodeClientData> inode();
	AutoBean<ISigData> sigData();
	AutoBean<ISigInterventionData> sigInterventionData();
}
