package com.francetelecom.protosig.presentation.client.mvp.view.impl;

import java.util.List;

import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.eventbus.event.InterventionGeocodingEvent;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.view.SideBarView;
import com.francetelecom.protosig.presentation.client.widget.AgendaWidget;
import com.francetelecom.protosig.presentation.client.widget.ClosePcDetailWidget;
import com.francetelecom.protosig.presentation.client.widget.InterventionDetailWidget;
import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * Basic Desktop {@link SideBarView} implementation.
 */
public class SideBarViewImpl extends AbstractViewImpl implements SideBarView {

	// CHECKSTYLE:OFF
	@UiField
	protected FlowPanel header;
	@UiField
	protected AgendaWidget agendaWidget;
	@UiField
	protected InterventionDetailWidget interDetailWidget;
	@UiField
	protected ClosePcDetailWidget closePcDetailWidget;

	// CHECKSTYLE:ON

	interface HeaderUiBinder extends UiBinder<Widget, SideBarViewImpl> {
	}

	private static HeaderUiBinder uiBinder = GWT.create(HeaderUiBinder.class);

	/**
	 * Header constructor.
	 */
	public SideBarViewImpl() {
		initWidget(uiBinder.createAndBindUi(this));
	}

	@Override
	public void setAgenda(List<InterventionBean> interventions) {
		if ( ! agendaWidget.isInitialized() ) {
			// build the agenda from interventions list
			agendaWidget.init(interventions);
		}
		agendaWidget.setVisible(true);
		interDetailWidget.setVisible(false);	
		closePcDetailWidget.setVisible(false);
	}

	@Override
	public void setInterventionDetail(InterventionBean inter, int deviceIndex) {
		// click on a customer in the daily round view : detailIntervention is null => do nothing
		if ( inter.getDetailIntervention() != null ) {
			agendaWidget.setVisible(false);
			interDetailWidget.setIntervention(inter, deviceIndex);
			interDetailWidget.setVisible(true);
			closePcDetailWidget.setVisible(false);
		}
	}

	@Override
	public void setInterventionConfidence(Integer data, InterventionGeocodingEvent.Level level) {
		agendaWidget.setInterventionConfidence(data,level);		
	}

	@Override
	public void setClosePcDetail(Long index, PcDto pc) {
		agendaWidget.setVisible(false);
		closePcDetailWidget.update(index,pc);
		interDetailWidget.setVisible(false);		
		closePcDetailWidget.setVisible(true);
	}



}