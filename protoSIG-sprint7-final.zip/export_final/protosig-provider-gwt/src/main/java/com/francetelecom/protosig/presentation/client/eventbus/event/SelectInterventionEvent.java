package com.francetelecom.protosig.presentation.client.eventbus.event;



/**
 * Event triggered when an intervention is selected or deselected in the agenda
 * @author jcwilk
 *
 */
public class SelectInterventionEvent extends GenericEvent<Integer> {
	private final boolean selected;
	public SelectInterventionEvent(Integer interventionIndex, boolean selected) {
		super(GenericEvent.Type.INTER_SELECT, interventionIndex);
		this.selected=selected;
	}
	public boolean isSelected() {
		return selected;
	}
	
}
