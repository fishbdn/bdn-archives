package com.francetelecom.protosig.presentation.client.mvp.view;

import com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget;

public interface MapView extends AbstractView {

	AbstractMapWidget getMap();

}
