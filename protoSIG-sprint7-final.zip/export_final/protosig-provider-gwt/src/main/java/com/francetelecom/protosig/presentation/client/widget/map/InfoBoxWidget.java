package com.francetelecom.protosig.presentation.client.widget.map;

import com.francetelecom.protosig.presentation.client.widget.map.model.PositionBean;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.user.client.ui.Composite;

/**
 * Infobox
 * 
 * @author JLZB1407
 * 
 */
public abstract class InfoBoxWidget<T extends PositionBean> extends
		Composite {

	private T bean;

	protected abstract void setBean(T bean);

	protected void preventEventsPropagationOnMap() {

		this.addDomHandler(new MouseDownHandler() {
			@Override
			public void onMouseDown(MouseDownEvent event) {
				event.stopPropagation();
			}
		}, MouseDownEvent.getType());
	}

	public T getBean() {
		return bean;
	}
	
}
