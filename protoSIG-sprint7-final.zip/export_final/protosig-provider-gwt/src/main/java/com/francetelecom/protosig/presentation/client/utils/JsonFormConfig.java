package com.francetelecom.protosig.presentation.client.utils;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.mvp.place.ErrorPlace;
import com.google.gwt.core.client.GWT;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.web.bindery.autobean.shared.AutoBean;
import com.google.web.bindery.autobean.shared.AutoBeanCodex;
import com.google.web.bindery.autobean.shared.AutoBeanFactory;

public class JsonFormConfig {
	/**
	 * Configuration data for a form field : code : label is read from
	 * Constantes.properties with name form.&lt;code&gt; path : value's path in
	 * the local storage intervention node must be public for GWT compiler
	 * 
	 * @author jcwilk
	 * 
	 */
	public interface IFieldData {
		String getCode();
		void setCode(String code);

		String getPath();
		void setPath(String path);
		
		// bug in autobean if using Boolean
		String getDetail();
		void setDetail(String flags);
	};
	
	/**
	 * Cannot use a Map<String, List<x>> with autobeans. List needs to be wrapped.
	 * @author jcwilk
	 *
	 */
	public interface IFieldList {
		List<IFieldData> getList();
		void setList(List<IFieldData> list);
	}

	/**
	 * Form configuration read from jsonForms.json must be public for GWT
	 * compiler
	 * 
	 * @author jcwilk
	 * 
	 */
	public interface IFormConfig {
		/**
		 * Bug in autobean if using a List<IFieldData>
		 */
		Map<String, IFieldList> getConfig();
	};

	/**
	 * Autobean factory. must be public for GWT compiler
	 * 
	 * @author jcwilk
	 * 
	 */
	public interface IFormConfigFactory extends AutoBeanFactory {
		AutoBean<IFormConfig> getConfig();
	}

	private final IFormConfigFactory factory = GWT
			.create(IFormConfigFactory.class);
	private IFormConfig config = null;
	
	/**
	 * Constructor.
	 * Get the json file from server and parse it
	 * 
	 */
	public JsonFormConfig() {
		// get json file
		RequestBuilder rb = new RequestBuilder(RequestBuilder.GET,
				"json/jsonForms.json?t=" + new Date().getTime());
		rb.setCallback(new RequestCallback() {

			@Override
			public void onResponseReceived(Request request, Response response) {
				// and parse it
				setConfig(response.getText());
			}

			@Override
			public void onError(Request request, Throwable exception) {
				Application.CLIENT_FACTORY.getPlaceController().goTo(
						new ErrorPlace(exception));
			}

		});
		try {
			rb.send();
		} catch (RequestException e) {
			Application.CLIENT_FACTORY.getPlaceController().goTo(
					new ErrorPlace(e));
		}
	}
	

	/**
	 * Parse form configuration from json
	 * 
	 * @param jsonConfig
	 */
	private void setConfig(String jsonConfig) {
		AutoBean<IFormConfig> bean = AutoBeanCodex.decode(factory,
				IFormConfig.class, jsonConfig);
		config = bean.as();
	}


	public Map<String, IFieldList> getConfig() {
		return config == null ? null : config.getConfig();
	}
	
}
