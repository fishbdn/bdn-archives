package com.francetelecom.protosig.presentation.client.factory;

import java.util.Map;

import com.francetelecom.protosig.presentation.client.eventbus.JsonEventBus;
import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.presenter.FooterPresenter;
import com.francetelecom.protosig.presentation.client.mvp.presenter.MapPresenter;
import com.francetelecom.protosig.presentation.client.mvp.presenter.SideBarPresenter;
import com.francetelecom.protosig.presentation.client.mvp.view.ErrorView;
import com.francetelecom.protosig.presentation.client.mvp.view.FooterView;
import com.francetelecom.protosig.presentation.client.mvp.view.MapView;
import com.francetelecom.protosig.presentation.client.mvp.view.SideBarView;
import com.francetelecom.protosig.presentation.client.rpc.SigServiceAsync;
import com.francetelecom.protosig.presentation.client.ui.SiteUI;
import com.francetelecom.protosig.presentation.client.utils.JsonFormConfig.IFieldList;
import com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage;
import com.google.gwt.place.shared.PlaceController;
import com.google.web.bindery.event.shared.EventBus;

/**
 * A ClientFactory is not strictly required in GWT 2.1; however, it is helpful
 * to use a factory or dependency injection framework like GIN to obtain
 * references to objects needed throughout your application like the event bus.
 * Our example uses a ClientFactory to provide an EventBus, GWT PlaceController,
 * and view implementations. Another advantage of using a ClientFactory is that
 * you can use it with GWT deferred binding to use different implementation
 * classes based on user.agent or other properties. For example, you might use a
 * MobileClientFactory to provide different view implementations than the
 * default desktop ClientFactoryImpl. To do this, instantiate your ClientFactory
 * with GWT.create in onModuleLoad()
 * 
 */
public interface ClientFactory {

	// general stuff

	EventBus getEventBus();

	JsonEventBus getJsonEventBus();

	PlaceController getPlaceController();

	SiteUI getSiteUI();

	ILocalStorage getLocalStorage() throws ClientFunctionalException;
	
	InterventionBeanFactory getInterventionBeanFactory();
	
	Map<String, IFieldList> getJsonFormConfig();

	// presenters

	SideBarPresenter getSideBarPresenter();

	FooterPresenter getFooterPresenter();

	MapPresenter getMapPresenter();

	// views

	SideBarView getHeaderView();

	FooterView getFooterView();

	MapView getMapView();

	ErrorView getErrorView();

	// RPC services

	SigServiceAsync getSigService();

}
