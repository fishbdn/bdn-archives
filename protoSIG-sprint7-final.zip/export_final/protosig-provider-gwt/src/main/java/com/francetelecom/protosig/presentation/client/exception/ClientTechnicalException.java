package com.francetelecom.protosig.presentation.client.exception;

import com.francetelecom.protosig.model.exception.ClientException;

/**
 * A client-side exception resulting in a stack trace displayed to the user
 * 
 * @author jcwilk
 * 
 */
public class ClientTechnicalException extends ClientException {


	/**
	 * 
	 */
	private static final long serialVersionUID = -7221386830660249017L;
	/**
	 * Constructor
	 * 
	 * @param errorCode
	 */
	public ClientTechnicalException(String errorCode) {
		super(errorCode);
	}

}
