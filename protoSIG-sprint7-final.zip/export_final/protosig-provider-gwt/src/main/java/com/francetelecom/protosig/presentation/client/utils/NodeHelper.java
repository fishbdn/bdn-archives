package com.francetelecom.protosig.presentation.client.utils;

import java.util.Map;

import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;

/**
 * Helper functions to get data from a INodeClientData tree
 * @author jcwilk
 *
 */
public final class NodeHelper {
	
	/**
	 * hiden constructor
	 */
	private NodeHelper() {		
	}
	
	/**
	 * Return a node in the client data tree
	 * 
	 * @param root
	 *            the tree root node
	 * @param xpath
	 *            the path to the node
	 * @param withLeaf
	 * 			  if false, ignore the last section of the xpath
	 * @return the node or null
	 */
	public static INodeClientData getNode(INodeClientData root, String xpath, boolean withLeaf) {
		String[] nodes = xpath.split("/");
		INodeClientData current = root;
		int end=withLeaf ? nodes.length : nodes.length-1;
		for (int i = 0; i < end; i++) {
			if (current.getChildBlock() != null
					&& current.getChildBlock().get(nodes[i]) != null) {
				current = current.getChildBlock().get(nodes[i]);
			} else {
				// path not found
				return null;
			}
		}
		return current;
	}
	


	/**
	 * GEt a value from the client data tree
	 * 
	 * @param root
	 *            root node of the tree
	 * @param xpath
	 *            path to the leaf
	 * @return string value of the leaf or null
	 */
	public static String getLeaf(INodeClientData root, String xpath) {
		INodeClientData node = getNode(root, xpath,false);
		if (node == null) {
			return null;
		}
		Map<String, String> data = node.getData();
		if (data == null) {
			// path not found
			return null;
		}
		return data.get(xpath.substring(xpath.lastIndexOf('/') + 1));
	}
}
