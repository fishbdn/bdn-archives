package com.francetelecom.protosig.presentation.client.utils;

import java.util.Date;

import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;

public final class DateUtils {
	/**
	 * hidden constructor
	 */
	private DateUtils() {}
	
	public static final long MILLI_PER_MINUTE = 1000 * 60L;
	public static final long MILLI_PER_HOUR = MILLI_PER_MINUTE * 60;
	public static final long MILLI_PER_HALF_HOUR = MILLI_PER_HOUR/2;
	public static final long MILLI_PER_DAY = MILLI_PER_HOUR * 24;
	// No Calendar in GWT JRE
	@SuppressWarnings("deprecation")
	public static final int TIMEZONE_OFFSET_MINUTES=new Date().getTimezoneOffset();
	
	/**
	 * Return time for the start of current day (milliseconds since 1 Jan 1970 GMT)
	 * 
	 * @return
	 */
	public static long getTruncatedDayCurrentTime() {
		Date currentDate=new Date();
		long current = currentDate.getTime();
		return getTruncatedDayTime(current);
	}

	/**
	 * Remove hour,minutes,seconds, milliseconds from someTime
	 * 
	 * @param someTime
	 * @return
	 */
	public static long getTruncatedDayTime(long someTime) {
		long newTime = someTime;
		newTime /= MILLI_PER_DAY;
		newTime *= MILLI_PER_DAY;
		return newTime;

	}

	/**
	 * Return hour from some time
	 * 
	 * @param someTime
	 * @return
	 */
	public static int getHour(long someTime) {
		long newTime = someTime;
		newTime -= getTruncatedDayTime(newTime);
		// no conversion needed on orange environment
		//newTime=convertGMTToLocal(newTime);
		newTime /= MILLI_PER_HOUR;
		return (int) newTime;
	}

	/**
	 * Return number of half hours since midnight 
	 * 
	 * @param someTime
	 * @return
	 */
	public static int getHalfHour(long someTime) {
		long newTime = someTime;
		newTime -= getTruncatedDayTime(newTime);
		// no conversion needed on orange environment
		//newTime=convertGMTToLocal(newTime);
		newTime /= MILLI_PER_HALF_HOUR;
		return (int) newTime;
	}
	
	/**
	 * Convert a local time into a GMT time
	 * @param someTime
	 * @return
	 */
	public static long convertLocalToGMT(long someTime) {
		return someTime - TIMEZONE_OFFSET_MINUTES*MILLI_PER_MINUTE;
	}

	/**
	 * Convert a GMT time into a local time
	 * @param someTime
	 * @return
	 */
	public static long convertGMTToLocal(long someTime) {
		return someTime + TIMEZONE_OFFSET_MINUTES*MILLI_PER_MINUTE;
	}

	/**
	 * Return true if the date belongs to the current day
	 * 
	 * @param someTime
	 * @return
	 */
	public static boolean isToday(long someTime) {
		return getTruncatedDayTime(someTime) == getTruncatedDayCurrentTime();
	}

	/**
	 * Return current date. Example : "Mardi 26 Fevrier"
	 * @return
	 */
	public static String getCurrentDateLong() {
		return DateTimeFormat.getFormat(PredefinedFormat.DATE_LONG)
				.format(new Date());
	}
	
}
