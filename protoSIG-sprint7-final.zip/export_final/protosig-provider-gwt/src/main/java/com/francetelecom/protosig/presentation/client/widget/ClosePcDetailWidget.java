package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailClosePCEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.MapAgendaEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.SwitchDragAndDropEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.UIModeEvent;
import com.francetelecom.protosig.presentation.client.rpc.GenericMessageCallback;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class ClosePcDetailWidget extends AbstractMethodChooseWidget {

	private static InterventionDetailWidgetUiBinder uiBinder = GWT
			.create(InterventionDetailWidgetUiBinder.class);

	interface InterventionDetailWidgetUiBinder extends
			UiBinder<Widget, ClosePcDetailWidget> {
	}

	// CHECKSTYLE:OFF
	@UiField
	protected Button refreshButton;
	@UiField
	protected Label titleLabel;
	@UiField
	protected Button backButton;
	@UiField
	protected Button prevButton;
	@UiField
	protected Button nextButton;
	@UiField
	protected Button clientPosButton;
	@UiField
	protected Button editButton;
	@UiField
	protected Button saveButton;
	@UiField
	protected Button cancelButton;	
	@UiField
	protected Button tamButton;
	@UiField
	protected FlowPanel legendPanel;
	@UiField
	protected Image legend;
	@UiField
	protected Button legendButton;
	@UiField
	protected Button localizeButton;
	@UiField
	protected Label referenceValue;
	@UiField
	protected Label addressValue;
	@UiField
	protected Label descTechValue;
	@UiField
	protected Label commentValue;
	@UiField
	protected Label centreValue;
	@UiField
	protected Label zoneValue;
	@UiField
	protected Label typeValue;
	@UiField
	protected Label dispoValue;
	// CHECKSTYLE:ON

	private boolean legendIsOpen = true;
	/**
	 * Current pc
	 */
	private PcDto pc;
	private long currentIndex;
	/**
	 * TAM dialog box
	 */
	protected TamWidget tamBox;
	
	public ClosePcDetailWidget() {
		initWidget(uiBinder.createAndBindUi(this));
		// center the map
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						GenericEvent.Type.RESET_MAP_ZOOM);
			}
		});
		// go back to agenda view
		backButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if ( tamBox != null ) {
					tamBox.hide();
				}
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new MapAgendaEvent(null));
			}
		});
		// display user position
		localizeButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						GenericEvent.Type.DISPLAY_USER_POS);
			}
		});
		legend.setUrl(GWT.getHostPageBaseURL() + "images/legend2.png");
		// open / close legend
		legendButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				if (legendIsOpen) {
					closeLegend();
				} else {
					openLegend();
				}
			}
		});
		// next pc button
		nextButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(new DetailClosePCEvent(currentIndex+1));
			}
		});
		// previous pc button
		prevButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(new DetailClosePCEvent(currentIndex-1));
			}
		});
		// display TAM screen
		tamButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				hideShowTamDialog();
			}
		});
		// display pc form 
		editButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				// display edit pc form
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new UIModeEvent(pc));
			}
		});
		// enable pc drag and drop
		clientPosButton.addClickHandler(moveHandler);
		// cancel drag and drop action
		cancelButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new SwitchDragAndDropEvent(pc, null,
								null, true));
				update(currentIndex,pc);
			}
		});
		// validate drag and drop action
		saveButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new SwitchDragAndDropEvent(pc, null,
								null, false));
				update(currentIndex,pc);
				// save new pc position in database
				// primary key = 42C base code + PN reference
				String id = pc.getDr() + "|"
						+ pc.getName();
				Application.CLIENT_FACTORY.getSigService().savePcLocation(id, 
						pc.getOriginalX(),
						pc.getOriginalY(),
						pc.getX(), 
						pc.getY(), 
						new GenericMessageCallback<Void>(
								Application.CONSTANTS.pc_moved(),
								Application.CONSTANTS.pc_updated_error()));
			}
		});
		
	}
	@Override
	protected void enableDragAndDrop(Double x, Double y) {
		// enable drag and drop listening on the customer or pc
		// pushpin
//		setHelpScreen(Application.CONSTANTS.pcMove_title(), PC_DRAG_ICON,
//				Application.CONSTANTS.pcMove_text());
		clientPosButton.setVisible(false);
		editButton.setVisible(false);
		tamButton.setVisible(false);
		saveButton.setVisible(true);
		cancelButton.setVisible(true);		
		pc.setOriginalX(pc.getX());
		pc.setOriginalY(pc.getY());
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				new SwitchDragAndDropEvent(pc, x, y, false));
	}
	
	// TODO factorize legend with AgendaWidget
	private void openLegend() {
		// legend animation uses CSS3 transition on top css property
		legendPanel.addStyleName("open");
		legendIsOpen = true;
	}

	private void closeLegend() {
		legendPanel.removeStyleName("open");
		legendIsOpen = false;
	}

	public void update(long index, PcDto pc) {
		this.pc=pc;
		clientPosButton.setVisible(true);
		editButton.setVisible(true);
		tamButton.setVisible(true);
		saveButton.setVisible(false);
		cancelButton.setVisible(false);		
		if ( pc != null ) {
			currentIndex=index;
			titleLabel.setText(Application.CONSTANTS.form_title_closepc()+" "+index);
			referenceValue.setText(pc.getName());
			addressValue.setText(pc.getAddress());
			descTechValue.setText(pc.getDescTech());
			commentValue.setText(pc.getComment());
			centreValue.setText(pc.getCentreCode());
			zoneValue.setText(pc.getName().length()>10 ? pc.getName().substring(3, 10):pc.getZoneCode());
			typeValue.setText(pc.getCategory());			
			dispoValue.setText(String.valueOf(pc.getNbAvailablePairs()));
			if ( tamBox != null ){
				tamBox.setPc(pc,0);
			}
		}
	}

	private void hideShowTamDialog() {
		if ( tamBox == null ) {
			tamBox=new TamWidget();
			tamBox.setPc(pc,0);
			tamBox.show();
		} else if ( tamBox.isShowing() ) {
			tamBox.hide();
		} else {
			tamBox.show();
		}
	}	
}
