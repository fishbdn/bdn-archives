package com.francetelecom.protosig.presentation.client.eventbus.event;

import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;



/**
 * Event triggered to enable or disable drag and drop on a customer or PC pushpin.
 * 
 * if device is null, the pushpin is the customer for the intervention
 * @author jcwilk
 *
 */
public class SwitchDragAndDropEvent extends GenericEvent<InterventionBean> {
	private final NetworkDeviceBean device;
	private final PcDto pc;
	private final boolean cancel;
	/**
	 * Where to move the pushpin before enabling drag and drop.
	 * If null, don't move the pushpin
	 */
	private final Double x,y;
	/**
	 * Turn drag and drop either on or off depending on current state
	 * @param inter the intervention
	 * @param device the device or null if the element is the customer
	 * @param x where to move the pushpin before enabling drag and drop
	 * @param y where to move the pushpin before enabling drag and drop
	 * @param cancel if true, reset the element's position
	 */
	public SwitchDragAndDropEvent(InterventionBean inter, NetworkDeviceBean device, Double x, Double y, boolean cancel) {
		super(GenericEvent.Type.SWITCH_DND, inter);
		this.device=device;
		this.cancel=cancel;
		this.pc=null;
		this.x=x;
		this.y=y;
	}
	public SwitchDragAndDropEvent(PcDto pc, Double x, Double y, boolean cancel) {
		super(GenericEvent.Type.SWITCH_DND, null);
		this.device=null;
		this.pc=pc;
		this.cancel=cancel;
		this.x=x;
		this.y=y;
	}
	public NetworkDeviceBean getDevice() {
		return device;
	}
	public boolean isCancel() {
		return cancel;
	}
	public Double getX() {
		return x;
	}
	public Double getY() {
		return y;
	}
	public PcDto getPc() {
		return pc;
	}
	
}
