package com.francetelecom.protosig.presentation.client.mvp.model;

import java.util.List;

import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IIntervention;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;
import com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin;
import com.francetelecom.protosig.presentation.client.widget.map.model.MovablePositionBean;

public class InterventionBean extends MovablePositionBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -865858653371790250L;
	/**
	 * Intervention index (first of the day = 1)
	 */
	private int index;
	private String etechReference;
	private String center;
	private String zone;
	private String activity;
	private String product;
	private String interventionState;
	private Long timeStart;
	private Long timeStop;
	private String inseeCode;
	private String postalCode;
	private String numStreet;
	private String streetName;
	private String cityName;
	private String codeBase;
	private String idIntervention;
	private boolean showDetail;
	private List<NetworkDeviceBean> devices;
	private IIntervention localStorageInter;
	private INodeClientData detailIntervention;
	private Pushpin customerPushpin;
	
	/**
	 * confidence in geocoding. If false, geocoding is not precise
	 */
	private Boolean confidence = true;
	
	public InterventionBean() {
	}
	
	
	public Boolean getConfidence() {
		return confidence;
	}


	public void setConfidence(Boolean confidence) {
		this.confidence = confidence;
	}


	public INodeClientData getDetailIntervention() {
		return detailIntervention;
	}

	public void setDetailIntervention(INodeClientData detailIntervention) {
		this.detailIntervention = detailIntervention;
	}

	public IIntervention getLocalStorageInter() {
		return localStorageInter;
	}

	public void setLocalStorageInter(IIntervention localStorageInter) {
		this.localStorageInter = localStorageInter;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public List<NetworkDeviceBean> getDevices() {
		return devices;
	}

	public void setDevices(List<NetworkDeviceBean> devices) {
		this.devices = devices;
	}

	public boolean isShowDetail() {
		return showDetail;
	}

	public void setShowDetail(boolean showDetail) {
		this.showDetail = showDetail;
	}

	public String getIdIntervention() {
		return idIntervention;
	}

	public void setIdIntervention(String idIntervention) {
		this.idIntervention = idIntervention;
	}

	public String getCodeBase() {
		return codeBase;
	}

	public void setCodeBase(String codeBase) {
		this.codeBase = codeBase;
	}

	public void setEtechReference(String etechReference) {
		this.etechReference = etechReference;
	}

	public void setCenter(String center) {
		this.center = center;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public void setInterventionState(String interventionState) {
		this.interventionState = interventionState;
	}

	public void setTimeStart(Long timeStart) {
		this.timeStart = timeStart;
	}

	public void setTimeStop(Long timeStop) {
		this.timeStop = timeStop;
	}

	public String getEtechReference() {
		return etechReference;
	}
	public String getCenter() {
		return center;
	}
	public String getZone() {
		return zone;
	}
	public String getActivity() {
		return activity;
	}
	public String getProduct() {
		return product;
	}
	public String getInterventionState() {
		return interventionState;
	}
	public Long getTimeStart() {
		return timeStart;
	}
	public Long getTimeStop() {
		return timeStop;
	}


	public String getNumStreet() {
		return numStreet;
	}


	public void setNumStreet(String numStreet) {
		this.numStreet = numStreet;
	}


	public String getStreetName() {
		return streetName;
	}


	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}


	public String getCityName() {
		return cityName;
	}


	public void setCityName(String cityName) {
		this.cityName = cityName;
	}


	public String getInseeCode() {
		return inseeCode;
	}


	public void setInseeCode(String inseeCode) {
		this.inseeCode = inseeCode;
	}


	public String getPostalCode() {
		return postalCode;
	}


	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public Pushpin getCustomerPushpin() {
		return customerPushpin;
	}


	public void setCustomerPushpin(Pushpin customerPushpin) {
		this.customerPushpin = customerPushpin;
	}



}
