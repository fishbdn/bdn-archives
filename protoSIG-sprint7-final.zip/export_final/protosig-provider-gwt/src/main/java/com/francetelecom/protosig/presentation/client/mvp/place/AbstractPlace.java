/**
 * 
 */
package com.francetelecom.protosig.presentation.client.mvp.place;

import com.google.gwt.place.shared.Place;
import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * @author mlaffargue
 * 
 */
public class AbstractPlace extends Place implements IsSerializable{
	private boolean selfFired = false;

	public boolean isSelfFired() {
		return selfFired;
	}

	public void setSelfFired(boolean selfFired) {
		this.selfFired = selfFired;
	}
}
