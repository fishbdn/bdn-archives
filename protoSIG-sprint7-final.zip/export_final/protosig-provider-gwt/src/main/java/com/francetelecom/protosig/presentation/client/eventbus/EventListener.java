package com.francetelecom.protosig.presentation.client.eventbus;

import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;

/**
 * A class receiving {@link GenericEvent}
 * 
 * @author jcwilk
 * 
 */
public interface EventListener {
	/**
	 * Process an event.
	 * 
	 * @param event
	 */
	void handleEvent(GenericEvent<?> event);
}
