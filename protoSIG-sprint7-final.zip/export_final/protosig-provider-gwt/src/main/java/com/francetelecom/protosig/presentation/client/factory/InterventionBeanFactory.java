package com.francetelecom.protosig.presentation.client.factory;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.WarnEvent;
import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IIntervention;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;
import com.francetelecom.protosig.presentation.client.utils.NodeHelper;
import com.francetelecom.protosig.presentation.client.utils.StringUtils;
import com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage;
import com.francetelecom.protosig.presentation.client.widget.map.GeoTranslator;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;

public class InterventionBeanFactory {
	/**
	 * Create a new intervention
	 * 
	 * @param index
	 *            intervention index in the day
	 * @param inter
	 *            intervention data from local storage
	 * @return the InterventionBean without the NetworkDeviceBean
	 */
	public InterventionBean create(int index, IIntervention inter) {
		InterventionBean bean = new InterventionBean();
		bean.setIndex(index);
		bean.setEtechReference(inter.getEtechReference());
		bean.setCenter(inter.getCenter());
		bean.setZone(inter.getZone());
		bean.setActivity(inter.getActivity());
		bean.setProduct(inter.getProduct());
		bean.setInterventionState(inter.getInterventionState());
		bean.setTimeStart(inter.getTimeStart());
		bean.setTimeStop(inter.getTimeStop());
		bean.setCodeBase(inter.getCodeBase());
		bean.setIdIntervention(inter.getId());
		bean.setLocalStorageInter(inter);
		computeClientAddress(inter, bean);
		return bean;
	}

	/**
	 * Retrieve data from local storage for network devices associated with an
	 * intervention
	 * 
	 * @param interBean
	 * @return filled interBean.devices
	 */
	public List<NetworkDeviceBean> getDetail(InterventionBean interBean) {
		List<NetworkDeviceBean> result = new LinkedList<NetworkDeviceBean>();
		try {
			INodeClientData inter = Application.CLIENT_FACTORY
					.getLocalStorage().getDetailIntervention(
							interBean.getIdIntervention(),
							interBean.getCodeBase());
			INodeClientData ligne = NodeHelper.getNode(inter,
					ILocalStorage.LIST_BLIGNE_XPATH, true);
			interBean.setDetailIntervention(inter);
			// get and parse railroad
			String railroadTypesList = NodeHelper.getLeaf(inter,
					ILocalStorage.RAILROAD_TYPES_XPATH);
			String railroadNamesList = NodeHelper.getLeaf(inter,
					ILocalStorage.RAILROAD_XPATH);
			if (railroadTypesList == null || railroadNamesList == null) {
				throw new ClientFunctionalException(null);
			}
			String[] railroadTypes = railroadTypesList.split(";");
			String[] railroadNames = railroadNamesList.split(";");
			if (railroadTypes.length != railroadNames.length) {
				throw new ClientFunctionalException(null);
			}
			// create device beans for each railroad element
			for (int index = 0; index < railroadTypes.length; index++) {
				String railroadType = railroadTypes[index];
				String railroadName = railroadNames[index];
				getDeviceDetail(index, interBean, railroadType, railroadName,
						ligne, result);
			}
		} catch (ClientFunctionalException e) {
			// ignore
		}
		return result;
	}

	/**
	 * Build client address for geocoding :
	 * "num street, postal code, city, France".
	 * 
	 * @param inter
	 * @param interBean
	 */
	private void computeClientAddress(IIntervention inter,
			InterventionBean interBean) {
		// build customer address
		INodeClientData adresseclientNode = NodeHelper.getNode(inter.getNode(),
				ILocalStorage.CUSTOMER_ADRESS_XPATH, true);

		if (adresseclientNode != null) {
			Map<String, String> addressMap = adresseclientNode.getData();
			// need intervention detail to get postal code
			try {
				INodeClientData detail = Application.CLIENT_FACTORY
						.getLocalStorage().getDetailIntervention(
								interBean.getIdIntervention(),
								interBean.getCodeBase());
				// get insee code and postal code from local storage
				interBean.setInseeCode(NodeHelper.getLeaf(detail,
						ILocalStorage.INSEE_CODE_XPATH));
				interBean.setPostalCode(NodeHelper.getLeaf(detail,
						ILocalStorage.POSTAL_CODE_XPATH));
			} catch (ClientFunctionalException e) {
				// no postal code. display warning but still try to geocode
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new WarnEvent(Application.CONSTANTS.intervention_nocp()
								+ " " + interBean.getIndex()));
			}
			interBean.setNumStreet(addressMap.get("numerovoie"));
			interBean.setStreetName(addressMap.get("libellevoie"));
			interBean.setCityName(addressMap.get("libellecommune"));
		}
	}

	/**
	 * Read two value from the client data tree and build a location from them,
	 * converting coordinates from Lambert2 to WGS84
	 * 
	 * @param node
	 *            tree root
	 * @param xpath
	 *            xpath for the x coordinate
	 * @param ypath
	 *            ypath for the y coordinate
	 * @return a location or null
	 */
	private Location getLocationFromLocalStorage(INodeClientData node,
			String xpath, String ypath) {
		String sx = NodeHelper.getLeaf(node, xpath);
		String sy = NodeHelper.getLeaf(node, ypath);
		if (StringUtils.isEmpty(sx) || StringUtils.isEmpty(sy)) {
			return null;
		}
		Double x = Double.valueOf(sx);
		Double y = Double.valueOf(sy);
		return new Location(x, y);
	}

	/**
	 * Add a new network device in the list if coordinates are found
	 * 
	 * @param index
	 *            device position in the railroad
	 * @param list
	 *            list of network devices
	 * @param deviceType
	 *            type of device to add
	 * @param ligne
	 *            client data tree
	 * @param xPath
	 *            path of the device x coordinate in the tree
	 * @param yPath
	 *            path of the device y coordinate in the tree
	 * @param listIndex
	 *            device position in the listrpc/listrre/... list
	 */
	private NetworkDeviceBean addNetworkDevice(int index, String name,
			List<NetworkDeviceBean> list, NetworkDeviceBean.Type deviceType,
			INodeClientData ligne, String xPath, String yPath, String listIndex) {
		NetworkDeviceBean ret = null;
		String fixedXPath = xPath.replaceAll("\\?", listIndex);
		String fixedYPath = yPath.replaceAll("\\?", listIndex);
		Location lambertLocation = getLocationFromLocalStorage(ligne,
				fixedXPath, fixedYPath);
		if (lambertLocation != null) {
			// convert coordinates
			double[] convertedCoords = GeoTranslator.convertLambert2eToWGS84(
					lambertLocation.getX(), lambertLocation.getY());
			Location wgs84loc = new Location(convertedCoords[0],
					convertedCoords[1]);
			ret = new NetworkDeviceBean(index, name, deviceType, wgs84loc);
			ret.setLambertLocation(lambertLocation);
			list.add(ret);
		}
		return ret;
	}

	/**
	 * Add a networkDeviceBean in the intervention
	 * 
	 * @param index
	 *            network device index in the railroad
	 * @param interBean
	 *            the intervention bean
	 * @param railroadType
	 *            network device type
	 * @param railroadName
	 *            network device name
	 * @param ligne
	 *            local storage node containing the details
	 * @param result
	 *            list of network devices to fill
	 * @throws ClientFunctionalException
	 *             in case local storage is not available
	 */
	private void getDeviceDetail(int index, InterventionBean interBean,
			String railroadType, String railroadName, INodeClientData ligne,
			List<NetworkDeviceBean> result) throws ClientFunctionalException {
		NetworkDeviceBean.Type type = NetworkDeviceBean.Type
				.valueOf(railroadType);
		switch (type) {
		case PC:
			// add PC
			NetworkDeviceBean pc = addNetworkDevice(index, railroadName,
					result, NetworkDeviceBean.Type.PC, ligne,
					ILocalStorage.PC_X_XPATH, ILocalStorage.PC_Y_XPATH, "0");
			// update with data from local storage
			Application.CLIENT_FACTORY.getLocalStorage()
					.updatePC(interBean, pc);
			break;
		case SR:
		case SRI:
		case SRS:
		case SRP:
		case SRZ:
			// add SR
			if (railroadName.indexOf(':') == -1) {
				throw new ClientFunctionalException(null);
			}
			String[] elements = railroadName.split(":");
			addNetworkDevice(index, elements[0], result,
					NetworkDeviceBean.Type.SRP, ligne,
					ILocalStorage.SR_X_XPATH, ILocalStorage.SR_Y_XPATH,
					elements[1]);
			break;
		case REHD:
			// add REHD
			addNetworkDevice(index, railroadName, result,
					NetworkDeviceBean.Type.RE, ligne,
					ILocalStorage.REHD_X_XPATH, ILocalStorage.REHD_Y_XPATH, "0");
			break;
		case RE:
			// add RE
			// sometimes, RE coordinates are in index "0", "1" or "2"...
			if (addNetworkDevice(index, railroadName, result,
					NetworkDeviceBean.Type.RE, ligne, ILocalStorage.RE_X_XPATH,
					ILocalStorage.RE_Y_XPATH, "0") == null) {
				// did not find coordinates in index 0. Try index 1
				if (addNetworkDevice(index, railroadName, result,
						NetworkDeviceBean.Type.RE, ligne, ILocalStorage.RE_X_XPATH,
						ILocalStorage.RE_Y_XPATH, "1") == null) {
					// did not find coordinates in index 1. Try index 2
					addNetworkDevice(index, railroadName, result,
							NetworkDeviceBean.Type.RE, ligne, ILocalStorage.RE_X_XPATH,
							ILocalStorage.RE_Y_XPATH, "2");
				}
			}
			break;
		default:
			// ignore CLI/DTI cutpoints
			break;
		}
	}
}
