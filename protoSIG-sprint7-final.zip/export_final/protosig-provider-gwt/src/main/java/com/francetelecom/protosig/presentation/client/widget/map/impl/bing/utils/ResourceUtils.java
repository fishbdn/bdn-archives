package com.francetelecom.protosig.presentation.client.widget.map.impl.bing.utils;

import java.util.List;

import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.francetelecom.protosig.presentation.client.widget.map.model.MapBox;
import com.francetelecom.protosig.presentation.client.widget.map.model.PositionBean;
import com.google.gwt.core.client.JsArrayNumber;

/**
 * ResourceUtils
 * 
 * @author JLZB1407
 * 
 */
public final class ResourceUtils {
	/**
	 * Prevent someone to instanciate this class
	 */
	private ResourceUtils() {
	}

	public static Location buildLocation(JsArrayNumber point) {
		return new Location(point.get(1), point.get(0));
	}

	private static final double MAPBOX_MARGIN=0.05;
	
	public static MapBox buildMapBox(List<? extends PositionBean> beans) {

		MapBox result = new MapBox();
		for (PositionBean bean : beans) {
			if (bean != null && bean.getLocation() != null) {
				Location loc = bean.getLocation();
				if (!result.isEmpty()) {
					if (result.getNw().getY() < loc.getY()) {
						result.getNw().setY(loc.getY());
					} else if (result.getSe().getY() > loc.getY()) {
						result.getSe().setY(loc.getY());
					}
					if (result.getNw().getX() > loc.getX()) {
						result.getNw().setX(loc.getX());
					} else if (result.getSe().getX() < loc.getX()) {
						result.getSe().setX(loc.getX());
					}
				} else {
					result.setNw(new Location(loc.getX(), loc.getY()));
					result.setSe(new Location(loc.getX(), loc.getY()));
				}
			}
		}
		// add 5% margin
		if ( !result.isEmpty() ) {
			double marginw = MAPBOX_MARGIN * (result.getSe().getX()-result.getNw().getX());
			result.getSe().setX(result.getSe().getX()+marginw);
			result.getNw().setX(result.getNw().getX()-marginw);
			double marginh = MAPBOX_MARGIN * (result.getSe().getY()-result.getNw().getY());
			result.getSe().setY(result.getSe().getY()+marginh);
			result.getNw().setY(result.getNw().getY()-marginh);
		}
		return result;
	}

	public static Location buildCenter(List<? extends PositionBean> beans) {

		MapBox box = buildMapBox(beans);
		return new Location((box.getNw().getX() + box.getSe().getX()) / 2, (box
				.getNw().getY() + box.getSe().getY()) / 2);
	}
}
