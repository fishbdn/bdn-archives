package com.francetelecom.protosig.presentation.client.mvp;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.mvp.place.ErrorPlace;
import com.francetelecom.protosig.presentation.client.mvp.place.MapPlace;
import com.francetelecom.protosig.presentation.client.mvp.presenter.AbstractPresenter;
import com.francetelecom.protosig.presentation.client.mvp.presenter.ErrorPresenter;
import com.google.gwt.activity.shared.Activity;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.core.client.GWT;
import com.google.gwt.place.shared.Place;

/**
 * ContentActivityMapper maps each Place to its corresponding Activity.
 * 
 */
public class ContentActivityMapper implements ActivityMapper {

	private AbstractPresenter lastActivity = null;

	@Override
	public Activity getActivity(Place place) {
		GWT.log("place :" + place);
		// Manager
		if (place instanceof MapPlace) {
			lastActivity = Application.CLIENT_FACTORY.getMapPresenter();
		} else if (place instanceof ErrorPlace) {
			return new ErrorPresenter(
					Application.CLIENT_FACTORY.getErrorView(),
					((ErrorPlace) place).getCause());
		} else {
			lastActivity = null;
		}

		return lastActivity;
	}
}
