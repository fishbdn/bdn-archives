/**
 * 
 */
package com.francetelecom.protosig.presentation.server;

/**
 * @author mlaffargue
 * 
 */
public final class SessionAttribute {
	/**
	 * hidden constructor
	 */
	private SessionAttribute() {}
	/**
	 * UserDto : current user
	 */
	public static final String USER = "user"; 
	/**
	 * List<String> : current user's roles
	 */
	public static final String ROLES = "roles"; 
}
