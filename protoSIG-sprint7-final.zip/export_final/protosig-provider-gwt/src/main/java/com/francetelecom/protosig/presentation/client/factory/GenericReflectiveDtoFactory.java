package com.francetelecom.protosig.presentation.client.factory;

import java.util.List;
import java.util.Map;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.GenericDto.Field;
import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.ErrorEvent;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;
import com.francetelecom.protosig.presentation.client.utils.JsonFormConfig.IFieldData;
import com.francetelecom.protosig.presentation.client.utils.JsonFormConfig.IFieldList;
import com.francetelecom.protosig.presentation.client.utils.NodeHelper;

/**
 * Helper to create GenericReflectiveDto
 * 
 * @author jcwilk
 * 
 */
public final class GenericReflectiveDtoFactory {

	/**
	 * List of DTO declared in jsonForms.json
	 */
	public enum GenericDtoType {
		CUSTOMER, PC, SR, RE
	}
	
	private GenericReflectiveDtoFactory() {
	}

	/**
	 * Clear all new field values, set old value to local storage value
	 * 
	 * @param dto
	 * @param interventionData
	 */
	private static void initFromLocalStorage(GenericDto dto,
			INodeClientData interventionData) {
		for (GenericDto.FieldDef def : dto.getFieldDefs()) {
			Field field = dto.getField(def.getCode());
			// reset the field values
			String path = def.getPath().toLowerCase();
			String value = NodeHelper.getLeaf(interventionData, path);
			field.setOldValue(value);
			field.setNewValue(null);
		}
	}

	/**
	 * Create a generic dto from a PcDto
	 * @param pc
	 * @return
	 */
	public static GenericDto createFromClosePc(PcDto pc) {
		// create the dto
		GenericDto dto = new GenericDto();
		// add field definitions
		addFieldDefinitions(dto, GenericDtoType.PC);

		// populate fields from pc dto
		Field field=dto.getField(GenericDto.FIELD_PCNAME);
		field.setOldValue(pc.getName());
		field.setNewValue(null);
		
		field=dto.getField(GenericDto.FIELD_CATEG);
		field.setOldValue(pc.getCategory());
		field.setNewValue(null);		

		field=dto.getField(GenericDto.FIELD_NUMBER);
		field.setOldValue(pc.getNumber());
		field.setNewValue(null);		

		field=dto.getField(GenericDto.FIELD_STREET);
		field.setOldValue(pc.getStreet());
		field.setNewValue(null);		

		field=dto.getField(GenericDto.FIELD_CITY_NAME);
		field.setOldValue(pc.getCity());
		field.setNewValue(null);		

		field=dto.getField(GenericDto.FIELD_COMMENT);
		field.setOldValue(pc.getComment());
		field.setNewValue(null);		

		dto.setId(pc.getDr()+"|"+pc.getName());

		return dto;
	}
	
	/**
	 * Add field definitions in the generic dto for given type
	 * @param dto
	 * @param dtoType
	 */
	private static void addFieldDefinitions(GenericDto dto, GenericDtoType dtoType) {
		// add field definitions
		Map<String, IFieldList> dtoMap = Application.CLIENT_FACTORY
				.getJsonFormConfig();
		IFieldList fieldList=dtoMap == null ? null : dtoMap.get(dtoType
				.name().toLowerCase());
		List<IFieldData> dtoConfig = fieldList == null ? null : fieldList.getList();
		if (dtoConfig == null) {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new ErrorEvent(Application.CONSTANTS.json_error()));
			return;
		}
		for (IFieldData fieldData : dtoConfig) {
			dto.addField(fieldData.getCode(), fieldData.getPath(),
					Boolean.parseBoolean(fieldData.getDetail()));
		}		
	}
	
	/**
	 * Create a new dto using list of fields declared in jsonForms.json under
	 * name dtoType
	 * 
	 * @param dtoType
	 *            configuration entry
	 * @param interventionData
	 *            local storage data
	 * @return
	 */
	public static GenericDto create(GenericDtoType dtoType,
			InterventionBean intervention, NetworkDeviceBean device) {
		INodeClientData interventionData = intervention.getDetailIntervention();
		// create the dto
		GenericDto dto = new GenericDto();

		// add field definitions
		addFieldDefinitions(dto, dtoType);

		// fills fields with values from local storage
		initFromLocalStorage(dto, interventionData);

		// set id
		String codeBase=intervention.getCodeBase();
		switch(dtoType) {
		case CUSTOMER :
			dto.setId(codeBase+"|"+dto.getOldValue("nd"));
			break;
		case PC :
			String pcName=device.getName();
			dto.setId(codeBase+"|"+pcName);
			break;
		default : break;
		}
		
		return dto;
	}
}
