package com.francetelecom.protosig.presentation.client.rpc;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.InfoEvent;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Callback that displays a message depending on the result of the call
 * 
 * @author jcwilk
 * 
 * @param <T>
 *            RPC result type
 */
public class GenericMessageCallback<T> extends GenericCallback<T> implements
		AsyncCallback<T> {

	private final String successMessage;
	private final String errorMessage;

	/**
	 * constructor
	 * @param successMessage message to display on success
	 * @param errorMessage message to display on error
	 */
	public GenericMessageCallback(String successMessage, String errorMessage) {
		this.successMessage = successMessage;
		this.errorMessage = errorMessage;
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				GenericEvent.Type.START_RPC);
	}

	@Override
	public void onFailure(Throwable caught) {
		super.onFailure(caught);
		if ( errorMessage != null ) {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				new InfoEvent(errorMessage));
		}
	}

	@Override
	public void onSuccess(T result) {
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				GenericEvent.Type.STOP_RPC);
		if ( successMessage != null ) {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				new InfoEvent(successMessage));
		}
		process(result);
	}

	/**
	 * EMpty process. Can be overriden
	 */
	@Override
	protected void process(T result) {
	}
}
