package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.GenericDto.Field;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.factory.GenericReflectiveDtoFactory;
import com.francetelecom.protosig.presentation.client.factory.GenericReflectiveDtoFactory.GenericDtoType;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;
import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

/**
 * Displays a form using : json/jsonForms.json for field list current
 * intervention detail from localStorage for field values
 * 
 * @author jcwilk
 * 
 */
public class JsonFormWidget extends Composite {

	private static final String FIELD_LABEL_PREFIX = "form_";
	private static final String FORM_TITLE_PREFIX = "form_title_";
	private static final String CSS_STYLE_TITLE = "title";

	private static JsonFormWidgetUiBinder uiBinder = GWT
			.create(JsonFormWidgetUiBinder.class);

	interface JsonFormWidgetUiBinder extends UiBinder<Widget, JsonFormWidget> {
	}

	// CHECKSTYLE:OFF
	@UiField
	protected FlowPanel content;
	// CHECKSTYLE:ON

	private GenericDto dto;

	/**
	 * Constructor. Get jsonForms.json from server and parse it
	 */
	public JsonFormWidget() {
		initWidget(uiBinder.createAndBindUi(this));
	}

	/**
	 * Fills the form with fields read from jsonForms.json
	 * 
	 * @param interventionData
	 *            node from current intervention
	 * @param type
	 *            form type
	 */
	public void setForm(InterventionBean intervention, int deviceIndex) {
		GenericDtoType type = null;
		NetworkDeviceBean device = null;
		String name = "";
		if (deviceIndex == -1) {
			type = GenericDtoType.CUSTOMER;
		} else {
			device = intervention.getDevices().get(
					deviceIndex);
			name = device.getName();
			switch (device.getType()) {
			case PC:
				type = GenericDtoType.PC;
				break;
			case SR:
			case SRI:
			case SRP:
			case SRS:
			case SRZ:
				type = GenericDtoType.SR;
				break;
			case RE:
				type = GenericDtoType.RE;
				break;
			default:
				break;
			}
		}
		populateFields(intervention, device, name, type);
	}

	/**
	 * Fills the fields for given form type
	 * 
	 * @param intervention
	 * @param name
	 *            customer/network device name for the form title
	 * @param type
	 *            form type
	 */
	private void populateFields(InterventionBean intervention, NetworkDeviceBean device, String name,
			GenericDtoType type) {
		INodeClientData interventionData = intervention.getDetailIntervention();
		if (interventionData != null) {
			dto = GenericReflectiveDtoFactory.create(type, intervention, device);
			content.clear();
			// form title
			Label title = new Label(
					Application.CONSTANTS.getString(FORM_TITLE_PREFIX
							+ type.name().toLowerCase())
							+ " " + name);
			title.addStyleName(CSS_STYLE_TITLE);
			content.add(title);
			for (Field field : dto.getFields()) {
				// add a new field
				String value = field.getOldValue();
				if ((!field.getDefinition().isDetail()) || value == null
						|| "".equals(value)) {
					// don't display empty fields
					continue;
				}
				FlowPanel fieldPanel = new FlowPanel();
				content.add(fieldPanel);
				// add field label
				String code = field.getDefinition().getCode();
				Label fieldLabel = new Label(
						Application.CONSTANTS.getString(FIELD_LABEL_PREFIX
								+ code));
				fieldLabel.addStyleName("formLabel");
				fieldPanel.add(fieldLabel);
				// add field value
				Label fieldValue = new Label(value);
				fieldValue.addStyleName("formValue");
				fieldPanel.add(fieldValue);
			}
		}
	}
}
