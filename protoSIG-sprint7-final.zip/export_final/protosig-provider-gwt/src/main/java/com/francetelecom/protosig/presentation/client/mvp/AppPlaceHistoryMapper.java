package com.francetelecom.protosig.presentation.client.mvp;

import com.francetelecom.protosig.presentation.client.mvp.place.MapPlace;
import com.google.gwt.place.shared.PlaceHistoryMapper;
import com.google.gwt.place.shared.WithTokenizers;

/**
 * Declares all the Places available in your app.
 */
@WithTokenizers({ MapPlace.Tokenizer.class })
public interface AppPlaceHistoryMapper extends PlaceHistoryMapper {

}
