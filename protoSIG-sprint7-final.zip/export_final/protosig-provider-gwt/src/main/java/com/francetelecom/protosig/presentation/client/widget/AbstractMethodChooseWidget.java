package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.InfoEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.WarnEvent;
import com.francetelecom.protosig.presentation.client.utils.geolocation.GeolocationHelper;
import com.francetelecom.protosig.presentation.client.utils.geolocation.GeolocationHelper.GeolocationCallback;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Composite;

/**
 * A widget with a dialog box to choose a pushpin movement method : gps or manual
 * @author jcwilk
 *
 */
public abstract class AbstractMethodChooseWidget extends Composite {
	protected static final String PC_DRAG_ICON = "images/pushpin_pc_drag.png";
	
	/**
	 * GPS/hand popup
	 */
	private ChoosePositionMethodWidget methodPopup;
	
	protected abstract void enableDragAndDrop(Double x, Double y);
	
	protected final ClickHandler moveHandler=new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				// show position method popup					
				if (methodPopup == null) {
					methodPopup = new ChoosePositionMethodWidget(
							gpsHandler, handHandler);
					methodPopup.center();
				}
				methodPopup.show();
			}
	};
	
	/**
	 * Enable customer/pc drag and drop
	 */
	private final ClickHandler handHandler = new ClickHandler() {
		@Override
		public void onClick(ClickEvent event) {
			methodPopup.hide();
			enableDragAndDrop(null, null);
		}
	};

	/**
	 * Get the user position, then enable customer/pc drag and drop
	 */
	private final ClickHandler gpsHandler = new ClickHandler() {
		@Override
		public void onClick(ClickEvent event) {
			methodPopup.hide();
			GeolocationHelper.getPosition(new GeolocationCallback() {

				@Override
				public void onSuccess(Double x, Double y) {
					// move customer/PC to x,y before enabling drag and drop
					enableDragAndDrop(x, y);
				}

				@Override
				public void onError() {
					Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
							new WarnEvent(Application.CONSTANTS.nogeoloc()));
				}

				@Override
				public void onCancel() {
					// permission refused
					Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
							new InfoEvent(Application.CONSTANTS.geolocRefused()));					
					// go back to popup
					methodPopup.show();
				}
			});
		}
	};

}
