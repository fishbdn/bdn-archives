package com.francetelecom.protosig.presentation.client.eventbus.event;

/**
 * Generic event
 * 
 * @author jcwilk
 * 
 * @param <T>
 *            data type
 */
public class GenericEvent<T> {

	public enum Type {
		// display loading message
		START_RPC,  
		// hide loading message
		STOP_RPC, 
		// display customers on the map
		MAP_AGENDA,
		// select or unselect an intervention in the agenda
		INTER_SELECT,
		// geocoding confidence is low for an intervention
		INTER_GEO,
		// display detail of an intervention
		INTER_DETAIL,
		// display detail of a close pc
		CLOSE_PC_DETAIL,
		// reset the map zoom and unselect all interventions
		REFRESH_MAP,
		// reset only the map zoom
		RESET_MAP_ZOOM,
		// display user position on the map
		DISPLAY_USER_POS,
		// find PC close to a position
		CLOSEST_PC,
		// change what is displayed on the map part of the frame
		UI_MODE,
		// start to listen to a long press to enable drag and drop
		SWITCH_DND,
		// display some information
		INFO, 
		// display some warning
		WARN, 
		// display some error
		ERROR
	}

	private final Type type;
	private T data;

	public GenericEvent(Type type, T data) {
		this.type = type;
		this.data = data;
	}

	public Type getType() {
		return type;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data=data;
	}
}
