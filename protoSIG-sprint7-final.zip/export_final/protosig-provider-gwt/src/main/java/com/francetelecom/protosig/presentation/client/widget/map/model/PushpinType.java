package com.francetelecom.protosig.presentation.client.widget.map.model;

/**
 * PushpinType
 * 
 * @author jcwilk
 * 
 */
public enum PushpinType {

	defaultType(9, 9, 1, 5), customer(44, 46, 0, 15), customer_trans(44, 46, 0,
			15), customer_warn(44, 46, 0, 15), customer_warn_trans(44, 46, 0, 15), pc(
			36, 46, 0, 13), pc_trans(36, 46, 0, 13), sr(36, 45, 0, 4), re(36, 46,
			0, 5), user(19, 27, 0, 5), 
			closepc_full(36, 46, 0, 13), closepcs_full(36, 50, 0, 9),
			closepc_dispo(36, 46, 0, 13), closepcs_dispo(36, 50, 0, 9);

	private static final String PATH = "images/pushpin_";
	private static final String EXTENSION = ".png";

	/**
	 * Pushpin image size in pixels
	 */
	private int width, height;
	/**
	 * Position of text
	 */
	private int textOffsetX, textOffsetY;

	private PushpinType(int width, int height, int textOffsetX, int textOffsetY) {
		this.width = width;
		this.height = height;
		this.textOffsetX = textOffsetX;
		this.textOffsetY = textOffsetY;
	}

	public String getImagePath() {
		return PATH + name() + EXTENSION;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public int getTextOffsetX() {
		return textOffsetX;
	}

	public int getTextOffsetY() {
		return textOffsetY;
	}

}
