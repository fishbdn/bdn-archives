package com.francetelecom.protosig.presentation.client.mvp.view;


/**
 * Contains all of the UI components that make up our Footer. Views are
 * responsible for the layout of the UI components.
 */
public interface FooterView extends AbstractView {

}
