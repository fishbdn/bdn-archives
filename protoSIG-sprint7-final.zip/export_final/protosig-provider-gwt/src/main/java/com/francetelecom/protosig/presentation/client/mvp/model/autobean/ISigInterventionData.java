package com.francetelecom.protosig.presentation.client.mvp.model.autobean;

/**
 * SIG prototype specific data for an intervention
 * @author jcwilk
 *
 */
public interface ISigInterventionData {
	/**
	 * eTech reference (intervention id)
	 * @return
	 */
	String getReference();
	/**
	 * customer longitude (only if modified in SIG)
	 * @return
	 */
	Double getCustomerX();
	/**
	 * customer latitude (only if modified in SIG)
	 * @return
	 */
	Double getCustomerY();
	/**
	 * PC longitude (only if modified in SIG)
	 * @return
	 */
	Double getPCX();
	/**
	 * PC latitude (only if modified in SIG)
	 * @return
	 */
	Double getPCY();
	
	// setters
	void setReference(String value);
	void setCustomerX(Double value);
	void setCustomerY(Double value);
	void setPCX(Double value);
	void setPCY(Double value);
}
