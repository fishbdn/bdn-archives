package com.francetelecom.protosig.presentation.client;

import com.francetelecom.protosig.presentation.client.eventbus.EventListener;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.MessageEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.UIModeEvent;
import com.francetelecom.protosig.presentation.client.exception.ClientExceptionHandler;
import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.factory.ClientFactory;
import com.francetelecom.protosig.presentation.client.factory.ClientFactoryImpl;
import com.francetelecom.protosig.presentation.client.mvp.AppPlaceHistoryMapper;
import com.francetelecom.protosig.presentation.client.mvp.ContentActivityMapper;
import com.francetelecom.protosig.presentation.client.mvp.FooterActivityMapper;
import com.francetelecom.protosig.presentation.client.mvp.SideBarActivityMapper;
import com.francetelecom.protosig.presentation.client.mvp.place.MapPlace;
import com.francetelecom.protosig.presentation.client.resources.Constantes;
import com.google.gwt.activity.shared.ActivityManager;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.activity.shared.CachingActivityMapper;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.place.shared.PlaceHistoryHandler;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * The entry point of the Gwt Application
 * 
 */
public class Application implements EntryPoint, EventListener {

	/**
	 * Holds the application constants
	 */
	public static final Constantes CONSTANTS = GWT.create(Constantes.class);

	/**
	 * Holds application wide objects
	 */
	public static final ClientFactory CLIENT_FACTORY = GWT
			.create(ClientFactoryImpl.class);

	private int rpcCallsCount = 0;
	/**
	 * No "loading..." message displayed if a RPC lasts less than x milliseconds
	 */
	private static final int RPC_MESSAGE_THRESHOLD = 150;

	@Override
	public void onModuleLoad() {
		GWT.setUncaughtExceptionHandler(new ClientExceptionHandler());
		createUI();
		CLIENT_FACTORY.getJsonEventBus().registerListener(this);
	}

	/**
	 * @throws ClientFunctionalException
	 * 
	 */
	private void createUI() {
		hideLoading();

		// Create activities managers
		createHeaderActivityManager();
		createContentActivityManager();
		createFooterActivityManager();

		// add main UI at the root level
		RootLayoutPanel.get().add(CLIENT_FACTORY.getSiteUI());
		PlaceHistoryHandler historyHandler = createHistoryHandler();
		historyHandler.handleCurrentHistory();
	}

	private PlaceHistoryHandler createHistoryHandler() {
		AppPlaceHistoryMapper historyMapper = GWT
				.create(AppPlaceHistoryMapper.class);
		PlaceHistoryHandler historyHandler = new PlaceHistoryHandler(
				historyMapper);
		historyHandler.register(CLIENT_FACTORY.getPlaceController(),
				CLIENT_FACTORY.getEventBus(), new MapPlace());
		return historyHandler;
	}

	private void createFooterActivityManager() {
		ActivityMapper footerActivityMapper = new FooterActivityMapper();
		ActivityManager footerActivityManager = new ActivityManager(
				footerActivityMapper, CLIENT_FACTORY.getEventBus());
		// display the footer view in the main UI
		footerActivityManager.setDisplay(CLIENT_FACTORY.getSiteUI()
				.getFooterContainer());
	}

	private void createContentActivityManager() {
		ActivityMapper contentActivityMapper = new CachingActivityMapper(
				new ContentActivityMapper());
		ActivityManager contentActivityManager = new ActivityManager(
				contentActivityMapper, CLIENT_FACTORY.getEventBus());
		// display the content view in the main UI
		contentActivityManager.setDisplay(CLIENT_FACTORY.getSiteUI()
				.getContentContainer());
	}

	private void createHeaderActivityManager() {
		ActivityMapper headerActivityMapper = new SideBarActivityMapper();
		ActivityManager headerActivityManager = new ActivityManager(
				headerActivityMapper, CLIENT_FACTORY.getEventBus());
		// display the header view in the main UI
		headerActivityManager.setDisplay(CLIENT_FACTORY.getSiteUI()
				.getSideBarContainer());
	}

	/**
	 * Hides the loading message in the hosted page
	 * 
	 */
	private void hideLoading() {
		final Element loading = DOM.getElementById("loading-shadow");
		if (loading != null) {
			DOM.removeChild(RootPanel.getBodyElement(), loading);
		}
	}

	/**
	 * decrease the RPC counter. HIde the loading message if no pending RPC
	 */
	public void onStopRPC() {
		rpcCallsCount--;
		if (rpcCallsCount <= 0) {
			rpcCallsCount = 0;
			CLIENT_FACTORY.getSiteUI().hideMessage();
		}
	}

	/**
	 * Increase the RPC counter. Shows the loading message
	 */
	public void onStartRPC() {
		rpcCallsCount++;
		final int myCount = rpcCallsCount;
		// use a timer to avoid displaying the message if the call is fast
		Timer t = new Timer() {
			@Override
			public void run() {
				if (myCount == rpcCallsCount
						&& !CLIENT_FACTORY.getSiteUI().isMessageVisible()) {
					CLIENT_FACTORY.getSiteUI().showRpcMessage();
				}
			}
		};
		t.schedule(RPC_MESSAGE_THRESHOLD);
	}

	/**
	 * Handle RPC start/stop events
	 */
	@Override
	public void handleEvent(GenericEvent<?> event) {
		switch (event.getType()) {
		case START_RPC:
			onStartRPC();
			break;
		case STOP_RPC:
			onStopRPC();
			break;
		case INFO:
			CLIENT_FACTORY.getSiteUI().info(((MessageEvent) event).getData());
			break;
		case WARN:
			CLIENT_FACTORY.getSiteUI().warn(((MessageEvent) event).getData());
			break;
		case ERROR:
			CLIENT_FACTORY.getSiteUI().error(((MessageEvent) event).getData());
			break;
		case UI_MODE:
			UIModeEvent mapModeEvent = (UIModeEvent) event;
			CLIENT_FACTORY.getSiteUI().setMode(mapModeEvent.getData(),
					mapModeEvent.getIntervention(), mapModeEvent.getPc(), mapModeEvent.getPcDto());
		default:
			break;
		}
	}

}
