package com.francetelecom.protosig.presentation.client.eventbus.event;

import com.francetelecom.protosig.model.PcDto;

/**
 * Event triggered to display the detail of a pc close to the customer on the map
 * @author jcwilk
 *
 */
public class DetailClosePCEvent extends GenericEvent<Long> {
	private PcDto pc;
	/**
	 * Display detail about an element on the map
	 * @param index the pc index 
	 */
	public DetailClosePCEvent(Long index) {
		super(GenericEvent.Type.CLOSE_PC_DETAIL, index);
	}
	public PcDto getPc() {
		return pc;
	}
	public void setPc(PcDto pc) {
		this.pc = pc;
	}
	
}
