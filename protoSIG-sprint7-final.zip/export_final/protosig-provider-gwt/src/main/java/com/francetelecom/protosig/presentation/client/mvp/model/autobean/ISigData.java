package com.francetelecom.protosig.presentation.client.mvp.model.autobean;

import java.util.List;

/**
 * Data stored in the local storage by the SIG prototype
 * @author jcwilk
 *
 */
public interface ISigData {
	List<ISigInterventionData> getInterventionList();
	void setInterventionList(List<ISigInterventionData> value);
}
