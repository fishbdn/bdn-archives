package com.francetelecom.protosig.presentation.client.mvp.view.impl;

import com.google.gwt.user.client.ui.Composite;

/**
 * This class should be extended by the view implementations. It'll allow to
 * have a common entry point.
 * 
 * @author jcwilk
 * 
 * @param <T>
 * 
 */
public abstract class AbstractViewImpl extends Composite {

}
