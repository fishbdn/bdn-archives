package com.francetelecom.protosig.presentation.client.widget.map.impl.bing;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailClosePCEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailInterventionEvent;
import com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.francetelecom.protosig.presentation.client.widget.map.model.PositionBean;
import com.francetelecom.protosig.presentation.client.widget.map.model.PushpinType;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.user.client.DOM;

/**
 * pushpin
 * 
 * @author JLZB1407
 * 
 */
public class Pushpin extends PositionBean implements
		AbstractMapWidget.IPushpin {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5578169839175573146L;

	private final PushpinType type;
	private final String imagePath;
	private String textPin = "";
	private final Long deviceIndex;
	private JavaScriptObject jsPushpin;
	private JavaScriptObject onDragHandler;
	private JavaScriptObject onClickHandler;
	private boolean displayIndex;

	private final String uid = DOM.createUniqueId();

	/**
	 * Create a pushpin for the map
	 * 
	 * @param interventionIndex
	 *            index of the intervention associated with the pushpin (-1 =
	 *            none)
	 * @param deviceIndex
	 *            index of the device in the intervention (-1 = none)
	 * @param type
	 *            pushpin type
	 * @param location
	 *            pushpin position on map
	 */
	public Pushpin(Long interventionIndex, Long deviceIndex, PushpinType type,
			Location location, boolean displayIndex) {

		setId(interventionIndex);
		this.type = type;
		this.deviceIndex = deviceIndex;
		this.displayIndex=displayIndex;
		setLocation(location);
		this.imagePath = type.getImagePath();
		if (interventionIndex != -1) {
			this.textPin = String.valueOf(interventionIndex);
		} else {
			this.textPin = "";
		}
	}

	/**
	 * Return true if drag and drop is currently active for this pushpin
	 * 
	 * @return
	 */
	public boolean isDragAndDropActive() {
		return this.onDragHandler != null;
	}

	public void onClick() {
		switch (type) {
		case customer:
		case customer_warn:
		case pc:
		case re:
		case sr:
			// display detail about some intervention device
			if (getId() != -1L ) {
				// only devices from the current intervention
				// send event to the side bar presenter
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new DetailInterventionEvent(getId(),
								deviceIndex));
			}
		break;
		case closepc_dispo :
		case closepc_full :
		case closepcs_dispo :
		case closepcs_full :
			if ( deviceIndex != -1L ) {
				// close pc detail
				// send event to the map presenter
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new DetailClosePCEvent(deviceIndex));				
			}
			break;
		case user:
			// click on the technician position : do nothing
		default:
			break;
		}
	}

	public void onDrag(double x, double y) {
		getLocation().setX(x);
		getLocation().setY(y);
	}

	@Override
	public PushpinType getType() {
		return type;
	}

	@Override
	public String getImagePath() {
		return imagePath;
	}

	@Override
	public String getTextPin() {
		return textPin;
	}

	public String getUid() {
		return uid;
	}

	public Double getLocationX() {
		return getLocation().getX();
	}

	public Double getLocationY() {
		return getLocation().getY();
	}

	public JavaScriptObject getOnDragHandler() {
		return onDragHandler;
	}

	public void setOnDragHandler(JavaScriptObject onDragHandler) {
		this.onDragHandler = onDragHandler;
	}

	public JavaScriptObject getJsPushpin() {
		return jsPushpin;
	}

	public void setJsPushpin(JavaScriptObject jsPushpin) {
		this.jsPushpin = jsPushpin;
	}

	public JavaScriptObject getOnClickHandler() {
		return onClickHandler;
	}

	public void setOnClickHandler(JavaScriptObject onClickHandler) {
		this.onClickHandler = onClickHandler;
	}

	public boolean isDisplayIndex() {
		return displayIndex;
	}

}
