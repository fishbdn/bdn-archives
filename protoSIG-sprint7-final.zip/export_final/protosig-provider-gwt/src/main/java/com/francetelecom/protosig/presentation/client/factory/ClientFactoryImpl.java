package com.francetelecom.protosig.presentation.client.factory;

import java.util.Map;

import com.francetelecom.protosig.presentation.client.eventbus.JsonEventBus;
import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.presenter.FooterPresenter;
import com.francetelecom.protosig.presentation.client.mvp.presenter.MapPresenter;
import com.francetelecom.protosig.presentation.client.mvp.presenter.SideBarPresenter;
import com.francetelecom.protosig.presentation.client.mvp.view.ErrorView;
import com.francetelecom.protosig.presentation.client.mvp.view.FooterView;
import com.francetelecom.protosig.presentation.client.mvp.view.MapView;
import com.francetelecom.protosig.presentation.client.mvp.view.SideBarView;
import com.francetelecom.protosig.presentation.client.mvp.view.impl.ErrorViewImpl;
import com.francetelecom.protosig.presentation.client.mvp.view.impl.FooterViewImpl;
import com.francetelecom.protosig.presentation.client.mvp.view.impl.MapViewImpl;
import com.francetelecom.protosig.presentation.client.mvp.view.impl.SideBarViewImpl;
import com.francetelecom.protosig.presentation.client.rpc.SigService;
import com.francetelecom.protosig.presentation.client.rpc.SigServiceAsync;
import com.francetelecom.protosig.presentation.client.ui.SiteUI;
import com.francetelecom.protosig.presentation.client.utils.JsonFormConfig;
import com.francetelecom.protosig.presentation.client.utils.JsonFormConfig.IFieldList;
import com.francetelecom.protosig.presentation.client.utils.localstorage.ILocalStorage;
import com.francetelecom.protosig.presentation.client.utils.localstorage.impl.HostedModeLocalStorageImpl;
import com.francetelecom.protosig.presentation.client.utils.localstorage.impl.LocalStorageImpl;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.place.shared.PlaceController;
import com.google.web.bindery.event.shared.EventBus;

/**
 * Implementation of ClientFactory
 * 
 */
public class ClientFactoryImpl implements ClientFactory {

	private static final EventBus EVENT_BUS = new SimpleEventBus();
	private static final JsonEventBus SMART_EVENT_BUS = new JsonEventBus();
	private static final PlaceController PLACE_CONTROLLER = new PlaceController(
			EVENT_BUS);
	private static final SiteUI SITE_UI = new SiteUI();
	private static LocalStorageImpl localStorage=null;
	private static final InterventionBeanFactory INTERVENTION_BEAN_FACTORY = new InterventionBeanFactory();
	private static final JsonFormConfig JSON_FORM_CONFIG=new JsonFormConfig();

	// ****** VIEWS ******
	private static SideBarView sideBarView = null;
	private static FooterView footerView = null;
	private static MapView mapView = null;
	private static ErrorView errorView = null;

	// ****** PRESENTERS ******
	private static SideBarPresenter sideBarPresenter = null;
	private static FooterPresenter footerPresenter = null;
	private static MapPresenter mapPresenter = null;

	// ****** SERVICES ******
	private static final SigServiceAsync CITY_SERVICE = GWT
			.create(SigService.class);
	
	// ******** Manager *********

	@Override
	public EventBus getEventBus() {
		return EVENT_BUS;
	}

	@Override
	public JsonEventBus getJsonEventBus() {
		return SMART_EVENT_BUS;
	}

	@Override
	public InterventionBeanFactory getInterventionBeanFactory() {
		return INTERVENTION_BEAN_FACTORY;
	}

	@Override
	public ILocalStorage getLocalStorage() throws ClientFunctionalException {
		if ( localStorage == null ) {
			// cannot use deferred binding here
			// would require to add dependency to gwt-dev
			// to create a PropertyProviderGenerator
			if ( GWT.isScript() ) {
				// use local storage from iTech
				localStorage = new LocalStorageImpl();
			} else {
				// hosted mode. create a dummy local storage
				localStorage = new HostedModeLocalStorageImpl();				
			}
		}
		return localStorage;
	}	
	
	@Override
	public SideBarPresenter getSideBarPresenter() {
		if (sideBarPresenter == null) {
			sideBarPresenter = new SideBarPresenter();
		}
		return sideBarPresenter;
	}

	@Override
	public FooterPresenter getFooterPresenter() {
		if (footerPresenter == null) {
			footerPresenter = new FooterPresenter();
		}
		return footerPresenter;
	}

	@Override
	public MapPresenter getMapPresenter() {
		if (mapPresenter == null) {
			mapPresenter = new MapPresenter();
		}
		return mapPresenter;
	}

	@Override
	public SideBarView getHeaderView() {
		if (sideBarView == null) {
			sideBarView = new SideBarViewImpl();
		}
		return sideBarView;
	}

	@Override
	public PlaceController getPlaceController() {
		return PLACE_CONTROLLER;
	}

	@Override
	public FooterView getFooterView() {
		if (footerView == null) {
			footerView = new FooterViewImpl();
		}
		return footerView;
	}

	@Override
	public MapView getMapView() {
		if (mapView == null) {
			mapView = new MapViewImpl();
		}
		return mapView;
	}

	@Override
	public ErrorView getErrorView() {
		if (errorView == null) {
			errorView = new ErrorViewImpl();
		}
		return errorView;
	}

	@Override
	public SiteUI getSiteUI() {
		return SITE_UI;
	}

	@Override
	public SigServiceAsync getSigService() {
		return CITY_SERVICE;
	}

	@Override
	public Map<String, IFieldList> getJsonFormConfig() {
		return JSON_FORM_CONFIG.getConfig();
	}

}
