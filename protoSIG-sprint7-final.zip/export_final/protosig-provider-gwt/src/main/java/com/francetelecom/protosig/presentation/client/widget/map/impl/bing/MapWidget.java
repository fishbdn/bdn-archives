package com.francetelecom.protosig.presentation.client.widget.map.impl.bing;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

import com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget;
import com.francetelecom.protosig.presentation.client.widget.map.IGeocoding;
import com.francetelecom.protosig.presentation.client.widget.map.impl.bing.utils.ResourceUtils;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.francetelecom.protosig.presentation.client.widget.map.model.MapBox;
import com.francetelecom.protosig.presentation.client.widget.map.model.PositionBean;
import com.francetelecom.protosig.presentation.client.widget.map.model.Resource;
import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.core.client.JsArrayNumber;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiConstructor;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * Bing implementation of IMap
 * 
 * @author JLZB1407
 * 
 */
public class MapWidget extends AbstractMapWidget {

	interface MapWidgetUiBinder extends UiBinder<Widget, MapWidget> {
	}

	private static MapWidgetUiBinder uiBinder = GWT
			.create(MapWidgetUiBinder.class);

	// CHECKSTYLE:OFF
	@UiField
	protected HTMLPanel mapPanel;
	// CHECKSTYLE:ON

	private final String uid;
	private final Geocoding geocoding = new Geocoding();
	private JavaScriptObject map;
	private Resource box;

	private final List<Pushpin> pushpins = new ArrayList<Pushpin>();

	private JavaScriptObject currentInfobox;

	private final Set<IViewChangeHandler> listener = new HashSet<IViewChangeHandler>();

	private final Queue<OnLoadMapCmd> onloadCmds = new LinkedList<OnLoadMapCmd>();

	private final List<Pushpin> viewPushpins = new ArrayList<Pushpin>();

	/**
	 * Backup of the text of the pushpin being dragged
	 */
	private String dragText;
	/**
	 * Pushpin being dragged
	 */
	private Pushpin dragPushpin;
	/**
	 * Currently selected pushpin
	 */
	private Pushpin selectedPushpin;
	/**
	 * Pushpin position before being dragged (for rollback)
	 */
	private final Location dragLocation=new Location(0,0);

	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#startView()
	 */
	@Override
	public void startView() {
		viewPushpins.clear();
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#endView()
	 */
	@Override
	public void endView() {
		setView(ResourceUtils.buildMapBox(viewPushpins));
	}
	
	/**
	 * Allow to delay some map commands
	 * 
	 */
	public class OnLoadMapCmd {

		public void run() {
			// to override
		}
	}

	public void addDelayedCmd(OnLoadMapCmd cmd) {
		onloadCmds.add(cmd);
		// try to execute at adding
		execOnLoadCmds(); 
	}

	@UiConstructor
	public MapWidget() {
		initWidget(uiBinder.createAndBindUi(this));

		// add map div
		uid = DOM.createUniqueId();

		mapPanel.getElement().setPropertyString("id", uid);
	}

	@Override
	protected void onLoad() {
		super.onLoad();

		// construct js map after onload only
		if (map == null) {
			map = map(uid, Authorization.AUTH_KEY);

			// register view changed
			registerViewChanged();

			// init map box
			retrieveResource();

			// run waiting cmds
			execOnLoadCmds();
		}
	}

	/**
	 * run wainting cmd
	 * 
	 */
	private void execOnLoadCmds() {
		if (map != null) {
			while (onloadCmds.size() > 0) {
				onloadCmds.poll().run();
			}
		}
	}

	@Override
	protected void onUnload() {
		super.onUnload();
		dispose(map);
		map = null;
	}

	@Override
	public void add(final Pushpin pushpin) {
		viewPushpins.add(pushpin);
		addDelayedCmd(new OnLoadMapCmd() {
			@Override
			public void run() {
				addDirect(pushpin);
			}
		});
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#setAutoView()
	 */
	@Override
	public void setAutoView() {
		setView(ResourceUtils.buildMapBox(pushpins));
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#updateView(double, double)
	 */
	@Override
	public void updateView(double x, double y) {
		List<PositionBean> list=new ArrayList<PositionBean>(pushpins.size()+1);
		list.addAll(pushpins);
		PositionBean newBean=new PositionBean();
		newBean.setLocation(new Location(x,y));
		list.add(newBean);
		setView(ResourceUtils.buildMapBox(list));
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#addDirect(com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin)
	 */
	@Override
	public void addDirect(final Pushpin pushpin) {
		pushpins.add(pushpin);
		addPushpin(pushpin.getLocation(), pushpin.getImagePath(),
				pushpin.isDisplayIndex() ? pushpin.getTextPin() : "", pushpin, 
				pushpin.getType().getWidth(), pushpin.getType().getHeight(),
				pushpin.getType().getTextOffsetX(),pushpin.getType().getTextOffsetY(),
				// put intervention pushpins in front of other pushpins
				"".equals(pushpin.getTextPin()) ? 1:0);
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#clearPushpins()
	 */
	@Override
	public void clearPushpins() {
		pushpins.clear();
		if (map != null) {
			clearPushpins(map);
		}
	}
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#remove(com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin)
	 */
	@Override
	public void remove(Pushpin pushpin) {
		pushpins.remove(pushpin);
		if ( map != null ) {
			clearPushpin(map,pushpin.getJsPushpin());
		}
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#addInfoBox(com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin)
	 */
	@Override
	public void addInfoBox(Pushpin pushpin) {
		clearInfoBox();
		setView(pushpin.getLocation());
		currentInfobox = addInfoBoxJs(pushpin);
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#clearInfoBox()
	 */
	@Override
	public void clearInfoBox() {
		if (currentInfobox != null) {
			clearInfoBox(map, currentInfobox);
			currentInfobox = null;
		}
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#setView(com.francetelecom.protosig.presentation.client.widget.map.model.Location)
	 */
	@Override
	public void setView(final Location location) {
		addDelayedCmd(new OnLoadMapCmd() {
			@Override
			public void run() {
				setView(map, location);
			}
		});
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#setView(com.francetelecom.protosig.presentation.client.widget.map.model.MapBox)
	 */
	@Override
	public void setView(final MapBox box) {
		viewPushpins.clear();
		addDelayedCmd(new OnLoadMapCmd() {
			@Override
			public void run() {
				if ( box != null && box.getNw() != null && box.getSe() != null)  {
					setView(map, box.getNw(), box.getSe());
				}
			}
		});
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#setZoom(int)
	 */
	@Override
	public void setZoom(final int zoom) {
		addDelayedCmd(new OnLoadMapCmd() {
			@Override
			public void run() {
				setZoom(map, zoom);
			}
		});
	}

	public static native JavaScriptObject map(String mapId, String key) /*-{
																		var mapJs = new $wnd.Microsoft.Maps.Map($doc.getElementById(mapId), {
																		credentials : key,
																		enableClickableLogo : false,
																		enableSearchLogo : false,
																		showScaleBar : false
																		});
																		// Get the existing options.
																		var options = mapJs.getOptions();

																		// Set default zoom on France
																		options.zoom = 5;
																		options.center = new $wnd.Microsoft.Maps.Location(46.8, 2.7);

																		mapJs.setView(options);

																		return mapJs;
																		}-*/;

	public static native void dispose(JavaScriptObject mapJs) /*-{
																if (typeof (mapJs) != 'undefined' && mapJs != null) {
																mapJs.dispose();
																}
																}-*/;

	public static native JsArrayNumber getBounds(JavaScriptObject map) /*-{
																		var bounds = map.getBounds();
																		var result = new Array(bounds.center.longitude, bounds.center.latitude,
																		bounds.width, bounds.height);
																		return result;
																		}-*/;

	public static native void setView(JavaScriptObject map, Location location) /*-{
																				var x = location.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::x;
																				var y = location.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::y;
																				map.setView({
																				center : new $wnd.Microsoft.Maps.Location(y, x)
																				})
																				}-*/;

	public static native void setView(JavaScriptObject map, Location nw,
			Location se) /*-{
				var nwx = nw.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::x;
				var nwy = nw.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::y;
				var sex = se.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::x;
				var sey = se.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::y;
				map.setView({
				bounds : $wnd.Microsoft.Maps.LocationRect.fromCorners(
				new $wnd.Microsoft.Maps.Location(nwy, nwx),
				new $wnd.Microsoft.Maps.Location(sey, sex))
				});
				}-*/;

	private static native void setZoom(JavaScriptObject map, int zoomLevel) /*-{
				map.setView({
				zoom : zoomLevel
				})
				}-*/;

	private native void addPushpin(Location location, String imagePath,
			String textPin, Pushpin pushpin, int pWidth, int pHeight, 
			int textOffsetX, int textOffsetY, int pzIndex) /*-{

				// create pushin
				var x = location.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::x;
				var y = location.@com.francetelecom.protosig.presentation.client.widget.map.model.Location::y;
				var pushpinOptions = {
				icon : imagePath,
				visible : true,
				text : textPin,
				typeName : 'ppstyle',
				textOffset : new $wnd.Microsoft.Maps.Point(textOffsetX, textOffsetY),
				width : pWidth,
				height : pHeight,
				zIndex : pzIndex
				};
				var pushpinJs = new $wnd.Microsoft.Maps.Pushpin(
				new $wnd.Microsoft.Maps.Location(y, x), pushpinOptions);

				// add pushpin to the map
				var mapJs = this.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget::map;
				mapJs.entities.push(pushpinJs);
				pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::jsPushpin=pushpinJs;
				
				// add click handler
				var onclick = $entry(function(e) {
					pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onClick()();
				});
				var clickhandler=$wnd.Microsoft.Maps.Events.addHandler(pushpinJs, 'click', onclick);
				pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onClickHandler=clickhandler;
				}-*/;
	
	/**
	 * Enable drag and drop on the pushpin.
	 * 
	 * Handlers are saved in the Pushpin object so that we can remove them later
	 * @param pushpin
	 */
	@Override
	public void enableDragDrop(Pushpin pushpin ) {
		if ( selectedPushpin != null ) {
			unselectPushpinInternal(selectedPushpin);
		}
		dragText=pushpin.getTextPin();
		dragPushpin=pushpin;
		dragLocation.setX(pushpin.getLocationX());
		dragLocation.setY(pushpin.getLocationY());
		enableDragDropInternal(pushpin);
	}
	
	/**
	 * Change a pushpin icon to add _sel (selected version of the icon)
	 * @param pushpin
	 */
	@Override
	public void selectPushpin(Pushpin pushpin) {
		if ( selectedPushpin != null ) unselectPushpinInternal(selectedPushpin);
		selectedPushpin=pushpin;
		selectPushpinInternal(selectedPushpin);
	}
	
	private native void selectPushpinInternal(Pushpin pushpin) /*-{
		var pushpinJs=pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::jsPushpin;
		var selicon=pushpinJs.getIcon().replace('.','_sel.');
		pushpinJs.setOptions({icon:selicon,zIndex:2});
	}-*/;

	private native void unselectPushpinInternal(Pushpin pushpin) /*-{
		var pushpinJs=pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::jsPushpin;
		var stdicon=pushpinJs.getIcon().replace('_sel.','.');
		pushpinJs.setOptions({icon:stdicon,zIndex:1});
	}-*/;

	private native void enableDragDropInternal(Pushpin pushpin) /*-{
				var pushpinJs=pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::jsPushpin;
				var dragicon=pushpinJs.getIcon().replace('.','_drag.');
				pushpinJs.setOptions({draggable:true,icon:dragicon,zIndex:2});
				// drag
				var ondrag = $entry(function(e) {
					var x = e.entity.getLocation().longitude;
					var y = e.entity.getLocation().latitude;
					pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onDrag(DD)(x,y);
				});
				var draghandler = $wnd.Microsoft.Maps.Events.addHandler(pushpinJs, 'drag', ondrag);
				pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onDragHandler=draghandler;
				// remove click handler
				$wnd.Microsoft.Maps.Events.removeHandler(pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onClickHandler);

				}-*/;
	
	/**
	 * @see com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget#move(com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin, com.francetelecom.protosig.presentation.client.widget.map.model.Location)
	 */
	@Override
	public void move(Pushpin pushpin, Location newLoc) {
		pushpin.getLocation().setX(newLoc.getX());
		pushpin.getLocation().setY(newLoc.getY());
		moveInternal(pushpin.getJsPushpin(),newLoc.getX(),newLoc.getY());
	}
	
	private native void moveInternal(JavaScriptObject jsPushpin,double x, double y) /*-{
		jsPushpin.setLocation(new $wnd.Microsoft.Maps.Location(y,x));
	}-*/;
	
	/**
	 * Disable previously enabled drag and drop
	 * @param cancel : if true, put back the pushpin at its original position
	 */
	@Override
	public void disableDragAndDrop(boolean cancel) {
		if ( cancel ) {
			dragPushpin.getLocation().setX(dragLocation.getX());
			dragPushpin.getLocation().setY(dragLocation.getY());
		}
		disableDragAndDropInternal(dragText, dragPushpin, dragPushpin.getJsPushpin());
		dragPushpin.setOnDragHandler(null);
		selectPushpin(dragPushpin);
	}
	
	private native void disableDragAndDropInternal(String index,Pushpin pushpin, JavaScriptObject pushpinJs) /*-{
				// disable drag and drop
				var stdicon=pushpinJs.getIcon().replace('_drag.','.');
				pushpinJs.setOptions({draggable:false,icon:stdicon,zIndex:1});
				$wnd.Microsoft.Maps.Events.removeHandler(pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onDragHandler);
				// potentially reset the pushpin position
				var x = pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::getLocationX()();
				var y = pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::getLocationY()();
				pushpinJs.setLocation(new $wnd.Microsoft.Maps.Location(y,x));
				// enable click
				var onclick = $entry(function(e) {
					pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onClick()();
				});
				var clickhandler=$wnd.Microsoft.Maps.Events.addHandler(pushpinJs, 'click', onclick);
				pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::onClickHandler=clickhandler;
				}-*/;	
	
	private static native void clearPushpins(JavaScriptObject map) /*-{
				map.entities.clear();
				}-*/;
	
	private static native void clearPushpin(JavaScriptObject map,JavaScriptObject jsPushpin) /*-{
					map.entities.remove(jsPushpin);
				}-*/;

	private native JavaScriptObject addInfoBoxJs(Pushpin pushpin) /*-{
				var x = pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::getLocationX()();
				var y = pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::getLocationY()();
				var vwidth = 360;
				var vheight = 280;
				var location = new $wnd.Microsoft.Maps.Location(y, x);
				var uidTooltipContent = pushpin.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin::getUid()();
				var htmlContent = '<div id=\'' + uidTooltipContent + '\'></div>';
				var infoboxOptions = {
				showPointer : false,
				offset : new $wnd.Microsoft.Maps.Point(10, -70),
				description : htmlContent,
				width : vwidth,
				height : vheight,
				};
				var infobox = new $wnd.Microsoft.Maps.Infobox(location, infoboxOptions);
				// clear old tooltip
				this.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget::clearInfoBox()();
				// add new tooltip content
				var mapJs = this.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget::map;
				mapJs.entities.push(infobox);

				// add widget
				this.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget::injectWidget(Lcom/francetelecom/protosig/presentation/client/widget/map/impl/bing/Pushpin;)(pushpin);

				return infobox;
				}-*/;

	protected void injectWidget(Pushpin pushpin) {
	}

	private static native void clearInfoBox(JavaScriptObject map,
			JavaScriptObject tooltip) /*-{
				map.entities.remove(tooltip);
				}-*/;

	private native void registerViewChanged() /*-{
				var mapJs = this.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget::map;
				var that = this;
				var onchange = $entry(function(e) {
				that.@com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget::onViewChanged()();
				});
				attachmapviewchangeend = $wnd.Microsoft.Maps.Events.addHandler(mapJs,
				'viewchangeend', onchange);
				}-*/;

	// NOSONAR (does not see JSNI invocation)
	protected void onViewChanged() {
		Resource resource = retrieveResource();
		for (IViewChangeHandler callback : listener) {
			callback.onViewChanged(resource);
		}
	}

	private Resource retrieveResource() {
		JsArrayNumber bounds = getBounds(map);
		box = new Resource(new Location(bounds.get(0), bounds.get(1)),
				new MapBox(new Location(bounds.get(0) - bounds.get(2) / 2,
						bounds.get(1) + bounds.get(3) / 2), new Location(
						bounds.get(0) + bounds.get(2) / 2, bounds.get(1)
								- bounds.get(3) / 2)));
		return box;
	}

	@Override
	public IGeocoding getGeocoding() {
		return geocoding;
	}

	@Override
	public String getMapId() {
		return uid;
	}

	public JavaScriptObject getMap() {
		return map;
	}

	@Override
	public Resource getBox() {
		return box;
	}

	@Override
	public void register(IViewChangeHandler callback) {
		listener.add(callback);
	}

	@Override
	public void unregister(IViewChangeHandler callback) {
		listener.remove(callback);
	}

	@Override
	public HTMLPanel getMapPanel() {
		return mapPanel;
	}

}
