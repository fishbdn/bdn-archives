package com.francetelecom.protosig.presentation.client.widget.map;


/**
 * Geocoding interface
 * 
 * @author jcwilk
 * 
 */
public interface IGeocoding {

	/**
	 * Send a geocoding request
	 * @param id id of the request
	 * @param address adress to geocode
	 * @param callback
	 */
	void geocode(Long id,String address, IGeocodingCallback callback);

}
