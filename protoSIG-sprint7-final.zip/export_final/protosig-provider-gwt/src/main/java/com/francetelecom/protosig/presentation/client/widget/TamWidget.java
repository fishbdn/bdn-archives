package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.model.PcDto;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Visibility;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.resources.client.CssResource;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class TamWidget extends DialogBox {

	private static TamWidgetUiBinder uiBinder = GWT
			.create(TamWidgetUiBinder.class);

	interface TamWidgetUiBinder extends UiBinder<Widget, TamWidget> {
	}

	interface Style extends CssResource {
		String pair();

		String clear();

		String pairsPanel();

		String dispo();

		String red();

		String green();
	}

	// CHECKSTYLE:OFF
	@UiField
	Label centreLabel;
	@UiField
	Label headLabel;
	@UiField
	Label zoneLabel;
	@UiField
	Label amorceLabel;
	@UiField
	Label pair1Label;
	@UiField
	Label pair2Label;
	@UiField
	Label pair3Label;
	@UiField
	Label pair4Label;
	@UiField
	Label pair5Label;
	@UiField
	Label pair6Label;
	@UiField
	Label pair7Label;
	@UiField
	Style style;
	@UiField
	Button prevButton;
	@UiField
	Button nextButton;
	// CHECKSTYLE:ON

	/**
	 * First pairs displayed
	 */
	private int offset = 0;
	private PcDto pc;

	// NB : ce code étant jetable, on évite de disperser les éléments à
	// supprimer
	// dans les css et Constantes.properties, quitte à perdre des points
	// Sonar...
	public TamWidget() {
		setWidget(uiBinder.createAndBindUi(this));
		this.setModal(false);
		this.setPopupPosition(254, 0);
		this.setText("TAM");
		prevButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if (offset > 0) {
					offset -= 7;
					setPc(pc, offset);
				}
			}
		});
		nextButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				String[] pairs = pc.getPairs().split(":");
				if (offset + 7 < pairs.length) {
					offset += 7;
					setPc(pc, offset);
				}
			}
		});
	}

	// disable dragging
	@Override
	protected void beginDragging(MouseDownEvent e) {
		e.preventDefault();
	}

	public void setPc(PcDto pc, int offset) {
		this.pc = pc;
		this.offset=offset;
		setText("TAM " + pc.getName());
		centreLabel.setText(pc.getCentreCode());
		zoneLabel.setText(pc.getZoneCode());
		headLabel.setText(pc.getName().substring(3, 10));
		String[] pairs = pc.getPairs().split(":");
		if (offset > 0) {
			prevButton.getElement().getStyle()
					.setVisibility(Visibility.VISIBLE);
		} else {
			prevButton.getElement().getStyle().setVisibility(Visibility.HIDDEN);
		}
		if (offset + 7 < pairs.length) {
			nextButton.getElement().getStyle()
					.setVisibility(Visibility.VISIBLE);
		} else {
			nextButton.getElement().getStyle().setVisibility(Visibility.HIDDEN);
		}
		if (pairs.length > offset) {
			setPair(pair1Label, pairs[offset]);
			amorceLabel.setText(pairs[offset].substring(0, 2));
		} else {
			amorceLabel.setText("");
			clear(pair1Label);
		}
		if (pairs.length > offset + 1) {
			setPair(pair2Label, pairs[offset + 1]);
		} else {
			clear(pair2Label);
		}
		if (pairs.length > offset + 2) {
			setPair(pair3Label, pairs[offset + 2]);
		} else {
			clear(pair3Label);
		}
		if (pairs.length > offset + 3) {
			setPair(pair4Label, pairs[offset + 3]);
		} else {
			clear(pair4Label);
		}
		if (pairs.length > offset + 4) {
			setPair(pair5Label, pairs[offset + 4]);
		} else {
			clear(pair5Label);
		}
		if (pairs.length > offset + 5) {
			setPair(pair6Label, pairs[offset + 5]);
		} else {
			clear(pair6Label);
		}
		if (pairs.length > offset + 6) {
			setPair(pair7Label, pairs[offset + 6]);
		} else {
			clear(pair7Label);
		}
	}

	private void clear(Label label) {
		label.setText("");
		label.removeStyleName(style.dispo());
		label.removeStyleName(style.red());
		label.removeStyleName(style.green());
		label.setVisible(false);
	}

	private void setPair(Label label, String pair) {
		String[] values = pair.split("-");
		if ( values.length == 4 ) {
			String status = values[2];
			String subStatus = values[3];
			label.setVisible(true);
			label.setText(values[1] + " " + values[2] + "-" + values[3]);
			label.removeStyleName(style.dispo());
			label.removeStyleName(style.red());
			label.removeStyleName(style.green());
			if ("D".equals(status)) {
				label.addStyleName(style.dispo());
				if ("CC".equals(subStatus) || "PU".equals(subStatus)) {
					label.addStyleName(style.green());
				}
			} else {
				if ("H".equals(status)
						&& ("HS".equals(subStatus) || "SI".equals(subStatus))) {
					label.addStyleName(style.red());
				}
			}
		}
	}
}
