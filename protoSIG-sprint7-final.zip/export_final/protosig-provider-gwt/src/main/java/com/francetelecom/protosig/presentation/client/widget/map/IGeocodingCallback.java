package com.francetelecom.protosig.presentation.client.widget.map;

import com.francetelecom.protosig.presentation.client.widget.map.model.Location;

/**
 * Gets result of a geocoding request
 * @author jcwilk
 *
 */
public interface IGeocodingCallback {

	/**
	 * Geocoding succesfull
	 * @param id id of the request
	 * @param location location on the map
	 * @param confidence false if confidence is not high
	 */
	void onSuccess(Long id,Location location, boolean confidence);

	/**
	 * Geocoding failed
	 * @param id id of the request
	 */
	void onError(Long id);
}
