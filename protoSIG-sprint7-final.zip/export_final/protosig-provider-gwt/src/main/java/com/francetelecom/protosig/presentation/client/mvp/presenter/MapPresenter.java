package com.francetelecom.protosig.presentation.client.mvp.presenter;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import com.francetelecom.protosig.model.GeocodeResponseDto;
import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.EventListener;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailClosePCEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailInterventionEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.ErrorEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.FindOrHideClosestPcEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.InfoEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.InterventionGeocodingEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.MapAgendaEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.SelectInterventionEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.SwitchDragAndDropEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.WarnEvent;
import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean.Type;
import com.francetelecom.protosig.presentation.client.mvp.place.ErrorPlace;
import com.francetelecom.protosig.presentation.client.mvp.view.MapView;
import com.francetelecom.protosig.presentation.client.rpc.GenericCallback;
import com.francetelecom.protosig.presentation.client.utils.InterventionFilter;
import com.francetelecom.protosig.presentation.client.utils.geolocation.GeolocationHelper;
import com.francetelecom.protosig.presentation.client.utils.geolocation.GeolocationHelper.GeolocationCallback;
import com.francetelecom.protosig.presentation.client.widget.map.GeoTranslator;
import com.francetelecom.protosig.presentation.client.widget.map.IGeocodingCallback;
import com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.francetelecom.protosig.presentation.client.widget.map.model.MovablePositionBean;
import com.francetelecom.protosig.presentation.client.widget.map.model.PushpinType;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;

public class MapPresenter extends AbstractPresenter implements EventListener,
		IGeocodingCallback {

	private MapView view = null;

	/**
	 * List of all interventions
	 */
	private List<InterventionBean> interventions;
	private int interventionsToGeocode;
	/**
	 * selected intervention or null
	 */
	private InterventionBean interventionDetail;

	/**
	 * Ghost pushpin in case of drag and drop
	 */
	private Pushpin ghostPushpin;
	/**
	 * User pushpin in case of geolocation
	 */
	private Pushpin userPushpin;
	/**
	 * Pushpin original location in case of drag and drop
	 */
	private final Location originalLocation = new Location(0, 0);

	/**
	 * Are the closest pc currently displayed on the map ?
	 */
	private boolean closestPcDisplayed = false;
	/**
	 * List of currently displayed closest pc
	 */
	private List<PcDto> closestPc = new LinkedList<PcDto>();
	/**
	 * Pushpins associated with closest pcs
	 */
	private List<Pushpin> closestPcPushpins = new LinkedList<Pushpin>();

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		view = Application.CLIENT_FACTORY.getMapView();
		panel.setWidget(view);
		Application.CLIENT_FACTORY.getJsonEventBus().registerListener(this);
	}

	/**
	 * Try to get postal code from insee code, then call bing maps geocoding api
	 * 
	 * @param inter
	 */
	private void doInterventionGeocoding(final InterventionBean inter) {
		// SigService.geocode does insee ->postal code conversion AND
		// ORAS geocoding
		Application.CLIENT_FACTORY.getSigService().geocode(
				inter.getNumStreet(), inter.getStreetName(),
				inter.getInseeCode(), inter.getCityName(),
				new GenericCallback<GeocodeResponseDto>() {
					@Override
					protected void process(GeocodeResponseDto result) {
						if (result == null || result.getX() == null) {
							MapPresenter.this.onError((long) inter.getIndex());
							return;
						}
						Location loc = new Location(result.getX(), result
								.getY());
						switch (result.getResult()) {
						case OK:
							MapPresenter.this.onSuccess(
									(long) inter.getIndex(), loc, true);
							break;
						case CONFIDENCE:
							MapPresenter.this.onSuccess(
									(long) inter.getIndex(), loc, false);
							break;
						case KO:
							MapPresenter.this.onError((long) inter.getIndex());
							break;
						}
					}

					@Override
					public void onFailure(Throwable caught) {
						super.onFailure(caught);
						MapPresenter.this.onError((long) inter.getIndex());
					}					
				});
	}

	/**
	 * Add one POI on the map for each customer in the agenda
	 * 
	 * @param agenda
	 */
	private void displayAgenda(List<InterventionBean> interventions) {
		if (interventions == null) {
			// reset the map zoom
			view.getMap().setAutoView();
		} else {
			view.getMap().clearPushpins();
			// match position in list with position in agenda
			this.interventions = interventions;
			Collections.sort(interventions, new Comparator<InterventionBean>() {
				@Override
				public int compare(InterventionBean arg0, InterventionBean arg1) {
					if (arg0 == null && arg1 == null) {
						return 0;
					} else if (arg0 == null || arg1 == null) {
						return -1;
					}
					return arg0.getIndex() - arg1.getIndex();
				}
			});
			// count number of interventions to geocode
			interventionsToGeocode = 0;
			for (InterventionBean inter : interventions) {
				if (InterventionFilter.isInterventionOk(inter
						.getLocalStorageInter())) {
					interventionsToGeocode++;
				}
			}
			// first compute postal code from insee code
			for (InterventionBean inter : interventions) {
				if (InterventionFilter.isInterventionOk(inter
						.getLocalStorageInter())) {
					doInterventionGeocoding(inter);
				}
			}
		}
	}

	/**
	 * Add a pushpin on the map for intervention index at position x,y. If all
	 * pushpins are created, reset the map zoom
	 * 
	 * @param index
	 *            intervention index
	 * @param location
	 * @param confidence
	 *            false if confidence is not high
	 */
	public void addInterventionPushpin(int index, Location location,
			boolean confidence) {
		InterventionBean inter = interventions.get(index - 1);
		interventionsToGeocode--;
		if (location != null) {
			Pushpin pushpin = new Pushpin((long) index, -1L,
					inter.getConfidence() ? PushpinType.customer
							: PushpinType.customer_warn, location, true);
			view.getMap().add(pushpin);

		}
		if (interventionsToGeocode == 0) {
			// all the interventions have been located. auto-zoom
			view.getMap().setAutoView();
		}
	}

	/**
	 * Display the clients for all intervention with auto-zoom
	 * 
	 * @param unselectAll
	 *            unselect all interventions
	 */
	private void resetMap(boolean unselectAll) {
		if (unselectAll) {
			// hide intervention network elements
			for (InterventionBean inter : interventions) {
				inter.setShowDetail(false);
			}
			// redraw pushpins
			resetPushpins();
		}
		// reset the map zoom
		view.getMap().setAutoView();
	}

	/**
	 * Return pushpin type for given device type
	 * 
	 * @param deviceType
	 * @return
	 */
	private PushpinType getPushpinTypeFromDeviceType(
			NetworkDeviceBean.Type deviceType) {
		PushpinType type = PushpinType.defaultType;
		switch (deviceType) {
		case PC:
			type = PushpinType.pc;
			break;
		case SR:
		case SRI:
		case SRS:
		case SRP:
		case SRZ:
			type = PushpinType.sr;
			break;
		case RE:
			type = PushpinType.re;
			break;
		default:
			break;
		}
		return type;
	}

	/**
	 * Display network elements (PC,SR,RE) for the intervention
	 * 
	 * @param intervention
	 */
	private void displayInterventionNetworkPushpins(
			InterventionBean intervention) {
		// add network elements
		long deviceIndex = 0;
		for (NetworkDeviceBean device : intervention.getDevices()) {
			PushpinType type = getPushpinTypeFromDeviceType(device.getType());
			Pushpin pushpin = new Pushpin((long) intervention.getIndex(),
					deviceIndex, type, device.getLocation(), false);
			device.setPushpin(pushpin);
			view.getMap().add(pushpin);
			if (device.getType() == Type.PC && device.getOriginalX() != null) {
				// pc has been moved. Add ghost pushpin at original pc
				// position
				createGhostPushpin(intervention, device,
						device.getOriginalLocation());
			}

			deviceIndex++;
		}
	}

	/**
	 * Display customer + network devices pushpins for an intervention
	 * 
	 * @param intervention
	 */
	private void displayInterventionPushpins(InterventionBean intervention) {
		if (intervention.getLocation() != null) {
			// add customer pushpin
			intervention.setCustomerPushpin(new Pushpin((long) intervention
					.getIndex(), -1L,
					intervention.getConfidence() ? PushpinType.customer
							: PushpinType.customer_warn, intervention
							.getLocation(), !intervention.isShowDetail()));
			view.getMap().add(intervention.getCustomerPushpin());
			if (intervention.isShowDetail()) {
				if ( intervention.getOriginalX() != null) {
					// customer has been moved. Add ghost pushpin at original
					// customer position
					createGhostPushpin(intervention, null,
							intervention.getOriginalLocation());
				}

				if (intervention.getDevices() != null) {
					// display other network elements
					displayInterventionNetworkPushpins(intervention);
				}
			}
		}			
	}

	/**
	 * Redraw all pushpins on the map
	 */
	private void resetPushpins() {
		// remove all pushpins
		view.getMap().clearPushpins();
		closestPcDisplayed = false;
		closestPc.clear();
		userPushpin = null;
		// add all intervention customers pushpins
		boolean hasDetail = false;
		for (InterventionBean intervention : interventions) {
			// display a single intervention with network devices
			if (intervention.isShowDetail()) {
				hasDetail = true;
				displayInterventionPushpins(intervention);
			}
		}
		if (!hasDetail) {
			for (InterventionBean intervention : interventions) {
				// display only interventions customers
				displayInterventionPushpins(intervention);
			}
		}
	}

	/**
	 * Display network elements of an intervention on the map
	 * 
	 * @param inter
	 */
	private void showIntervention(int interId) {
		for (int id = 1; id <= interventions.size(); id++) {
			if (id != interId) {
				hideIntervention(id, false);
			}
		}
		interventionDetail = interventions.get(interId - 1);
		if (interventionDetail == null) {
			return;
		}
		if (!interventionDetail.getConfidence()) {
			// display warning
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new WarnEvent(Application.CONSTANTS
							.intervention_confidence()));
		} else {
			// send an empty message to erase any existing warning
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new WarnEvent(null));
		}
		if (interventionDetail.getDevices() == null) {
			interventionDetail
					.setDevices(Application.CLIENT_FACTORY
							.getInterventionBeanFactory().getDetail(
									interventionDetail));
		}
		if (interventionDetail.getDevices() == null
				|| interventionDetail.getDevices().size() == 0) {
			// display error icon on the intervention
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new InterventionGeocodingEvent(interId,
							InterventionGeocodingEvent.Level.NO_ANSWER));
			// cannot find railroad. display error message
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new WarnEvent(Application.CONSTANTS.intervention_nodetail()
							+ " " + interventionDetail.getIndex()));
		}
		interventionDetail.setShowDetail(true);
		resetPushpins();
		view.getMap().setAutoView();
	}

	/**
	 * Remove network elements for an intervention on the map
	 * 
	 * @param inter
	 */
	private void hideIntervention(int interId, boolean updateZoom) {
		InterventionBean inter = interventions.get(interId - 1);
		resetPushpins();
		if (updateZoom) {
			view.getMap().setAutoView();
		}
		if (inter == null) {
			return;
		}
		inter.setShowDetail(false);
	}

	/**
	 * Use HTML5 geolocation API to get user position and displays it on the map
	 */
	private void displayUserPos() {
		// display user position
		GeolocationHelper.getPosition(new GeolocationCallback() {
			@Override
			public void onSuccess(Double x, Double y) {
				if (userPushpin == null) {
					userPushpin = new Pushpin(-1L, -1L, PushpinType.user,
							new Location(x, y), false);
					view.getMap().add(userPushpin);
					view.getMap().setAutoView();
				} else {
					view.getMap().move(userPushpin, new Location(x, y));
				}
			}

			@Override
			public void onError() {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new WarnEvent(Application.CONSTANTS.nogeoloc()));
			}

			@Override
			public void onCancel() {
				// permission refused
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new InfoEvent(Application.CONSTANTS.geolocRefused()));
			}
		});
	}

	/**
	 * Create a semi-transparent pushpin for the customer or device
	 * 
	 * @param inter
	 *            holds customer position if device is null
	 * @param device
	 *            holds device position
	 */
	private void createGhostPushpin(InterventionBean inter,
			NetworkDeviceBean device, Location loc) {
		PushpinType ghostPushpinType;
		if (device == null) {
			ghostPushpinType = inter.getConfidence() ? PushpinType.customer_trans
					: PushpinType.customer_warn_trans;
		} else {
			ghostPushpinType = PushpinType.pc_trans;
		}
		ghostPushpin = new Pushpin(-1L, -1L, ghostPushpinType, loc, false);
		view.getMap().add(ghostPushpin);
	}

	/**
	 * Disable drag and drop for a customer or pc
	 * 
	 * @param intervention
	 *            the intervention containing the customer pushpin
	 * @param device
	 *            if pc, the device containing the pushpin
	 * @param moveBean
	 *            bean associated with the moved pushpin
	 * @param cancel
	 *            whether movement must be canceled
	 */
	private void disableDragAndDrop(InterventionBean intervention,
			NetworkDeviceBean device, MovablePositionBean moveBean,
			boolean cancel) {
		// disable drag and drop
		view.getMap().disableDragAndDrop(cancel);
		if (cancel) {
			// remove the ghost pushpin
			if (moveBean.getOriginalLocation() == null) {
				view.getMap().remove(ghostPushpin);
			}
		} else {
			// save customer/pc position in local storage
			if (moveBean.getOriginalLocation() == null) {
				moveBean.setOriginalX(originalLocation.getX());
				moveBean.setOriginalY(originalLocation.getY());
			}
			try {
				if (device == null) {
					Application.CLIENT_FACTORY.getLocalStorage()
							.saveCustomerPos(intervention);
				} else {
					Application.CLIENT_FACTORY.getLocalStorage().savePcPos(
							intervention, device);
				}
			} catch (ClientFunctionalException e) {
				Application.CLIENT_FACTORY.getPlaceController().goTo(
						new ErrorPlace(e));
			}
		}
	}

	/**
	 * Enable or disable drag and drop on the pushpin
	 * 
	 * @param intervention
	 *            : intervention containing the customer pushpin
	 * @param device
	 *            : if not null, device containing the pc pushpin
	 * @param x
	 *            : where to move the pushpin before enabling drag and drop
	 * @param y
	 *            : where to move the pushpin before enabling drag and drop
	 */
	private void switchDragAndDrop(InterventionBean intervention,
			NetworkDeviceBean device, Double x, Double y, boolean cancel) {
		Pushpin pushpin = null;
		MovablePositionBean moveBean;
		// get the pushpin
		if (device != null) {
			pushpin = device.getPushpin();
			moveBean = device;
		} else {
			pushpin = intervention.getCustomerPushpin();
			moveBean = intervention;
		}
		if (pushpin.isDragAndDropActive()) {
			disableDragAndDrop(intervention, device, moveBean, cancel);
		} else {
			// enable drag and drop
			if (moveBean.getOriginalX() == null) {
				// create a ghost pushpin at original location
				originalLocation.setX(moveBean.getLocation().getX());
				originalLocation.setY(moveBean.getLocation().getY());
				createGhostPushpin(intervention, device, originalLocation);
			}
			// enable drag and drop
			view.getMap().enableDragDrop(pushpin);
			if (x != null) {
				// move the pushpin to a new position
				view.getMap().move(pushpin, new Location(x, y));
				view.getMap().updateView(x, y);
			}
		}
	}

	private void switchDragAndDropClosePc(PcDto pc, Double x, Double y, boolean cancel) {
		Pushpin pushpin = null;
		// get the pushpin
		int index=0;
		for (PcDto pcDto:closestPc) {
			if ( pcDto.equals(pc) ) {
				pushpin=closestPcPushpins.get(index);
				break;
			}
			index++;
		}
		if (pushpin.isDragAndDropActive()) {
			view.getMap().disableDragAndDrop(cancel);
		} else {
			// enable drag and drop
			view.getMap().enableDragDrop(pushpin);
			if (x != null) {
				// move the pushpin to a new position
				view.getMap().move(pushpin, new Location(x, y));
				view.getMap().updateView(x, y);
			}
		}
	}
	/**
	 * SmartEventBus event processing callback
	 */
	@Override
	public void handleEvent(GenericEvent<?> event) {
		switch (event.getType()) {
		case INTER_SELECT:
			SelectInterventionEvent interEvent = (SelectInterventionEvent) event;
			if (interEvent.isSelected()) {
				showIntervention(interEvent.getData());
			} else {
				hideIntervention(interEvent.getData(), true);
			}
			break;
		case INTER_DETAIL :
			// display network elements for an intervention
			DetailInterventionEvent detailEvent=(DetailInterventionEvent)event;
			if ( detailEvent.getData() != -1L ) {
				int interIndex=detailEvent.getData().intValue()-1;
				int deviceIndex=detailEvent.getDeviceIndex().intValue();
				Pushpin pushpin=null;
				if ( deviceIndex == -1 ) {
					// select customer icon
					pushpin=interventions.get(interIndex).getCustomerPushpin();
				} else {
					// select device icon
					pushpin=interventions.get(interIndex).getDevices().get(deviceIndex).getPushpin();
				}
				if ( pushpin  != null ) {
					view.getMap().selectPushpin(pushpin);
				}
			}
			break;
		case MAP_AGENDA:
			MapAgendaEvent mapEvent = (MapAgendaEvent) event;
			displayAgenda(mapEvent.getData());
			break;
		case REFRESH_MAP:
			resetMap(true);
			break;
		case RESET_MAP_ZOOM:
			resetMap(false);
			break;
		case DISPLAY_USER_POS:
			displayUserPos();
			break;
		case CLOSEST_PC:
			FindOrHideClosestPcEvent closestEvent = (FindOrHideClosestPcEvent) event;
			findOrHideClosestPc(closestEvent.getData(), closestEvent.getPos());
			break;
		case SWITCH_DND:
			SwitchDragAndDropEvent ddEvent = (SwitchDragAndDropEvent) event;
			if ( ddEvent.getPc() != null ) {
				// drag and drop a close pc
				switchDragAndDropClosePc(ddEvent.getPc(), ddEvent.getX(), ddEvent.getY(), ddEvent.isCancel());
			} else {
				// drag and drop intervention customer or pc
				switchDragAndDrop(ddEvent.getData(), ddEvent.getDevice(),
					ddEvent.getX(), ddEvent.getY(), ddEvent.isCancel());
			}
			break;
		case CLOSE_PC_DETAIL :
			if (!closestPc.isEmpty()) {
				DetailClosePCEvent detailClosePCEvent=(DetailClosePCEvent)event;
				// wrap around
				long index = detailClosePCEvent.getData()-1;
				if (index < 0) {
					index = closestPc.size()-1;
				} else if ( index >= closestPc.size()) {
					index=0;
				}
				// add pc data in the event and forward to SidebarPresenter
				detailClosePCEvent.setData(index+1);
				detailClosePCEvent.setPc(closestPc.get((int)index));
				view.getMap().selectPushpin(closestPcPushpins.get((int)index));
			}
			break;
		default:
			break;
		}
	}

	/**
	 * RPC callback displaying pc pushpins
	 * 
	 * @author jcwilk
	 * 
	 */
	private class FindClosestPcCallback extends GenericCallback<List<PcDto>> {
		@Override
		protected void process(List<PcDto> result) {
			if (result.size() == 0) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new InfoEvent(Application.CONSTANTS.no_close_pc()));
				return;
			}
			view.getMap().startView();
			long index=1;
			closestPc.clear();
			closestPcPushpins.clear();
			
			for (PcDto pc:result) {
				// convert coordinates to WGS84
				double[] wgs84Coords = GeoTranslator
						.convertLambert2eToWGS84(pc.getX(), pc.getY());
				pc.setX(wgs84Coords[0]);
				pc.setY(wgs84Coords[1]);
			}

			for (PcDto pc:result) {
				// don't overwrite the PC already associated with
				// the intervention
				boolean display = true;
				for (NetworkDeviceBean device : interventionDetail.getDevices()) {
					if (NetworkDeviceBean.Type.PC.equals(device.getType())
							&& hasSamePosition(pc, device)) {
						display = false;
						break;
					}
				}
				if (display) {
					// check if overlapping another close pc
					boolean multi = false;
					for (PcDto pc2 : result) {
						if (pc == pc2) {
							continue;
						}
						if (hasSamePosition(pc, pc2)) {
							multi = true;
							break;
						}
					}
					// add a new pushpin for this PC
					PushpinType type;
					if (multi) {
						if (pc.isFull()) {
							type = PushpinType.closepcs_full;
						} else {
							type = PushpinType.closepcs_dispo;
						}
					} else {
						if (pc.isFull()) {
							type = PushpinType.closepc_full;
						} else {
							type = PushpinType.closepc_dispo;
						}
					}
					Pushpin pcPushpin=new Pushpin(index, index, type, new Location(
							pc.getX(), pc.getY()), true);
					closestPcDisplayed = true;
					closestPc.add(pc);
					closestPcPushpins.add(pcPushpin);
					index++;
				}
			}
			// display pushpins in reverse order so that closest pc are on top
			for ( int i=closestPcPushpins.size()-1; i >=0; i--) {
				Pushpin pcPushpin=closestPcPushpins.get(i);
				view.getMap().add(pcPushpin);
			}
			view.getMap().endView();
		}

		@Override
		public void onFailure(Throwable caught) {
			super.onFailure(caught);
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new ErrorEvent("Impossible de récupérer les données :"
							+ caught.getMessage()));
		}
	};

	/**
	 * Check if the PC is the same as the PC from the intervention
	 * 
	 * @param pc
	 * @param device
	 * @return true if pc's position matches the device's one
	 */
	private boolean hasSamePosition(PcDto pc, NetworkDeviceBean device) {
		if (device.getLocation().isEquivalent(pc.getX(), pc.getY())) {
			return true;
		}
		if (device.getOriginalLocation() != null
				&& device.getOriginalLocation().isEquivalent(pc.getX(),
						pc.getY())) {
			return true;
		}
		return false;
	}

	/**
	 * Check if the PC is the same as the PC from the intervention
	 * 
	 * @param pc
	 * @param device
	 * @return true if pc's position matches the device's one
	 */
	private boolean hasSamePosition(PcDto pc, PcDto pc2) {
		Location loc2 = new Location(pc2.getX(), pc2.getY());
		if (loc2.isEquivalent(pc.getX(), pc.getY())) {
			return true;
		}
		return false;
	}

	/**
	 * Get PC close to a position from server
	 * 
	 * @param dr
	 * @param x
	 * @param y
	 */
	private void findOrHideClosestPc(String dr, final Location pos) {
		if (closestPcDisplayed) {
			resetPushpins();
		} else {
			Application.CLIENT_FACTORY.getSigService().getClosestPC(dr,
					pos.getX(), pos.getY(), new FindClosestPcCallback());
		}
	}

	/**
	 * IGeocodingCallback success callback
	 */
	@Override
	public void onSuccess(Long id, Location location, boolean confidence) {
		InterventionBean inter = interventions.get(id.intValue() - 1);
		inter.setConfidence(confidence);
		double[] wgs84Coords = GeoTranslator.convertLambert2eToWGS84(
				location.getX(), location.getY());
		// need lambert coordinates to find closest pc
		inter.setLambertLocation(new Location(location.getX(), location.getY()));
		// and wgs84 for bing map
		inter.setLocation(new Location(wgs84Coords[0], wgs84Coords[1]));
		// check if there is local data for this intervention
		try {
			Application.CLIENT_FACTORY.getLocalStorage().updateIntervention(
					inter);
		} catch (ClientFunctionalException e) {
			Application.CLIENT_FACTORY.getPlaceController().goTo(
					new ErrorPlace(e));
		}

		addInterventionPushpin(id.intValue(), inter.getLocation(), confidence);
		if (!confidence) {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new InterventionGeocodingEvent(id.intValue(),
							InterventionGeocodingEvent.Level.LOW_CONFIDENCE));
		} else {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new InterventionGeocodingEvent(id.intValue(),
							InterventionGeocodingEvent.Level.OK));
		}
	}

	/**
	 * IGeocodingCallback error callback
	 */
	@Override
	public void onError(Long id) {
		addInterventionPushpin(id.intValue(), null, true);
		InterventionBean inter = interventions.get(id.intValue() - 1);
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				new WarnEvent(Application.CONSTANTS.intervention_nogeoloc()
						+ " " + inter.getEtechReference()));
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				new InterventionGeocodingEvent(id.intValue(),
						InterventionGeocodingEvent.Level.NO_ANSWER));
	}

}
