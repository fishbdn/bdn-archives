package com.francetelecom.protosig.presentation.client.widget.map.model;

/**
 * Location
 * 
 * @author JLZB1407
 * 
 */
public class Location {

	private static final Double EPSILON=1E-10;
	
	private double x;
	private double y;

	public Location(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "location:long=" + x + ";lat=" + y;
	}
	
	/**
	 * Check if two position are close enough to be considered equal
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean isEquivalent(Double x, Double y) {
		if ( Math.abs(x-this.x) > EPSILON ) {
			return false;
		}
		if ( Math.abs(y-this.y) > EPSILON ) {
			return false;
		}
		return true;
	}

	@Override
	public boolean equals(Object obj) {
		if ( ! (obj instanceof Location ) ) {
			return false;
		}
		Location lobj=(Location)obj;
		return (x == lobj.getX() && y == lobj.getY());
	}

	@Override
	public int hashCode() {
		if (x == 0 || y == 0) {
			return 0;
		}
		return new Double(x).hashCode() + 13 * new Double(y).hashCode();
	}

}
