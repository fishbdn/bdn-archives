package com.francetelecom.protosig.presentation.client.eventbus.event;


/**
 * Displays a temporary error message
 * @author jcwilk
 *
 */
public class ErrorEvent extends MessageEvent {
	public ErrorEvent(String message) {
		super(Severity.ERROR,message);
	}
}
