package com.francetelecom.protosig.presentation.client.widget.map.impl.bing;

/**
 * Authorization
 * 
 * @author jcwilk
 * 
 */
public final class Authorization {
	/**
	 * Prevent someone to instanciate this class
	 */
	private Authorization() {
	}

	// protosig trial key
	//public static final String AUTH_KEY="Ah2r-jkb8owDbO5tm-Pw29uL5qrk29tZ_4iWFgW61VLpU487P_vm1cD3sGpPBchw";
	// orange business key
	public static final String AUTH_KEY="AjkmjccteDNRqN8eJio9EHK-A9bmJILZwQChXXPQ5s32tZZgkJO-CUkiTIA0La3E";
}
