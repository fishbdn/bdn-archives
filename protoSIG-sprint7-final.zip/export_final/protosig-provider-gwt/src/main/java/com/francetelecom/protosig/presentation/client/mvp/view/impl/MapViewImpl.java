package com.francetelecom.protosig.presentation.client.mvp.view.impl;

import com.francetelecom.protosig.presentation.client.mvp.view.MapView;
import com.francetelecom.protosig.presentation.client.widget.map.AbstractMapWidget;
import com.francetelecom.protosig.presentation.client.widget.map.impl.bing.MapWidget;
import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Widget;

public class MapViewImpl extends AbstractViewImpl implements MapView {
	interface MapUiBinder extends UiBinder<Widget, MapViewImpl> {
	}

	private static MapUiBinder uiBinder = GWT.create(MapUiBinder.class);

	// CHECKSTYLE:OFF
	@UiField(provided = true)
	protected final MapWidget map;
	// CHECKSTYLE:ON

	/**
	 * Map view constructor.
	 */
	public MapViewImpl() {
		map = new MapWidget();
		initWidget(uiBinder.createAndBindUi(this));
	}
	
	@Override
	public AbstractMapWidget getMap() {
		return map;
	}
	
}
