package com.francetelecom.protosig.presentation.client.eventbus;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.francetelecom.protosig.model.exception.ClientException;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.exception.ClientTechnicalException;
import com.francetelecom.protosig.presentation.client.mvp.place.ErrorPlace;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;

/**
 * Client-side event bus where listeners subscriptions are defined in a .json file (json/events.json).
 * No dynamic subscription/unsubscription to make it easier to know what happens when an event is published
 * 
 * @author jcwilk
 * 
 */
public class JsonEventBus {

	/**
	 * Associates a listener to its class name
	 */
	private final Map<String, EventListener> listeners = new HashMap<String, EventListener>();
	/**
	 * Associates an event type to a list of listener class names
	 */
	private Map<GenericEvent.Type, List<String>> subscriptions = null;
	/**
	 * Events published before the subscription file is read
	 */
	private final List<GenericEvent<?>> pendingEvents = new LinkedList<GenericEvent<?>>();

	/**
	 * Publish a data-less event to all subscribed listeners
	 * 
	 * @param type the event type
	 */
	public void publishEvent(GenericEvent.Type type) {
		publishEvent(new GenericEvent<Void>(type, null),false);
	}

	public <T> void publishEvent(GenericEvent<T> event) {
		publishEvent(event,false);
	}
	
	/**
	 * Publish an event, calling all subscribed listeners
	 * 
	 * @param event the event
	 */
	public <T> void publishEvent(GenericEvent<T> event, boolean pending) {
		if (subscriptions == null) {
			// subscription file not yet read
			pendingEvents.add(event);
		} else {
			List<String> subscribed = subscriptions.get(event.getType());
			if (subscribed != null) {
				for (String listenerName : subscribed) {
					EventListener listener = listeners.get(listenerName);
					if (listener == null) {
						if (!pending) {
							// a subscriber has not yet registered
							pendingEvents.add(event);
						} else {
							Application.CLIENT_FACTORY.getPlaceController().goTo(
								new ErrorPlace(
										new ClientTechnicalException(
												"unregistered listener "
														+ listenerName
														+ " for event "+event.getType().name())));
						}
					} else {
						listener.handleEvent(event);
					}
				}
			}
		}
	}

	/**
	 * Register a new listener
	 * 
	 * @param listenerName
	 * @param listener
	 */
	public void registerListener(EventListener listener) {
		listeners.put(listener.getClass().getName(), listener);
		if ( subscriptions != null ) {
			processPendingEvents(true);
		}
	}

	/**
	 * Create a json event bus, reading subscriptions from json/events.json
	 * 
	 */
	public JsonEventBus() {
		RequestBuilder rb = new RequestBuilder(RequestBuilder.GET,
				"json/events.json?t=" + new Date().getTime());
		rb.setCallback(new RequestCallback() {

			@Override
			public void onResponseReceived(Request request, Response response) {
				try {
					parseJson(response.getText());
				} catch (ClientException e) {
					Application.CLIENT_FACTORY.getPlaceController().goTo(
							new ErrorPlace(e));
				}
			}

			@Override
			public void onError(Request request, Throwable exception) {
				Application.CLIENT_FACTORY.getPlaceController().goTo(
						new ErrorPlace(exception));
			}
		});
		try {
			rb.send();
		} catch (RequestException e) {
			Application.CLIENT_FACTORY.getPlaceController().goTo(
					new ErrorPlace(e));
		}
	}

	/**
	 * Read subscriptions from json/events.json. Populates the subscriptions map
	 * 
	 * @param json
	 * @throws ClientException
	 */
	private void parseJson(String json) throws ClientException {
		JSONValue root = JSONParser.parseStrict(json);
		JSONObject object = root.isObject();
		if (object == null) {
			throw new ClientException("Syntax error in events.json");
		}
		subscriptions = new HashMap<GenericEvent.Type, List<String>>();
		for (String key : object.keySet()) {
			GenericEvent.Type type = GenericEvent.Type.valueOf(key);
			JSONArray array = object.get(key).isArray();
			if (array == null) {
				throw new ClientException("Syntax error in events.json");
			}
			List<String> subscribed = subscriptions.get(key);
			if (subscribed == null) {
				subscribed = new LinkedList<String>();
				subscriptions.put(type, subscribed);
			}
			for (int i = 0; i < array.size(); i++) {
				JSONString value = array.get(i).isString();
				if (value != null) {
					subscribed.add(value.stringValue());
				}
			}
		}
		processPendingEvents(false);
	}
	
	private void processPendingEvents(boolean pending) {
		// process pending events
		for (GenericEvent<?> event : pendingEvents) {
			publishEvent(event,pending);
		}
		pendingEvents.clear();
	}

}
