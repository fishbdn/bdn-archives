package com.francetelecom.protosig.presentation.client.eventbus.event;

import com.francetelecom.protosig.presentation.client.widget.map.model.Location;



/**
 * Event triggered when the user wants to look for pc close to a position
 * @author jcwilk
 *
 */
public class FindOrHideClosestPcEvent extends GenericEvent<String> {
	private final Location pos;
	public FindOrHideClosestPcEvent(String dr, Location pos) {
		super(GenericEvent.Type.CLOSEST_PC, dr);
		this.pos=pos;
	}
	public Location getPos() {
		return pos;
	}
	
}
