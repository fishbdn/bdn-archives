package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.FindOrHideClosestPcEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.MapAgendaEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.SwitchDragAndDropEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.UIModeEvent;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.rpc.GenericMessageCallback;
import com.francetelecom.protosig.presentation.client.ui.SiteUI;
import com.francetelecom.protosig.presentation.client.widget.map.GeoTranslator;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.InlineHTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class InterventionDetailWidget extends AbstractMethodChooseWidget {

	private static final String CSS_STYLE_TITLE = "title";
	private static final String CSS_STYLE_HELP = "help";
	private static final String CSS_STYLE_HELP_ICON = "helpIcon";
	private static final String CUSTOMER_DRAG_ICON = "images/pushpin_customer_drag.png";
	private static final int LEGEND_AUTOCLOSE_DELAY = 3000;

	private static InterventionDetailWidgetUiBinder uiBinder = GWT
			.create(InterventionDetailWidgetUiBinder.class);

	interface InterventionDetailWidgetUiBinder extends
			UiBinder<Widget, InterventionDetailWidget> {
	}

	// CHECKSTYLE:OFF
	@UiField
	protected Button refreshButton;
	@UiField
	protected Button backButton;
	@UiField
	protected FlowPanel legendPanel;
	@UiField
	protected Image legend;
	@UiField
	protected Button legendButton;
	@UiField
	protected Button localizeButton;
	@UiField
	protected Button clientPosButton;
	@UiField
	protected Button findPcButton;
	@UiField
	protected Button editButton;
	@UiField
	protected Button saveButton;
	@UiField
	protected Button cancelButton;
	@UiField
	protected FlowPanel detailContentPanel;
	// CHECKSTYLE:ON
	private final JsonFormWidget formWidget;

	private boolean legendIsOpen = true;
	/**
	 * Is drag and drop enabled ?
	 */
	private boolean dragAndDrop = false;
	/**
	 * Current intervention
	 */
	private InterventionBean intervention;
	/**
	 * focused network device or null if focus is on customer
	 */
	private NetworkDeviceBean device;

	public InterventionDetailWidget() {
		initWidget(uiBinder.createAndBindUi(this));
		// center the map
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						GenericEvent.Type.RESET_MAP_ZOOM);
			}
		});
		// go back to agenda view
		backButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if (dragAndDrop) {
					// cancel and drop
					Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
							new SwitchDragAndDropEvent(intervention, device,
									null, null, true));
				}
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new MapAgendaEvent(null));
			}
		});
		// display user position
		localizeButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						GenericEvent.Type.DISPLAY_USER_POS);
			}
		});
		// find pc close to the customer
		findPcButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Location pos;
				// always use the customer position
				pos = intervention.getLocation();
				double [] coords=GeoTranslator.convertWGS84ToLambert2e(pos.getX(), pos.getY());
				String dr = intervention.getCodeBase();
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new FindOrHideClosestPcEvent(dr, new Location(coords[0],coords[1])));
			}
		});
		formWidget = new JsonFormWidget();
		legend.setUrl(GWT.getHostPageBaseURL() + "images/legend2.png");
		// open / close legend
		legendButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				if (legendIsOpen) {
					closeLegend();
				} else {
					openLegend();
				}
			}
		});
		// go to customer/pc form view
		editButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				if (intervention == null) {
					return;
				}
				SiteUI.Mode mode = (device == null ? SiteUI.Mode.EDIT_CUSTOMER
						: SiteUI.Mode.EDIT_PC);
				// display edit customer/pc form
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new UIModeEvent(mode, intervention, device));
			}
		});
		// enable customer/pc drag and drop
		clientPosButton.addClickHandler(moveHandler);
		// cancel drag and drop action
		cancelButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new SwitchDragAndDropEvent(intervention, device, null,
								null, true));
				setIntervention(intervention, device == null ? -1 : device
						.getId().intValue());
			}
		});
		// validate drag and drop action
		saveButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new SwitchDragAndDropEvent(intervention, device, null,
								null, false));
				setIntervention(intervention, device == null ? -1 : device
						.getId().intValue());
				if (device != null) {
					// save new pc position in database
					// primary key = 42C base code + PN reference
					String id = intervention.getCodeBase() + "|"
							+ device.getName();
					Application.CLIENT_FACTORY.getSigService().savePcLocation(id, 
							device.getOriginalLocation().getX(),
							device.getOriginalLocation().getY(),
							device.getLocation().getX(), 
							device.getLocation().getY(), 
							new GenericMessageCallback<Void>(
									Application.CONSTANTS.pc_moved(),
									Application.CONSTANTS.pc_updated_error()));
				}
			}
		});

		// automatically display, then hide the legend on first display
		openLegend();
		Timer t = new Timer() {

			@Override
			public void run() {
				closeLegend();
			}
		};
		t.schedule(LEGEND_AUTOCLOSE_DELAY);
	}

	@Override
	protected void enableDragAndDrop(Double x, Double y) {
		// enable drag and drop listening on the customer or pc
		// pushpin
		if (device != null) {
			setPcMove();
		} else {
			setCustomerMove();
		}
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				new SwitchDragAndDropEvent(intervention, device, x, y, false));
	}

	// TODO factorize legend with AgendaWidget
	private void openLegend() {
		// legend animation uses CSS3 transition on top css property
		legendPanel.addStyleName("open");
		legendIsOpen = true;
	}

	private void closeLegend() {
		legendPanel.removeStyleName("open");
		legendIsOpen = false;
	}

	/**
	 * Display detail information about the customer or a network device
	 * 
	 * @param inter
	 *            intervention bean
	 * @param deviceIndex
	 *            -1 if customer, else device index in inter.getDevices()
	 */
	public void setIntervention(InterventionBean inter, int deviceIndex) {
		detailContentPanel.clear();

		// set footer button bar
		clientPosButton.setVisible(true);
		editButton.setVisible(true);
		findPcButton.setVisible(true);
		saveButton.setVisible(false);
		cancelButton.setVisible(false);
		this.intervention = inter;

		// display/hide relevant buttons
		if (deviceIndex >= 0) {
			this.device = inter.getDevices().get(deviceIndex);
			switch (device.getType()) {
			case PC:
				clientPosButton.setVisible(true);
				editButton.setVisible(true);
				findPcButton.setVisible(true);
				break;
			default:
				clientPosButton.setVisible(false);
				editButton.setVisible(false);
				findPcButton.setVisible(false);
				break;
			}
		} else {
			this.device = null;
			clientPosButton.setVisible(true);
			editButton.setVisible(true);
			findPcButton.setVisible(true);
		}
		// build the generic form
		formWidget.setForm(inter, deviceIndex);
		detailContentPanel.add(formWidget);
		dragAndDrop = false;
	}

	/**
	 * Display help information about how to change the customer position
	 */
	public void setCustomerMove() {
		setHelpScreen(Application.CONSTANTS.customerMove_title(),
				CUSTOMER_DRAG_ICON, Application.CONSTANTS.customerMove_text());
	}

	/**
	 * Display help information about how to change the PC position
	 */
	public void setPcMove() {
		setHelpScreen(Application.CONSTANTS.pcMove_title(), PC_DRAG_ICON,
				Application.CONSTANTS.pcMove_text());
	}

	/**
	 * Display help information about how to change a map element's position
	 * 
	 * @param title
	 * @param icon
	 *            relative path to the icon to display
	 * @param text
	 *            text to display (\n will be converted to &lt;br/&gt;)
	 */
	public void setHelpScreen(String title, String icon, String text) {
		detailContentPanel.clear();
		// change footer buttons bar
		clientPosButton.setVisible(false);
		editButton.setVisible(false);
		findPcButton.setVisible(false);
		saveButton.setVisible(true);
		cancelButton.setVisible(true);

		// add title
		Label titleWidget = new Label(title);
		titleWidget.addStyleName(CSS_STYLE_TITLE);
		detailContentPanel.add(titleWidget);

		// add icon
		Image img = new Image(GWT.getHostPageBaseURL() + icon);
		img.addStyleName(CSS_STYLE_HELP_ICON);
		detailContentPanel.add(img);

		// add text
		InlineHTML textWidget = new InlineHTML(text.replaceAll("\\n", "<br />"));
		textWidget.addStyleName(CSS_STYLE_HELP);
		detailContentPanel.add(textWidget);
		dragAndDrop = true;
	}
}
