package com.francetelecom.protosig.presentation.client.mvp.model;

import com.francetelecom.protosig.presentation.client.widget.map.impl.bing.Pushpin;
import com.francetelecom.protosig.presentation.client.widget.map.model.Location;
import com.francetelecom.protosig.presentation.client.widget.map.model.MovablePositionBean;

public class NetworkDeviceBean extends MovablePositionBean {

	public enum Type {
		CLI,DTI,PC,SR,SRI,SRP,SRZ,SRS,RE,REHD
	};
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8138546213669135361L;
	
	private final Type type;
	private String name;
	private Pushpin pushpin;

	public NetworkDeviceBean(int index, String name, Type type,Location loc) {
		setLocation(loc);
		setId((long)index);
		this.name=name;
		this.type=type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Type getType() {
		return type;
	}

	public Pushpin getPushpin() {
		return pushpin;
	}

	public void setPushpin(Pushpin pushpin) {
		this.pushpin = pushpin;
	}

}
