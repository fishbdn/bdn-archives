package com.francetelecom.protosig.presentation.client.ui;

import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.widget.EditCustomerWidget;
import com.francetelecom.protosig.presentation.client.widget.EditPcWidget;
import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * Site UI widget. It is split into several widget containers: <li>sideBar :
 * holds the side bar widgets</li> <li>content : holds
 * the content widgets</li> <li>footer : holds the
 * footer widgets</li>
 */
public class SiteUI extends Composite {
	interface SiteUiBinder extends UiBinder<Widget, SiteUI> {
	}
	
	/**
	 * How many time a message is displayed (in milliseconds)
	 */
	private static final int MESSAGE_LIFE=5000;
	/**
	 * GUI main mode :
	 * 
	 * MAP : map with a column on the left
	 * 
	 * EDIT_CUSTOMER : fullscreen customer edit form
	 * 
	 * EDIT_PC : fullscreen PC edit form
	 * @author jcwilk
	 *
	 */
	public enum Mode {
		MAP,
		EDIT_CUSTOMER,
		EDIT_PC,
		EDIT_CLOSE_PC
	};	
	private static SiteUiBinder uiBinder = GWT.create(SiteUiBinder.class);
	private int infoCount = 0;

	// CHECKSTYLE:OFF
	@UiField
	protected Label infoMessage;

	/**
	 * holds the side bar widgets
	 */
	@UiField
	protected SimplePanel sideBarContainer;
	/**
	 * holds the content widgets
	 */
	@UiField
	protected SimplePanel contentContainer;
	/**
	 * holds the footer widgets
	 */
	@UiField
	protected SimplePanel footerContainer;
	@UiField
	protected EditCustomerWidget editCustomerWidget;
	@UiField
	protected EditPcWidget editPcWidget;

	// CHECKSTYLE:ON

	/**
	 * Constructor
	 */
	public SiteUI() {
		initWidget(uiBinder.createAndBindUi(this));
		info(Application.CONSTANTS.title_welcome());
	}

	/**
	 * Change what is displayed (map, or edit forms)
	 * @param mode
	 * @param intervention
	 * @param pc only if mode is EDIT_PC
	 */
	public void setMode(Mode mode, InterventionBean intervention, NetworkDeviceBean pc, PcDto pcDto) {		
		switch ( mode ) {
		case MAP :
			editCustomerWidget.setVisible(false);
			editPcWidget.setVisible(false);
			sideBarContainer.setVisible(true);
			contentContainer.setVisible(true);
			break;
		case EDIT_CUSTOMER :
			sideBarContainer.setVisible(false);
			contentContainer.setVisible(false);
			editPcWidget.setVisible(false);
			editCustomerWidget.setIntervention(intervention);
			editCustomerWidget.setVisible(true);
			break;
		case EDIT_PC :
			sideBarContainer.setVisible(false);
			contentContainer.setVisible(false);
			editCustomerWidget.setVisible(false);			
			editPcWidget.setIntervention(intervention, pc);
			editPcWidget.setVisible(true);
			break;
		case EDIT_CLOSE_PC :
			sideBarContainer.setVisible(false);
			contentContainer.setVisible(false);
			editCustomerWidget.setVisible(false);			
			editPcWidget.setClosePc(pcDto);
			editPcWidget.setVisible(true);
		}
	}
	
	/**
	 * @return the panel to hold the main
	 */
	public SimplePanel getContentContainer() {
		return contentContainer;
	}

	/**
	 * @return the panel to hold the side bar
	 */
	public SimplePanel getSideBarContainer() {
		return sideBarContainer;
	}

	/**
	 * @return the panel to hold the footer
	 */
	public SimplePanel getFooterContainer() {
		return footerContainer;
	}

	public void hideMessage() {
		infoMessage.setVisible(false);
	}
	
	public boolean isMessageVisible() {
		return infoMessage.isVisible();
	}

	public void showRpcMessage() {
		info(Application.CONSTANTS.header_loading());
	}

	public final void info(String message) {
		if (message != null) {
			infoMessage.setStyleName("info");
			setMessage(message);
		} else {
			infoMessage.setVisible(false);
		}
	}

	public final void warn(String message) {
		if (message != null) {
			infoMessage.setStyleName("warn");
			setMessage(message);
			GWT.log("WARN : "+message);
		} else {
			infoMessage.setVisible(false);
		}
	}

	public final void error(String message) {
		if (message != null) {
			infoMessage.setStyleName("error");
			setMessage(message);
			GWT.log("ERROR : "+message);
		} else {
			infoMessage.setVisible(false);
		}
	}

	private void setMessage(String message) {
		infoMessage.setText(message);
		infoMessage.setVisible(true);
		infoCount++;
		final int myCount = infoCount;
		Timer t = new Timer() {
			@Override
			public void run() {
				if (infoCount == myCount) {
					infoMessage.setVisible(false);
				}
			}
		};
		t.schedule(MESSAGE_LIFE);
	}

}
