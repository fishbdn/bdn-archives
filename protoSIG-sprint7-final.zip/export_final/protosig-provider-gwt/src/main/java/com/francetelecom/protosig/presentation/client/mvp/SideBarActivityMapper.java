package com.francetelecom.protosig.presentation.client.mvp;

import com.francetelecom.protosig.presentation.client.Application;
import com.google.gwt.activity.shared.Activity;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.place.shared.Place;

/**
 * HeaderActivityMapper maps each Place to its corresponding Activity.
 * 
 */
public class SideBarActivityMapper implements ActivityMapper {
	/**
	 * Constructor.
	 */
	public SideBarActivityMapper() {
	}

	@Override
	public Activity getActivity(Place place) {
		return Application.CLIENT_FACTORY.getSideBarPresenter();
	}
}
