package com.francetelecom.protosig.presentation.client.widget.map.model;

/**
 * MapBox
 * 
 * @author JLZB1407
 * 
 */
public class MapBox {

	private Location nw;
	private Location se;

	public MapBox() {
	}

	public MapBox(Location nw, Location se) {
		this();
		this.nw = nw;
		this.se = se;
	}

	public Location getNw() {
		return nw;
	}

	public void setNw(Location nw) {
		this.nw = nw;
	}

	public Location getSe() {
		return se;
	}

	public void setSe(Location se) {
		this.se = se;
	}

	public boolean isEmpty() {
		return nw == null || se == null ? true : false;
	}

	public boolean isIn(Location point) {
		if (isEmpty() || point == null) {
			return false;
		}
		return (point.getX() >= nw.getX() && point.getY() <= nw.getY()
				&& point.getX() <= se.getX() && point.getY() >= se.getY());
	}

	@Override
	public String toString() {
		return "NW:" + nw.toString() + ",SE:" + se.toString();
	}

}
