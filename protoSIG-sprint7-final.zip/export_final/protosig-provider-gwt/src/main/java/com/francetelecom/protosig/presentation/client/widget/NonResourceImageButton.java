package com.francetelecom.protosig.presentation.client.widget;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiConstructor;
import com.google.gwt.user.client.ui.Button;

/**
 * A button with an icon, usable in ui:binder but does not require to put images inside java packages
 * @author jcwilk
 *
 */
public class NonResourceImageButton extends Button {
	@UiConstructor
	public NonResourceImageButton(String image) {
		setHTML("<image src=\""+GWT.getHostPageBaseURL()+image+"\"/>");
	}
}
