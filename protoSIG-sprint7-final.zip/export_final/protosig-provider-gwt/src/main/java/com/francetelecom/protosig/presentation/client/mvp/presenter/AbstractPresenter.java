package com.francetelecom.protosig.presentation.client.mvp.presenter;

import com.francetelecom.protosig.presentation.client.Application;
import com.google.gwt.activity.shared.AbstractActivity;
import com.google.gwt.place.shared.Place;

/**
 * This class is meant to be extended by the application Presenters. It'll be a
 * simple way to have a global entry point to all presenters.
 * 
 * @author jcwilk
 * 
 */
public abstract class AbstractPresenter extends AbstractActivity {
	@SuppressWarnings("javadoc")
	public void goTo(Place newPlace) {
		Application.CLIENT_FACTORY.getPlaceController().goTo(newPlace);
	}
}
