package com.francetelecom.protosig.presentation.client.rpc;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Callback that displays a "loading" message during the RPC call
 * @author jcwilk
 *
 * @param <T> RPC result type
 */
public abstract class GenericCallback<T> implements AsyncCallback<T> {

	public GenericCallback() {
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				GenericEvent.Type.START_RPC);
	}

	@Override
	public void onFailure(Throwable caught) {
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				GenericEvent.Type.STOP_RPC);

	}

	@Override
	public void onSuccess(T result) {
		Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
				GenericEvent.Type.STOP_RPC);
		process(result);
	}

	protected abstract void process(T result);

}
