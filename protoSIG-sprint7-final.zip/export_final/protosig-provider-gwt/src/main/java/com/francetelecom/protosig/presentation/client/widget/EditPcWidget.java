package com.francetelecom.protosig.presentation.client.widget;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.UIModeEvent;
import com.francetelecom.protosig.presentation.client.factory.GenericReflectiveDtoFactory;
import com.francetelecom.protosig.presentation.client.factory.GenericReflectiveDtoFactory.GenericDtoType;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.rpc.GenericMessageCallback;
import com.francetelecom.protosig.presentation.client.ui.SiteUI;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class EditPcWidget extends Composite {

	private static EditCustomerWidgetUiBinder uiBinder = GWT
			.create(EditCustomerWidgetUiBinder.class);

	interface EditCustomerWidgetUiBinder extends UiBinder<Widget, EditPcWidget> {
	}

	// CHECKSTYLE:OFF
	@UiField
	protected TextBox pccatValue;
	@UiField
	protected TextBox specialDeviceValue;
	@UiField
	protected TextBox levelValue;
	@UiField
	protected TextBox stairValue;
	@UiField
	protected TextBox buildingValue;
	@UiField
	protected TextBox groupValue;
	@UiField
	protected TextBox numberValue;
	@UiField
	protected TextBox streetValue;
	@UiField
	protected TextBox cityCodeValue;
	@UiField
	protected TextBox cityNameValue;
	@UiField
	protected TextArea commentValue;
	@UiField
	protected Button cancelButton;
	@UiField
	protected Button saveButton;

	// CHECKSTYLE:ON
	private GenericDto dto;

	/**
	 * Save button handler. Saves pc details to the database and go back to map
	 * view
	 * 
	 * @author jcwilk
	 * 
	 */
	private class SaveClickHandler implements ClickHandler {
		@Override
		public void onClick(ClickEvent event) {
			// save updates to the database
			setUpdates();
			Application.CLIENT_FACTORY.getSigService().savePcUpdate(
					dto,
					new GenericMessageCallback<Void>(Application.CONSTANTS
							.pc_updated(), Application.CONSTANTS
							.pc_updated_error()));
			// go back to map mode
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new UIModeEvent(SiteUI.Mode.MAP, null, null));
		}
	};

	public EditPcWidget() {
		initWidget(uiBinder.createAndBindUi(this));
		// set buttons callbacks
		cancelButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				// go back to map mode
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new UIModeEvent(SiteUI.Mode.MAP, null, null));
			}
		});
		saveButton.addClickHandler(new SaveClickHandler());
	}

	/**
	 * Create a dto containing values from the form
	 * 
	 * @return
	 */
	private void setUpdates() {
		dto.setNewValue(GenericDto.FIELD_BUILDING,buildingValue.getText());
		dto.setNewValue(GenericDto.FIELD_CITY_NAME,cityNameValue.getText());
		dto.setNewValue(GenericDto.FIELD_COMMENT,commentValue.getText());
		dto.setNewValue(GenericDto.FIELD_CITY_CODE,cityCodeValue.getText());
		dto.setNewValue(GenericDto.FIELD_LEVEL,levelValue.getText());
		dto.setNewValue(GenericDto.FIELD_NUMBER,numberValue.getText());
		dto.setNewValue(GenericDto.FIELD_STAIR,stairValue.getText());
		dto.setNewValue(GenericDto.FIELD_STREET,streetValue.getText());
		dto.setNewValue(GenericDto.FIELD_GROUP,groupValue.getText());
	}

	/**
	 * Reset the form for a new pc
	 * 
	 * @param intervention
	 */
	public void setIntervention(InterventionBean intervention,
			NetworkDeviceBean pc) {
		// set fields values
		dto = GenericReflectiveDtoFactory.create(GenericDtoType.PC, intervention, pc);
		initPcFields();
	}
	
	/**
	 * Init form fields from the pc in dto
	 */
	private void initPcFields() {
		// init fields labels
		pccatValue.setText(dto.getOldValue(GenericDto.FIELD_CATEG));
		specialDeviceValue.setText(dto.getOldValue(GenericDto.FIELD_SPECIAL_DEVICE));

		levelValue.setText(dto.getOldValue(GenericDto.FIELD_LEVEL));
		stairValue.setText(dto.getOldValue(GenericDto.FIELD_STAIR));
		buildingValue.setText(dto.getOldValue(GenericDto.FIELD_BUILDING));
		groupValue.setText(dto.getOldValue(GenericDto.FIELD_GROUP));
		numberValue.setText(dto.getOldValue(GenericDto.FIELD_NUMBER));
		streetValue.setText(dto.getOldValue(GenericDto.FIELD_STREET));
		cityCodeValue.setText(dto.getOldValue(GenericDto.FIELD_CITY_CODE));
		cityNameValue.setText(dto.getOldValue(GenericDto.FIELD_CITY_NAME));
		commentValue.setText(dto.getOldValue(GenericDto.FIELD_COMMENT));
		
	}
	
	/**
	 * Reset the form for a close pc
	 * @param pc
	 */
	public void setClosePc(PcDto pc) {
		dto = GenericReflectiveDtoFactory.createFromClosePc(pc);
		initPcFields();
	}

}
