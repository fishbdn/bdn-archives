package com.francetelecom.protosig.presentation.client.widget;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.InterventionGeocodingEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.SelectInterventionEvent;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.utils.DateUtils;
import com.francetelecom.protosig.presentation.client.utils.InterventionFilter;
import com.francetelecom.protosig.presentation.client.utils.StringUtils;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.FocusPanel;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class AgendaWidget extends Composite {

	private static AgendaWidgetUiBinder uiBinder = GWT
			.create(AgendaWidgetUiBinder.class);
	
	interface AgendaWidgetUiBinder extends UiBinder<Widget, AgendaWidget> {
	}

	private enum InterventionRowType {
		// top rounded corner
		START,
		// no rounded corners
		MIDDLE,
		// bottom rounded corner
		END,
		// both corners rounded
		SINGLE
	};
	
	private static final int LEGEND_AUTOCLOSE_DELAY=3000;
	private static final int DEFAULT_START_HOUR=8;
	private static final int DEFAULT_END_HOUR=18;
	private static final int MAX_HOUR=23;

	// CHECKSTYLE:OFF
	@UiField
	protected FlowPanel agendaHeader;
	@UiField
	protected Button localizeButton;	
	@UiField
	protected Label dateLabel;
	@UiField
	protected Button refreshButton;
	@UiField
	protected FlowPanel legendPanel;
	@UiField
	protected Image legend;
	@UiField
	protected Button legendButton;
	@UiField
	protected Grid hourColumn;
	@UiField
	protected Grid interColumn;
	// CHECKSTYLE:ON
	private boolean initialized=false;

	/**
	 * Focus is on this intervention
	 */
	private static final String STYLE_INTER_SELECTED = "selected";
	/**
	 * customer geocoding confidence is low on this intervention
	 */
	private static final String STYLE_INTER_CONFIDENCE = "confidence";
	/**
	 * customer geocoding failed on this intervention
	 */
	private static final String STYLE_INTER_ERROR = "ko";
	/**
	 * this type of intervention is not supported
	 */
	private static final String STYLE_INTER_DISABLED = "disabled";
	/**
	 * customer geocoding is in progress
	 */
	private static final String STYLE_INTER_LOADING = "loading";
	/**
	 * specific style for client name
	 */
	private static final String STYLE_SMALL = "small";
	/**
	 * keep track of widgets associated with each intervention (key is intervention index)
	 */
	private final Map<Integer, Widget> interWidgets = new HashMap<Integer, Widget>();

	/**
	 * First hour displayed on the agenda
	 */
	private int startHour;
	/**
	 * Last hour displayed on the agenda
	 */
	private int endHour;
	private boolean legendIsOpen=true;

	public AgendaWidget() {
		initWidget(uiBinder.createAndBindUi(this));
		// center screen
		refreshButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						GenericEvent.Type.REFRESH_MAP);
				unselectAll();
			}
		});
		// show/hide legend
		legend.setUrl(GWT.getHostPageBaseURL()+"images/legend.png");
		legendButton.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				if (legendIsOpen) {
					closeLegend();
				} else {
					openLegend();
				}				
			}
		});
		// display user position
		localizeButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						GenericEvent.Type.DISPLAY_USER_POS);
			}
		});		
		// automatically display, then hide the legend on first display
		openLegend();
		Timer t=new Timer() {
			
			@Override
			public void run() {
				closeLegend();
			}
		};
		t.schedule( LEGEND_AUTOCLOSE_DELAY );
	}
	
	private void openLegend() {
		// legend animation uses CSS3 transition on top css property
		legendPanel.addStyleName("open");
		legendIsOpen=true;
	}
	
	private void closeLegend() {
		legendPanel.removeStyleName("open");
		legendIsOpen=false;
	}

	/**
	 * Whether the agenda has already been created from the intervention list 
	 * @return
	 */
	public boolean isInitialized() {
		return initialized;
	}

	/**
	 * Create the agenda from the intervention list
	 * @param interventions
	 */
	public void init(List<InterventionBean> interventions) {
		// set header
		dateLabel.setText(DateUtils.getCurrentDateLong());
		detectTimeRange(interventions);
		buildHourColumn();
		buildInterventionColumn(interventions);
		initialized=true;
	}

	/**
	 * Detect first and last hour to display depending on the list of
	 * interventions
	 * 
	 * @param agenda
	 */
	private void detectTimeRange(List<InterventionBean> interList) {
		// detect time range for this agenda
		if (interList.isEmpty()) {
			startHour = DEFAULT_START_HOUR;
			endHour = DEFAULT_END_HOUR;
		} else {
			startHour = MAX_HOUR;
			endHour = 0;
			for (InterventionBean inter : interList) {
				// keep only intervention for current day
				if (DateUtils.isToday(inter.getTimeStart())) {
					int interStart = DateUtils.getHour(inter.getTimeStart());
					int interStop = DateUtils.getHour(inter.getTimeStop()) + 1;

					if (interStart < startHour) {
						startHour = interStart;
					}
					if (interStop > endHour) {
						endHour = interStop;
					}
				}
			}
		}
	}

	/**
	 * Create the agenda first column
	 */
	private void buildHourColumn() {
		// build the hour column
		hourColumn.resize(endHour - startHour + 1, 1);
		int rowId = 0;
		for (long hour = startHour; hour <= endHour; hour++) {
			hourColumn.setHTML(rowId, 0, hour + "h");
			rowId++;
		}
	}

	/**
	 * Unselect all interventions
	 */
	private void unselectAll() {
		for (int row = 0; row < interColumn.getRowCount(); row++) {
			interColumn.getCellFormatter().removeStyleName(row, 0,
					STYLE_INTER_SELECTED);
		}
	}

	/**
	 * Create the agenda second column
	 */
	private void buildInterventionColumn(List<InterventionBean> interList) {
		// build the intervention column (empty)
		int nbHalfHour = (endHour - startHour + 1) * 2;
		interColumn.resize(nbHalfHour, 1);
		// place interventions
		for (InterventionBean inter : interList) {
			// keep only intervention for current day
			if (DateUtils.isToday(inter.getTimeStart())) {
				int halfHourStart = DateUtils.getHalfHour(inter.getTimeStart());
				int halfHourEnd = DateUtils.getHalfHour(inter.getTimeStop());
				int startRow = halfHourStart - startHour * 2;
				int endRow = halfHourEnd - startHour * 2 - 1;
				int textRow = (startRow + endRow) / 2;
				if (endRow > startRow) {
					// multi-row intervention
					createInterventionWidget(startRow, startRow, endRow, inter,
							InterventionRowType.START, textRow);
					for (int row = startRow + 1; row < endRow; row++) {
						createInterventionWidget(row, startRow, endRow, inter,
								InterventionRowType.MIDDLE, textRow );
					}
					createInterventionWidget(endRow, startRow, endRow, inter,
							InterventionRowType.END, textRow );
				} else {
					// single-row intervention
					createInterventionWidget(startRow, startRow, endRow, inter,
							InterventionRowType.SINGLE, startRow);
				}
			}
		}
	}

	/**
	 * Triggered when an intervention is clicked in the agenda
	 */
	private class InterClickHandler implements ClickHandler {
		private final InterventionBean inter;
		private final int startRow,endRow;

		public InterClickHandler(InterventionBean inter, int startRow,int endRow) {
			this.inter = inter;
			this.startRow=startRow;
			this.endRow=endRow;
		}

		@Override
		public void onClick(ClickEvent event) {
			if (inter.isShowDetail()) {
				// unselect current intervention
				inter.setShowDetail(false);
				for (int row = startRow; row <= endRow; row++) {
					interColumn.getCellFormatter().removeStyleName(row, 0,
							STYLE_INTER_SELECTED);
				}
				// send event to the map presenter
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new SelectInterventionEvent(inter.getIndex(), false));
			} else {
				// select intervention
				inter.setShowDetail(true);
				for (int row = 0; row < interColumn.getRowCount(); row++) {
					if ( row >= startRow && row <= endRow ) {
						// select current intervention
						interColumn.getCellFormatter().addStyleName(row, 0,
							STYLE_INTER_SELECTED);
					} else {
						// unselect all other interventions
						interColumn.getCellFormatter().removeStyleName(row, 0,
								STYLE_INTER_SELECTED);						
					}
				}
				// send event to the map presenter
				Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
						new SelectInterventionEvent(inter.getIndex(), true));
			}			
		}
	};

	/**
	 * Create a widget for the intervention in the agenda
	 * 
	 * @param row current row for this intervention (each row = 30 minutes)
	 * @param startRow first row for this intervention
	 * @param endRow last row for this intervention
	 * @param inter the intervention
	 * @param type row type
	 * @param textRow row where the text is displayed
	 */
	private void createInterventionWidget(int row, int startRow, int endRow, InterventionBean inter,
			InterventionRowType type, int textRow) {
		// create the widget with the proper css style and background image
		boolean isInterventionActive = InterventionFilter
				.isInterventionOk(inter.getLocalStorageInter());
		FlowPanel interWidget = new FlowPanel();
		interWidget.addStyleName("agendaInter");
		interColumn.getCellFormatter().setStyleName(row, 0,
				type.name().toLowerCase());
		Image img = new Image("images/agenda_box_"
				+ inter.getInterventionState() + "_" + type.name() + ".png");
		interWidget.add(img);
		if (row == textRow) {
			// add intervention text
			HTML widget = new HTML(inter.getIndex()
					+ "&nbsp;&nbsp;&nbsp;&nbsp;"
					+ StringUtils.emptyIfNull(inter.getEtechReference()) + " "
					+ StringUtils.emptyIfNull(inter.getActivity())
					+ StringUtils.emptyIfNull(inter.getProduct()));
			interWidget.add(widget);
			interWidgets.put(inter.getIndex(), widget);
			if (! isInterventionActive) {
				widget.addStyleName(STYLE_INTER_DISABLED);
			} else {
				widget.addStyleName(STYLE_INTER_LOADING);
			}
		} else if (row == textRow+1 ) {
			// add customer name
			HTML widget= new HTML(StringUtils.emptyIfNull(inter.getLocalStorageInter().getClientName()));
			widget.addStyleName(STYLE_SMALL);
			interWidget.add(widget);
		} else {
			interWidget.add(new HTML("&nbsp;"));
		}
		if (isInterventionActive) {
			// make it clickable
			FocusPanel focus = new FocusPanel();
			focus.add(interWidget);
			interColumn.setWidget(row, 0, focus);
			focus.addClickHandler(new InterClickHandler(inter,startRow,endRow));
		} else {
			interColumn.setWidget(row, 0, interWidget);
		}

	}

	/**
	 * Display low confidence indicator for an intervention
	 * 
	 * @param data
	 */
	public void setInterventionConfidence(Integer data,
			InterventionGeocodingEvent.Level level) {
		Widget widget = interWidgets.get(data);
		if (widget != null) {
			widget.removeStyleName(STYLE_INTER_LOADING);
			widget.removeStyleName(STYLE_INTER_ERROR);
			widget.removeStyleName(STYLE_INTER_CONFIDENCE);
			switch (level) {
			case NO_ANSWER:
				widget.addStyleName(STYLE_INTER_ERROR);
				break;
			case LOW_CONFIDENCE:
				widget.addStyleName(STYLE_INTER_CONFIDENCE);
				break;
			default:break;
			}
		}
	}
}
