package com.francetelecom.protosig.presentation.client.widget.map.model;

/**
 * Resource
 * 
 * @author JLZB1407
 * 
 */
public class Resource {

	private Location location;
	private MapBox mapBox;

	public Resource(Location location, MapBox mapBox) {
		super();
		this.location = location;
		this.mapBox = mapBox;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public MapBox getMapBox() {
		return mapBox;
	}

	public void setMapBox(MapBox mapBox) {
		this.mapBox = mapBox;
	}

	@Override
	public String toString() {
		return "center:" + location + ";mapbox:" + mapBox.toString();
	}

}
