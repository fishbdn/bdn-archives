package com.francetelecom.protosig.presentation.server;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.francetelecom.protosig.business.CustomerBusiness;
import com.francetelecom.protosig.business.PcBusiness;
import com.francetelecom.protosig.business.RefDataBusiness;
import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.GeocodeResponseDto;
import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.rpc.SigService;
import com.francetelecom.protosig.ws.OrasService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * @author jcwilk
 * 
 */
@SuppressWarnings("serial")
@RemoteServiceRelativePath("sigService")
public class SigServiceImpl extends SecurityCheckServlet implements SigService {
	@Autowired
	private RefDataBusiness refDataBusiness;
	@Autowired
	private PcBusiness pcBusiness;
	@Autowired
	private CustomerBusiness customerBusiness;
	@Autowired
	private OrasService orasService;

	/**
	 * Constructor
	 */
	public SigServiceImpl() {
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.rpc.SigService#getPostalCodeFromInseeCode(java.lang.String)
	 */
	@Override
	public String getPostalCodeFromInseeCode(String inseeCode) {
		return refDataBusiness.getPostalCodeFromInseeCode(inseeCode);
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.rpc.SigService#geocode(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public GeocodeResponseDto geocode(String streetNumber, String streetName, String inseeCode, String cityName) {
		// convert insee code to postal code
		String postalCode=null;
		if ( inseeCode != null && ! "".equals(inseeCode) ) {
			postalCode=refDataBusiness.getPostalCodeFromInseeCode(inseeCode);
		}
		// call Oras web service for actual geocoding
		return orasService.geocode(streetNumber,streetName,postalCode,cityName);
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.rpc.SigService#getClosestPC(java.lang.String,
	 *      java.lang.Double, java.lang.Double)
	 */
	@Override
	public List<PcDto> getClosestPC(String dr, Double x, Double y) {
		return pcBusiness.getClosest(dr, x, y);
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.rpc.SigService#savePcUpdate(com.francetelecom.protosig.model.PcUpdateDto)
	 */
	@Override
	public void savePcUpdate(GenericDto update) {
		update.setCodeIdent(this.getUserFromSession().getCodeIdent());
		pcBusiness.saveUpdate(update);
	}

	@Override
	public void savePcLocation(String id, Double oldx, Double oldy, Double x, Double y) {
		pcBusiness.savePcLocation(id, this.getUserFromSession().getCodeIdent(),
				oldx,oldy,x,y);
	}

	/**
	 * @see com.francetelecom.protosig.presentation.client.rpc.SigService#saveCustomerUpdate(com.francetelecom.protosig.model.CustomerUpdateDto)
	 */
	@Override
	public void saveCustomerUpdate(GenericDto update) {
		update.setCodeIdent(this.getUserFromSession().getCodeIdent());
		customerBusiness.saveUpdate(update);
	}

}
