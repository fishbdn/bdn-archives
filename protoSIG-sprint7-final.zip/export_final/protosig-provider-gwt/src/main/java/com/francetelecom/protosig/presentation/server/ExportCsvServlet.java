package com.francetelecom.protosig.presentation.server;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.francetelecom.protosig.business.CustomerBusiness;
import com.francetelecom.protosig.business.PcBusiness;
import com.francetelecom.protosig.model.GenericDto;

public class ExportCsvServlet extends SpringBeanInjectionServlet {

	private static final long serialVersionUID = 6611106011185165536L;

	@Autowired
	private PcBusiness pcBusiness;

	@Autowired
	private CustomerBusiness customerBusiness;

	private static final String TYPE_PC = "pc";
	private static final String TYPE_CUSTOMER = "customer";
	private static final String PARAM_CLEAR = "clear";
	private static final String PARAM_TYPE = "type";
	private static final String CSV_SEPARATOR = ";";

	private static final String DATE_FORMAT = "dd/MM/yyyy";
	private static final String HOUR_FORMAT = "hh:mm:ss";

	private static final String CODE_BASICAT = "TIC";

	DateFormat sdfDate = new SimpleDateFormat(DATE_FORMAT);
	DateFormat sdfHour = new SimpleDateFormat(HOUR_FORMAT);

	/**
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 * 
	 *      Servlet parameters :
	 * 
	 *      type : pc | customer
	 * 
	 *      clear : if true, erase table data after export
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		ServletOutputStream op = resp.getOutputStream();
		String clear = req.getParameter(PARAM_CLEAR);
		String type = req.getParameter(PARAM_TYPE);
		boolean mustClear = (clear != null && Boolean.parseBoolean(clear));
		PrintWriter out = new PrintWriter(op);
		try {
			if (TYPE_PC.equals(type)) {
				setHeaders(resp);
				writePcUpdates(out);
			} else if (TYPE_CUSTOMER.equals(type)) {
				setHeaders(resp);
				writeCustomerUpdates(out);
			} else {
				out.print("Type " + type
						+ " inconnu. Valeurs possibles : pc|customer");
			}
		} finally {
			out.flush();
			out.close();
		}
		if (mustClear) {
			// delete all data from the table
			if (TYPE_PC.equals(type)) {
				pcBusiness.clearUpdates();
			} else if (TYPE_CUSTOMER.equals(type)) {
				customerBusiness.clearUpdates();
			}
		}
	}

	/**
	 * Dump a CSV of all PC updates in the database
	 * 
	 * @param out
	 */
	private void writePcUpdates(PrintWriter out) {
		List<GenericDto> pcs = pcBusiness.getUpdates();
		for (GenericDto pc : pcs) {
			writePc(out, pc);
		}
	}

	/**
	 * DUmp a CSV of all customer updates in the database
	 * 
	 * @param out
	 */
	private void writeCustomerUpdates(PrintWriter out) {
		List<GenericDto> customers = customerBusiness.getUpdates();
		for (GenericDto customer : customers) {
			writeCustomer(out, customer);
		}
	}

	/**
	 * replace null strings with ""
	 * 
	 * @param value
	 * @return
	 */
	private String safeString(String value) {
		return (value == null ? "" : value);
	}

	/**
	 * generate CSV columns for old and new values of a field
	 * 
	 * @param dto
	 *            the generic dto
	 * @param fieldCode
	 *            the field code
	 * @return the CSV columns, starting with ;
	 */
	private String getFields(GenericDto dto, String fieldCode) {
		String result = CSV_SEPARATOR;
		result += safeString(dto.getOldValue(fieldCode));
		result += CSV_SEPARATOR;
		result += safeString(dto.getNewValue(fieldCode));
		return result;
	}

	/**
	 * Write all CSV columns for a PC
	 * 
	 * @param out
	 *            output writer
	 * @param pc
	 */
	private void writePc(PrintWriter out, GenericDto pc) {
		String line = CODE_BASICAT;
		line += CSV_SEPARATOR;
		line += safeString(pc.getCodeIdent());
		line += CSV_SEPARATOR;
		// split <dr>|<pccode> primary key into 2 CSV columns
		line += safeString(pc.getId().replaceFirst("\\|", CSV_SEPARATOR));
		line += getFields(pc, GenericDto.FIELD_NUMBER);
		line += getFields(pc, GenericDto.FIELD_GROUP);
		line += getFields(pc, GenericDto.FIELD_BUILDING);
		line += getFields(pc, GenericDto.FIELD_STAIR);
		line += getFields(pc, GenericDto.FIELD_LEVEL);
		line += getFields(pc, GenericDto.FIELD_COMMENT);
		line += getFields(pc, GenericDto.FIELD_X);
		line += getFields(pc, GenericDto.FIELD_Y);
		line += getDate(pc.getUpdateDate());
		out.println(line);
	}

	/**
	 * Write all CSV columns for a customer
	 * 
	 * @param out
	 *            the output writer
	 * @param pc
	 */
	private void writeCustomer(PrintWriter out, GenericDto pc) {
		String line = CODE_BASICAT;
		line += CSV_SEPARATOR;
		// split <dr>|<ND> primary key into 2 CSV columns
		String[] ids=pc.getId().split("\\|");
		// dr
		if ( ids.length == 2 ) {
			line += safeString(ids[0]);
		}
		line += CSV_SEPARATOR;
		line += safeString(pc.getCodeIdent());
		line += CSV_SEPARATOR;
		line += safeString(pc.getLabel());
		line += CSV_SEPARATOR;
		// ND
		if ( ids.length == 2 ) {
			line += safeString(ids[1]);
		} else {
			// old line without dr
			line += safeString(pc.getId());			
		}
		line += getFields(pc, GenericDto.FIELD_DOOR);
		line += getFields(pc, GenericDto.FIELD_LEVEL);
		line += getFields(pc, GenericDto.FIELD_STAIR);
		line += getFields(pc, GenericDto.FIELD_GROUP);
		line += getFields(pc, GenericDto.FIELD_BUILDING);
		line += getFields(pc, GenericDto.FIELD_NUMBER);
		line += getFields(pc, GenericDto.FIELD_NUMBER_COMPLEMENT);
		line += getFields(pc, GenericDto.FIELD_STREET);
		line += getFields(pc, GenericDto.FIELD_COMMENT);
		line += getFields(pc, GenericDto.FIELD_CITY_CODE);
		line += getFields(pc, GenericDto.FIELD_CITY_NAME);
		line += getDate(pc.getUpdateDate());
		out.println(line);
	}

	/**
	 * Write the date columns (date + hour)
	 * 
	 * @param date
	 * @return the CSV columns, starting with ;
	 */
	private String getDate(Date date) {
		String result = CSV_SEPARATOR;
		result += date == null ? "" : sdfDate.format(date);
		result += CSV_SEPARATOR;
		result += date == null ? "" : sdfHour.format(date);
		return result;
	}

	/**
	 * Set HTTP header for a CSV file
	 * 
	 * @param resp
	 */
	private void setHeaders(HttpServletResponse resp) {
		resp.setContentType("text/csv");
		resp.setHeader("Content-Disposition",
				"attachment; filename=\"export.csv\"");
		resp.setCharacterEncoding("UTF-8");
	}

}
