package com.francetelecom.protosig.presentation.client.rpc;

import java.util.List;

import com.francetelecom.protosig.model.GenericDto;
import com.francetelecom.protosig.model.GeocodeResponseDto;
import com.francetelecom.protosig.model.PcDto;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("sigService")
public interface SigService extends RemoteService {
	/**
	 * Convert an insee code into a postal code
	 * @param inseeCode
	 * @return the postal code
	 */
	String getPostalCodeFromInseeCode(String inseeCode);

	/**
	 * Find position from address
	 * @param adress number + street name
	 * @param inseeCode city insee code
	 * @param cityName
	 * @return
	 */
	GeocodeResponseDto geocode(String streetNumber, String streetName, String inseeCode, String cityName);
	
	/**
	 * Returns the 15 closest PC for a DR
	 * @param dr
	 * @param x
	 * @param y
	 * @return
	 */
	List<PcDto> getClosestPC(String dr, Double x, Double y);
	
	/**
	 * Save pc update to the database 
	 * @param update
	 * @return
	 */
	void savePcUpdate(GenericDto update);

	/**
	 * Save new pc location to the database
	 * @parma id pc id (dr+name) 
	 * @param oldx,oldy old location
	 * @param x,y new location
	 * @return
	 */
	void savePcLocation(String id, Double oldx, Double oldy, Double x, Double y);

	/**
	 * Save customer update to the database 
	 * @param update
	 * @return
	 */
	void saveCustomerUpdate(GenericDto update);

}
