package com.francetelecom.protosig.presentation.client.mvp.view;

import java.util.List;

import com.francetelecom.protosig.model.PcDto;
import com.francetelecom.protosig.presentation.client.eventbus.event.InterventionGeocodingEvent;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;


/**
 * Contains all of the UI components that make up the side bar. Views are
 * responsible for the layout of the UI components.
 */
public interface SideBarView extends AbstractView {
	/**
	 * Fill the agenda with interventions
	 * @param interventions
	 */
	void setAgenda(List<InterventionBean> interventions);
	
	/**
	 * Display detail for an intervention
	 * @param inter the intervention
	 * @param deviceIndex number of the device in the railroad or -1 for the customer
	 */
	void setInterventionDetail(InterventionBean inter, int deviceIndex);
	
	/**
	 * Display low confidence indicator for an intervention
	 * @param data intervention index
	 * @param level confidence level
	 */
	void setInterventionConfidence(Integer data, InterventionGeocodingEvent.Level level);

	/**
	 * Display detail about a pc close to the customer
	 * @param index pc index in the close pc list
	 * @param pc the pc data
	 */
	void setClosePcDetail(Long index, PcDto pc);
}
