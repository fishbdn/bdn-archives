package com.francetelecom.protosig.presentation.client.mvp.presenter;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.mvp.view.FooterView;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;

/**
 * Drives {@link FooterView}. An activity in GWT 2.1 is analogous to a presenter
 * in MVP terminology. It contains all of the logic, including view transition
 * and data sync via RPCs back to the server. It contains no Widgets or UI code.
 * As a general rule, for every view you'll want a presenter to drive the view
 * and handle events that are sourced from the UI widgets within the view.
 * Activities are started and stopped by an ActivityManager associated with a
 * container Widget.
 */
public class FooterPresenter extends AbstractPresenter {

	/**
	 * Constructor.
	 */
	public FooterPresenter() {
	}

	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		// display view in UI
		panel.setWidget(Application.CLIENT_FACTORY.getFooterView());
	}

}
