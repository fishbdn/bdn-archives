package com.francetelecom.protosig.presentation.client.mvp;

import com.francetelecom.protosig.presentation.client.Application;
import com.google.gwt.activity.shared.Activity;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.place.shared.Place;

/**
 * FooterActivityMapper maps each Place to its corresponding Activity.
 * 
 */
public class FooterActivityMapper implements ActivityMapper {

	/**
	 * Constructor.
	 */
	public FooterActivityMapper() {
	}

	@Override
	public Activity getActivity(Place place) {
		return Application.CLIENT_FACTORY.getFooterPresenter();
	}
}
