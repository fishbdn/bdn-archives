package com.francetelecom.protosig.presentation.client.eventbus.event;

import java.util.List;

import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;

/**
 * Display the daily round : agenda on the sidebar, customers on the map
 * @author jcwilk
 *
 */
public class MapAgendaEvent extends GenericEvent<List<InterventionBean>> {
	
	/**
	 * If interventions is null, use the previous intervention list
	 * @param interventions
	 */
	public MapAgendaEvent(List<InterventionBean> interventions) {
		super(GenericEvent.Type.MAP_AGENDA,interventions);
	}
}
