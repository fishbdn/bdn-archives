package com.francetelecom.protosig.presentation.client.utils.geolocation;

import com.google.gwt.core.client.Callback;
import com.google.gwt.geolocation.client.Geolocation;
import com.google.gwt.geolocation.client.Geolocation.PositionOptions;
import com.google.gwt.geolocation.client.Position;
import com.google.gwt.geolocation.client.PositionError;

/**
 * Wrapper to GWT Geolocation API
 * @author jcwilk
 *
 */
public final class GeolocationHelper {
	/**
	 * hidden constructor
	 */
	private GeolocationHelper() {}
	
	public interface GeolocationCallback {
		/**
		 * Position of the user has been found
		 * @param x
		 * @param y
		 */
		void onSuccess(Double x, Double y);
		/**
		 * User has cancel (refused) the geolocation request
		 */
		void onCancel();
		/**
		 * timeout/no gps/...
		 */
		void onError();
	}
	
	/**
	 * Try to get the user position using HTML5 geolocation API
	 * @param cbk
	 */
	public static void getPosition(final GeolocationCallback cbk) {
		Geolocation geo = Geolocation.getIfSupported();
		if (geo == null) {
			cbk.onError();
		}
		PositionOptions options = new PositionOptions();
		options.setHighAccuracyEnabled(true);
		geo.getCurrentPosition(new Callback<Position, PositionError>() {
			@Override
			public void onFailure(PositionError reason) {
				if ( reason.getCode() == PositionError.PERMISSION_DENIED ) {
					// user declined access to their position
					cbk.onCancel();
				} else {
					// unable to find user's position
					cbk.onError();					
				}
			}

			@Override
			public void onSuccess(Position result) {
				// found user position
				double x = result.getCoordinates().getLongitude();
				double y = result.getCoordinates().getLatitude();
				cbk.onSuccess(x, y);
			}
		}, options);
	}
}
