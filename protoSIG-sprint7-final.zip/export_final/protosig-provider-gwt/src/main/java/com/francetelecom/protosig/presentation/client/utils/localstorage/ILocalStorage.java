package com.francetelecom.protosig.presentation.client.utils.localstorage;

import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.NetworkDeviceBean;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IAgenda;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.INodeClientData;

public interface ILocalStorage {
	String CUSTOMER_ADRESS_XPATH="bintervention/adresseclient";
	String RAILROAD_TYPES_XPATH="breakpoint_names";
	String RAILROAD_XPATH="r_bran";
	String LIST_BLIGNE_XPATH="detailintervention/botcomplet/listbligne/0";
	String POSTAL_CODE_XPATH="detailintervention/botcomplet/bclient/adrcli/cdpt";
	String INSEE_CODE_XPATH="detailintervention/botcomplet/bclient/adrcli/ccom";
	String PC_X_XPATH="listrpc/?/coxpc";
	String PC_Y_XPATH="listrpc/?/coypc";
	String SR_X_XPATH="listrsr/?/coxsr";
	String SR_Y_XPATH="listrsr/?/coysr";
	String REHD_X_XPATH="listrrehdmed/?/cox";
	String REHD_Y_XPATH="listrrehdmed/?/coy";
	String RE_X_XPATH="listrre/?/coxre";
	String RE_Y_XPATH="listrre/?/coyre";
	
	/**
	 * Decode agenda from json in local storage
	 * @return
	 * @throws ClientFunctionalException 
	 */
	IAgenda getAgenda() throws ClientFunctionalException;
	
	/**
	 * Decode intervention detail from json in local storage
	 * @param idIntervention
	 * @param codeBase
	 * @return
	 * @throws ClientFunctionalException
	 */
	INodeClientData getDetailIntervention(String idIntervention, String codeBase) throws ClientFunctionalException;
	
	/**
	 * Store new customer position in local storage
	 * @param inter
	 */
	void saveCustomerPos(InterventionBean inter);
	
	/**
	 * Store new PC position in local storage
	 * @param inter
	 */
	void savePcPos(InterventionBean inter, NetworkDeviceBean pc);
	
	/**
	 * Update the intervention with data from local storage
	 * @param inter
	 */
	void updateIntervention(InterventionBean inter);

	/**
	 * Update the PC with data from local storage
	 * @param inter
	 * @param device
	 */
	void updatePC(InterventionBean inter, NetworkDeviceBean device);
}
