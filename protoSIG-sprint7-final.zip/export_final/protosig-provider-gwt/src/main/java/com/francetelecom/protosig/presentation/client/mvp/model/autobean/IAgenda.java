package com.francetelecom.protosig.presentation.client.mvp.model.autobean;

import java.util.List;


public interface IAgenda {
	/**
	 * @return the technicianInterventionList
	 * @throws Exception
	 */
	List<IIntervention> getTechnicianInterventionList();

	/**
	 * @param technicianInterventionList
	 *            the technicianInterventionList to set
	 */
	void setTechnicianInterventionList(List<IIntervention> technicianInterventionList);

}
