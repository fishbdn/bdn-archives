package com.francetelecom.protosig.presentation.client.mvp.presenter;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.mvp.view.ErrorView;
import com.francetelecom.protosig.presentation.client.mvp.view.impl.ErrorViewImpl;
import com.francetelecom.protosig.presentation.client.ui.SiteUI.Mode;
import com.google.gwt.activity.shared.AbstractActivity;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;

/**
 * Drives {@link ErrorViewImpl}.
 * 
 * @author jcwilk
 */
public class ErrorPresenter extends AbstractActivity {

	// managed view
	private final ErrorView view;

	private final Throwable cause;

	public ErrorPresenter(ErrorView view, Throwable cause) {
		super();
		this.view = view;
		this.cause = cause;
	}

	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		Application.CLIENT_FACTORY.getSiteUI().setMode(Mode.MAP, null, null,
				null);
		panel.setWidget(view);
		view.setError(cause);
	}
}
