package com.francetelecom.protosig.presentation.client.mvp.place;

import com.google.gwt.place.shared.PlaceTokenizer;

public class MapPlace extends AbstractPlace {
	public static class Tokenizer implements PlaceTokenizer<MapPlace> {

		@Override
		public MapPlace getPlace(String token) {
			return new MapPlace();
		}

		@Override
		public String getToken(MapPlace place) {
			return "";
		}

	};
}
