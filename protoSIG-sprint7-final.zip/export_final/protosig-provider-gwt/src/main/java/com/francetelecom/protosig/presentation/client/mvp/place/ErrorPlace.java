package com.francetelecom.protosig.presentation.client.mvp.place;

import com.google.gwt.place.shared.PlaceTokenizer;

public class ErrorPlace extends AbstractPlace {

	private final Throwable cause;

	public ErrorPlace(Throwable e) {
		this.cause = e;
	}

	public static class Tokenizer implements PlaceTokenizer<ErrorPlace> {

		@Override
		public ErrorPlace getPlace(String token) {
			return new ErrorPlace(null);
		}

		@Override
		public String getToken(ErrorPlace place) {
			return "";
		}

	}

	public Throwable getCause() {
		return cause;
	}
}
