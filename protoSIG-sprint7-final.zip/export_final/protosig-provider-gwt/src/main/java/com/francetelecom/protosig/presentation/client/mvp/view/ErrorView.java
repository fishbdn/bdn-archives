package com.francetelecom.protosig.presentation.client.mvp.view;


/**
 * Error View. Allow to display technical error.
 * 
 * @author jcwilk
 */
public interface ErrorView extends AbstractView {

	void setError(Throwable caught);

}
