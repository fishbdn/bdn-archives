package com.francetelecom.protosig.presentation.client.widget.map;

import java.io.Serializable;
import java.util.Comparator;

import com.francetelecom.protosig.presentation.client.widget.map.model.PositionBean;

/**
 * Localizable comparator.
 * 
 * for BP, order by coef and IssueType ordinal value
 * 
 * for PB, order by IssueType ordinal value
 * 
 * @author JLZB1407
 * 
 */
public class LocalizableComparator<T extends PositionBean> implements
		Comparator<T>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6434418192863578484L;

	@Override
	public int compare(T o1, T o2) {
		return 0;
	}
}
