package com.francetelecom.protosig.presentation.client.mvp.presenter;

import java.util.ArrayList;
import java.util.List;

import com.francetelecom.protosig.presentation.client.Application;
import com.francetelecom.protosig.presentation.client.eventbus.EventListener;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailClosePCEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.DetailInterventionEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.ErrorEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.GenericEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.InterventionGeocodingEvent;
import com.francetelecom.protosig.presentation.client.eventbus.event.MapAgendaEvent;
import com.francetelecom.protosig.presentation.client.exception.ClientFunctionalException;
import com.francetelecom.protosig.presentation.client.mvp.model.InterventionBean;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IAgenda;
import com.francetelecom.protosig.presentation.client.mvp.model.autobean.IIntervention;
import com.francetelecom.protosig.presentation.client.mvp.view.SideBarView;
import com.francetelecom.protosig.presentation.client.utils.DateUtils;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;

/**
 * Drives {@link SideBarView}. An activity in GWT 2.1 is analogous to a
 * presenter in MVP terminology. It contains all of the logic, including view
 * transition and data sync via RPCs back to the server. It contains no Widgets
 * or UI code. As a general rule, for every view you'll want a presenter to
 * drive the view and handle events that are sourced from the UI widgets within
 * the view. Activities are started and stopped by an ActivityManager associated
 * with a container Widget.
 */
public class SideBarPresenter extends AbstractPresenter implements
		EventListener {

	// managed view
	private SideBarView view = null;
	
	private List<InterventionBean> interventions;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		view = Application.CLIENT_FACTORY.getHeaderView();
		panel.setWidget(view);
		Application.CLIENT_FACTORY.getJsonEventBus().registerListener(this);
		try {
			// get agenda data from local storage
			IAgenda agenda = Application.CLIENT_FACTORY.getLocalStorage()
					.getAgenda();
			// build list of interventionbeans
			interventions = buildInterventionList(agenda);
			// display agenda
			view.setAgenda(interventions);
			// send event to the map presenter
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new MapAgendaEvent(interventions));
		} catch (ClientFunctionalException e) {
			Application.CLIENT_FACTORY.getJsonEventBus().publishEvent(
					new ErrorEvent(Application.CONSTANTS.getString(e
							.getMessage())));
		}
	}

	/**
	 * @param agenda
	 * @return
	 */
	List<InterventionBean> buildInterventionList(IAgenda agenda) {
		List<InterventionBean> interventionList = new ArrayList<InterventionBean>(
				agenda.getTechnicianInterventionList().size());
		int id = 1;
		for (IIntervention inter : agenda.getTechnicianInterventionList()) {
			if (DateUtils.isToday(inter.getTimeStart())) {
				interventionList.add(Application.CLIENT_FACTORY
						.getInterventionBeanFactory().create(
								id, inter));
				id++;
			}
		}
		return interventionList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void handleEvent(GenericEvent<?> event) {
		switch (event.getType()) {
		case INTER_DETAIL :
			// display network elements for an intervention
			DetailInterventionEvent detailEvent=(DetailInterventionEvent)event;
			if ( detailEvent.getData() != -1L ) {
				view.setInterventionDetail(interventions.get(detailEvent.getData().intValue()-1),
					detailEvent.getDeviceIndex().intValue());
			}
			break;
		case CLOSE_PC_DETAIL :
			// display detail about a close pc
			DetailClosePCEvent detailClosePcEvent=(DetailClosePCEvent)event;
			view.setClosePcDetail(detailClosePcEvent.getData(), detailClosePcEvent.getPc());
			break;
		case INTER_GEO :
			// change intervention geocoding confidence indicator
			InterventionGeocodingEvent confidenceEvent=(InterventionGeocodingEvent)event;
			view.setInterventionConfidence(confidenceEvent.getData(),confidenceEvent.getLevel());
			break;
		case MAP_AGENDA :
			// go back to agenda view
			view.setAgenda(interventions);
			break;
		default:
			break;
		}
	}
}
