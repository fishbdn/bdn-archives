

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.francetelecom.protosig.presentation.client.widget.map.GeoTranslator;

/**
 * test geo translator
 * 
 * @author VVZQ3324
 */
public class TestGeoTranslator {

	@Test
	public void testConvertLambert2eToWGS84() throws Exception {
		double[] lonlat = GeoTranslator.convertLambert2eToWGS84(1.0, 1.0);
		assertEquals(lonlat[0], -3.4046187244528077, 1E-14);
		assertEquals(lonlat[1], 27.14097023696693, 1E-14);
	}
	
	@Test
	public void testConvertWGS84ToLambert2e() throws Exception {
		double[] lonlat = GeoTranslator.convertWGS84ToLambert2e( 7,48 );
		assertEquals(lonlat[0], 947846.2438738535, 1E-14);
		assertEquals(lonlat[1], 2343733.602916683, 1E-14);
	}
}
