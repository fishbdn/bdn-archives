-- suppression tables obsoletes
DROP TABLE sig_pc;

-- table des PC 
CREATE TABLE `sig_pc_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `dr` varchar(4) NOT NULL,
  `crep` varchar(3) DEFAULT NULL,
  `czon` varchar(3) DEFAULT NULL,
  `reqam` varchar(15) DEFAULT NULL,
  `cnov` varchar(5) DEFAULT NULL,
  `lvoie` varchar(100) DEFAULT NULL,
  `lcommune` varchar(100) DEFAULT NULL,
  `x` double NOT NULL,
  `y` double NOT NULL,
  `orico` varchar(1) DEFAULT NULL,
  `sysco` varchar(4) DEFAULT NULL,
  `catpc` varchar(2) DEFAULT NULL,
  `cdtpc` varchar(100) DEFAULT NULL,
  `lcom` varchar(50) DEFAULT NULL,
  `pairs` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DR` (`dr`)
);

-- chargement de la table sig_pc_data a partir du fichier PC_HE_K2_fixed.csv
-- modifier le chemin du fichier
-- NB : pour avoir un nombre de colonnes constant, le fichier issue de la peri 
-- a été reformaté à l'aide de cette commande :
-- awk 'BEGIN { FS=";"}; { out=$1";"$2";"$3";"$4";"$5";"$6";"$7";"$8";"$9";"$10";"$11";"$12";"$13";"$14";"$15";\""$16; for (i=17;i <= NF; i++ ) { out = out":"$i}; out = out"\""; print out }' PC_HE_K2.csv  > PC_HE_K2_fixed.csv
LOAD DATA LOCAL INFILE 'd:/Profiles/jcWilk/Desktop/PROTOSIG/PC_HE_K2_fixed.csv' 
INTO TABLE sig_pc_data FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '"' lines terminated by '\n' 
(dr,name,crep,czon,reqam,cnov,lvoie,lcommune,x,y,orico,sysco,catpc,cdtpc,lcom,pairs);
