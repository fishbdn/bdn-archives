--
-- mise a jour base de données protoSIG sprint 1 -> sprint2
--

-- table correspondance code insee - code postal
CREATE  TABLE `sig_city` (
  `id` BIGINT NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(128) NOT NULL ,
  `dept` VARCHAR(45) NOT NULL ,
  `postal_code` VARCHAR(6) NOT NULL ,
  `insee_code` VARCHAR(6) NOT NULL ,
  PRIMARY KEY (`id`) );

-- table des PC
CREATE  TABLE `sig_pc` (
  `id` BIGINT NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `dr` VARCHAR(4) NOT NULL ,
  `ccom` VARCHAR(6) NULL ,
  `categ` VARCHAR(5) NULL ,
  `x` DOUBLE NOT NULL ,
  `y` DOUBLE NOT NULL ,
  PRIMARY KEY (`id`) );
  
-- chargement de la table sig_city a partir du fichier insee.csv
-- modifier le chemin du fichier
LOAD DATA LOCAL INFILE 'd:/Profiles/jcWilk/Desktop/PROTOSIG/insee.csv' INTO TABLE sig_city FIELDS TERMINATED BY ';' lines terminated by '\r\n' (name,postal_code,dept,insee_code);

-- chargement de la table sig_pc a partir du fichier pc.csv
-- modifier le chemin du fichier
LOAD DATA LOCAL INFILE 'd:/Profiles/jcWilk/Desktop/PROTOSIG/pc.csv' INTO TABLE sig_pc FIELDS TERMINATED BY ';' lines terminated by '\r\n' IGNORE 1 LINES (name,dr,ccom,categ,x,y);


