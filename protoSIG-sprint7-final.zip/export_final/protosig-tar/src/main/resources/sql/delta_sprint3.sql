-- suppression tables obsoletes
DROP TABLE poi;
DROP TABLE metadata;

-- ajout index sur table des pc
ALTER TABLE `sig_pc` 
ADD INDEX `IDX_DR` (`dr` ASC) ;

-- table des modifications de PC à envoyer à 42C
CREATE  TABLE `sig_pc_updates` (
  `id` VARCHAR(30) NOT NULL ,
  `codeident` VARCHAR(15) NOT NULL ,
  `update_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `level` VARCHAR(10) NULL ,
  `stair` VARCHAR(10) NULL ,
  `building_group` varchar(45) DEFAULT NULL,
  `building` VARCHAR(45) NULL ,
  `number` VARCHAR(10) NULL ,
  `street` VARCHAR(100) NULL ,
  `insee_code` VARCHAR(8) NULL ,
  `city_name` VARCHAR(100) NULL ,
  `comment` VARCHAR(1024) NULL ,
  `x` double DEFAULT NULL,
  `y` double DEFAULT NULL,    
  `level_old` VARCHAR(10) NULL ,
  `stair_old` VARCHAR(10) NULL ,
  `building_group_old` VARCHAR(45) NULL ,
  `building_old` VARCHAR(45) NULL ,
  `number_old` VARCHAR(10) NULL ,
  `street_old` VARCHAR(100) NULL ,
  `insee_code_old` VARCHAR(8) NULL ,
  `city_name_old` VARCHAR(100) NULL ,
  `comment_old` VARCHAR(1024) NULL ,
  `x_old` double DEFAULT NULL,
  `y_old` double DEFAULT NULL,    
  PRIMARY KEY (`id`) );

-- table des modifications de clients à envoyer à 42C  
CREATE  TABLE `sig_customer_updates` (
  `nd` varchar(20) NOT NULL,
  `codeident` varchar(15) NOT NULL,
  `client_name` varchar(100) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `door` varchar(10) DEFAULT NULL,
  `level` varchar(10) DEFAULT NULL,
  `stair` varchar(10) DEFAULT NULL,
  `building_group` varchar(45) DEFAULT NULL,
  `building` varchar(45) DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  `number_complement` varchar(100) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `insee_code` varchar(8) DEFAULT NULL,
  `city_name` varchar(100) DEFAULT NULL,
  `comment` varchar(1024) DEFAULT NULL,
  `door_old` varchar(10) DEFAULT NULL,
  `level_old` varchar(10) DEFAULT NULL,
  `stair_old` varchar(10) DEFAULT NULL,
  `building_group_old` varchar(45) DEFAULT NULL,
  `building_old` varchar(45) DEFAULT NULL,
  `number_old` varchar(10) DEFAULT NULL,
  `number_complement_old` varchar(100) DEFAULT NULL,
  `street_old` varchar(100) DEFAULT NULL,
  `insee_code_old` varchar(8) DEFAULT NULL,
  `city_name_old` varchar(100) DEFAULT NULL,
  `comment_old` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`nd`) );  