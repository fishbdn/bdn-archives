package com.francetelecom.protosig.bo.po;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This class defines an persistent object mapped to the sig_customer_updates table.
 * 
 * @author jcwilk
 * 
 */
@Entity
@Table(name = "sig_customer_updates")
public class CustomerUpdatePO {

	@Id
	private String nd;
	@Column(name="update_date", insertable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateDate;
	/**
	 * user name
	 */
	@Column
	private String codeIdent;
	@Column(name="client_name")
	private String clientName;

	@Column
	private String level;
	@Column
	private String stair;
	@Column
	private String building;
	@Column
	private String number;
	@Column
	private String street;
	@Column(name="insee_code")
	private String inseeCode;
	@Column(name="city_name")
	private String cityName;
	@Column
	private String comment;
	
	@Column
	private String door;
	@Column(name="building_group")
	private String group;
	@Column(name="number_complement")
	private String numberComplement;

	@Column(name="level_old")
	private String levelOld;
	@Column(name="stair_old")
	private String stairOld;
	@Column(name="building_old")
	private String buildingOld;
	@Column(name="number_old")
	private String numberOld;
	@Column(name="street_old")
	private String streetOld;
	@Column(name="insee_code_old")
	private String inseeCodeOld;
	@Column(name="city_name_old")
	private String cityNameOld;
	@Column(name="comment_old")
	private String commentOld;
	
	@Column(name="door_old")
	private String doorOld;
	@Column(name="building_group_old")
	private String groupOld;
	@Column(name="number_complement_old")
	private String numberComplementOld;

	public String getDoor() {
		return door;
	}
	public void setDoor(String door) {
		this.door = door;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getNumberComplement() {
		return numberComplement;
	}
	public void setNumberComplement(String numberComplement) {
		this.numberComplement = numberComplement;
	}
	public String getCodeIdent() {
		return codeIdent;
	}
	public void setCodeIdent(String codeIdent) {
		this.codeIdent = codeIdent;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getStair() {
		return stair;
	}
	public void setStair(String stair) {
		this.stair = stair;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getInseeCode() {
		return inseeCode;
	}
	public void setInseeCode(String inseeCode) {
		this.inseeCode = inseeCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getNd() {
		return nd;
	}
	public void setNd(String nd) {
		this.nd = nd;
	}
	public String getLevelOld() {
		return levelOld;
	}
	public void setLevelOld(String levelOld) {
		this.levelOld = levelOld;
	}
	public String getStairOld() {
		return stairOld;
	}
	public void setStairOld(String stairOld) {
		this.stairOld = stairOld;
	}
	public String getBuildingOld() {
		return buildingOld;
	}
	public void setBuildingOld(String buildingOld) {
		this.buildingOld = buildingOld;
	}
	public String getNumberOld() {
		return numberOld;
	}
	public void setNumberOld(String numberOld) {
		this.numberOld = numberOld;
	}
	public String getStreetOld() {
		return streetOld;
	}
	public void setStreetOld(String streetOld) {
		this.streetOld = streetOld;
	}
	public String getInseeCodeOld() {
		return inseeCodeOld;
	}
	public void setInseeCodeOld(String inseeCodeOld) {
		this.inseeCodeOld = inseeCodeOld;
	}
	public String getCityNameOld() {
		return cityNameOld;
	}
	public void setCityNameOld(String cityNameOld) {
		this.cityNameOld = cityNameOld;
	}
	public String getCommentOld() {
		return commentOld;
	}
	public void setCommentOld(String commentOld) {
		this.commentOld = commentOld;
	}
	public String getDoorOld() {
		return doorOld;
	}
	public void setDoorOld(String doorOld) {
		this.doorOld = doorOld;
	}
	public String getGroupOld() {
		return groupOld;
	}
	public void setGroupOld(String groupOld) {
		this.groupOld = groupOld;
	}
	public String getNumberComplementOld() {
		return numberComplementOld;
	}
	public void setNumberComplementOld(String numberComplementOld) {
		this.numberComplementOld = numberComplementOld;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	
}
