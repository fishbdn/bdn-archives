package com.francetelecom.protosig.bo.po;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class defines an persistent object mapped to the sig_pc table.
 * 
 * @author jcwilk
 * 
 */
@Entity
@Table(name = "sig_pc_data")
@NamedQuery(name = "closest", query = "select p from PcPO p where p.dr=:dr and p.x != 0 order by pow(p.x-:x,2)+pow(p.y-:y,2)")
public class PcPO {

	/**
	 * id with generated value
	 */
	@Id
	private Long id;

	/**
	 * PC name
	 */
	@Column
	private String name;
	/**
	 * DR
	 */
	@Column
	private String dr;
	/**
	 * Centre code
	 */
	@Column(name="crep")
	private String centreCode;
	/**
	 * Zone code
	 */
	@Column(name="czon")
	private String zoneCode;
	/**
	 * street number
	 */
	@Column(name="cnov")
	private String number;
	/**
	 * street name
	 */
	@Column(name="lvoie")
	private String street;
	/**
	 * city name
	 */
	@Column(name="lcommune")
	private String city;
	/**
	 * x coordinate
	 */
	@Column
	private Double x;
	/**
	 * y coordinate
	 */
	@Column
	private Double y;
	/**
	 * category
	 */
	@Column(name="catpc")
	private String category;
	/**
	 * commnet
	 */
	@Column(name="lcom")
	private String comment;

	/**
	 * technical description
	 */
	@Column(name="cdtpc")
	private String descTech;
	
	/**
	 * List of ':' separated pairs
	 */
	@Column(name="pairs")
	private String pairs;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDr() {
		return dr;
	}

	public void setDr(String dr) {
		this.dr = dr;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getX() {
		return x;
	}

	public void setX(Double x) {
		this.x = x;
	}

	public Double getY() {
		return y;
	}

	public void setY(Double y) {
		this.y = y;
	}

	public String getCentreCode() {
		return centreCode;
	}

	public void setCentreCode(String centreCode) {
		this.centreCode = centreCode;
	}

	public String getZoneCode() {
		return zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPairs() {
		return pairs;
	}

	public void setPairs(String pairs) {
		this.pairs = pairs;
	}

	public String getDescTech() {
		return descTech;
	}

	public void setDescTech(String descTech) {
		this.descTech = descTech;
	}

}
