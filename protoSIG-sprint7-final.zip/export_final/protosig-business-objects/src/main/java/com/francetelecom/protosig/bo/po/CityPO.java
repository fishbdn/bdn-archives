package com.francetelecom.protosig.bo.po;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * This class defines an persistent object mapped to the sig_city table.
 * 
 * @author jcwilk
 * 
 */
@Entity
@Table(name = "sig_city")
@NamedQuery(name = "inseeToPostal", query = "select postalCode from CityPO c where c.inseeCode=:inseeCode")
public class CityPO {

	/**
	 * id with generated value
	 */
	@Id
	private Long id;

	/**
	 * City name
	 */
	@Column
	private String name;
	/**
	 * City postal code
	 */
	@Column(name="postal_code")
	private String postalCode;
	/**
	 * City department name
	 */
	@Column
	private String dept;
	/**
	 * City insee code
	 */
	@Column(name="insee_code")
	private String inseeCode;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getInseeCode() {
		return inseeCode;
	}

	public void setInseeCode(String inseeCode) {
		this.inseeCode = inseeCode;
	}

}
