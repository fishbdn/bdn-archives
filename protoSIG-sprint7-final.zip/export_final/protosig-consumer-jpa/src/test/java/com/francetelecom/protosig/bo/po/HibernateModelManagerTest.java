/**
 * 
 */
package com.francetelecom.protosig.bo.po;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.dao.InitSpringContextTests;

/**
 * @author mlaffargue
 * 
 */

@Transactional
public class HibernateModelManagerTest extends InitSpringContextTests {
	// private static final String CUID = "cuidTU";

	@PersistenceContext
	private EntityManager em;

	// private static final ON2PO ON2A = new ON2PO("on2a", "on2a", "on2a");
	// private static final ON1PO ON1AA = new ON1PO("on1aa", "on1aa", "on1aa",
	// ON2A);
	// private static final ON1PO ON1AB = new ON1PO("on1ab", "on1ab", "on1ab",
	// ON2A);
	// private static final DepartmentPO DPT31 = new DepartmentPO("31tu",
	// "Haute-Garonne");
	// private static final SiretPO SIRETA = new SiretPO("sireta", "libelle",
	// "6", "voie", "cmpl", "3", "", "31000",
	// "Toulouse", DPT31);
	//
	// // Create the manager
	// private ManagerPO manager;
	// private Query q;
	//
	// /**
	// * Set some ref table values
	// */
	// @Before
	// public void setupRefTable() {
	// em.persist(ON2A);
	// em.persist(ON1AA);
	// em.persist(ON1AB);
	// em.persist(DPT31);
	// em.persist(SIRETA);
	// manager = new ManagerPO(CUID, new Date(), null, null);
	// em.persist(manager);
	// }
	//
	// /**
	// * - Create a manager
	// *
	// * - Link it to an ON1
	// *
	// * - Remove the ON1 from the Manager
	// *
	// * - Check ON1 still exists, check manager_on1 link deleted
	// */
	// @Test
	// public void removeGestionnaireOn1link() {
	// // Link it to an ON1
	// Set<ON1PO> on1s = new HashSet<ON1PO>(1);
	// on1s.add(ON1AA);
	// manager.setOn1s(on1s);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on1 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	//
	// manager.getOn1s().remove(ON1AA);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check linked object removed
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on1 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	//
	// // Check ON1 still exists
	// assertNotNull(em.find(ON1PO.class, ON1AA.getCodeOn1()));
	// }
	//
	// /**
	// * - Create a manager
	// *
	// * - Link it to an ON2
	// *
	// * - Remove the ON2 from the Manager
	// *
	// * - Check ON2 still exists, check manager_on2 link deleted
	// */
	// @Test
	// public void removeGestionnaireOn2link() {
	// // Link it to an ON2
	// Set<ON2PO> on2s = new HashSet<ON2PO>(1);
	// on2s.add(ON2A);
	// manager.setOn2s(on2s);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on2 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	//
	// manager.getOn2s().remove(ON2A);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check linked object removed
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on2 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	//
	// // Check ON2 still exists
	// assertNotNull(em.find(ON2PO.class, ON2A.getCodeOn2()));
	// }
	//
	// /**
	// * - Create a manager
	// *
	// * - Link it to an Siret
	// *
	// * - Remove the Siret from the Manager
	// *
	// * - Check Siret still exists, check manager_siret link deleted
	// */
	// @Test
	// public void removeGestionnaireSiretlink() {
	// // Link it to an Siret
	// Set<SiretPO> sirets = new HashSet<SiretPO>(1);
	// sirets.add(SIRETA);
	// manager.setSirets(sirets);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_siret WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	//
	// manager.getSirets().remove(SIRETA);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check linked object removed
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_siret WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	//
	// // Check Siret still exists
	// assertNotNull(em.find(SiretPO.class, SIRETA.getCodeSiret()));
	// }
	//
	// /**
	// * - Create a manager
	// *
	// * - Link it to an Department
	// *
	// * - Remove the Department from the Manager
	// *
	// * - Check Department still exists, check manager_siret link deleted
	// */
	// @Test
	// public void removeGestionnaireDepartmentlink() {
	// // Link it to a Departement
	// Set<DepartmentPO> dpts = new HashSet<DepartmentPO>(1);
	// dpts.add(DPT31);
	// manager.setDepartements(dpts);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_departement WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	//
	// manager.getDepartements().remove(DPT31);
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check linked object removed
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_departement WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	//
	// // Check Departement still exists
	// assertNotNull(em.find(DepartmentPO.class, DPT31.getCodeDepartement()));
	// }
	//
	// /**
	// * Create a manager, add some perimeters, delete the manager.
	// *
	// * The links to ON1/ON2/SIRET/DEPARTMENT should be deleted
	// */
	// @Test
	// public void removeManager() {
	// // Link it to an Departement
	// Set<DepartmentPO> dpts = new HashSet<DepartmentPO>(1);
	// dpts.add(DPT31);
	// manager.setDepartements(dpts);
	// // Link it to an Siret
	// Set<SiretPO> sirets = new HashSet<SiretPO>(1);
	// sirets.add(SIRETA);
	// // Link it to an ON2
	// Set<ON2PO> on2s = new HashSet<ON2PO>(1);
	// on2s.add(ON2A);
	// manager.setOn2s(on2s);
	// // Link it to an ON1
	// Set<ON1PO> on1s = new HashSet<ON1PO>(1);
	// on1s.add(ON1AA);
	//
	// manager.setOn1s(on1s);
	// manager.setOn2s(on2s);
	// manager.setSirets(sirets);
	// manager.setDepartements(dpts);
	//
	// // Persist
	// manager = em.merge(manager);
	// em.flush();
	//
	// em.clear();
	//
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on1 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_departement WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	// // Check linked object removed
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_siret WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	// // Check persist cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on2 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(1, q.getResultList().size());
	//
	// ManagerPO managerPo = em.find(ManagerPO.class, manager.getCuid());
	// // Delete the manager
	// em.remove(managerPo);
	// em.flush();
	//
	// em.clear();
	// assertNull(em.find(ManagerPO.class, manager.getCuid()));
	//
	// // Check delete cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on1 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	// // Check delete cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_departement WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	// // Check linked object removed
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_siret WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	// // Check delete cascade ok
	// q =
	// em.createNativeQuery("SELECT * FROM gestionnaire_on2 WHERE cuid=:cuid");
	// q.setParameter("cuid", CUID);
	// assertEquals(0, q.getResultList().size());
	//
	// }
}
