/**
 * 
 */
package com.francetelecom.protosig.bo.po;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

import com.francetelecom.protosig.dao.InitSpringContextTests;

/**
 * This class is used to test the Hibernate model (Cascading ...)
 * 
 * @author mlaffargue
 * 
 */

@Transactional
public class HibernateModelActorTest extends InitSpringContextTests {
	// private static final String CODE_MISSION = "cod";

	// private static final String CUID = "cuidTU";

	@PersistenceContext
	private EntityManager em;

	// private static final ON2PO ON2A = new ON2PO("on2a", "on2a", "on2a");
	// private static final ON1PO ON1AA = new ON1PO("on1aa", "on1aa", "on1aa",
	// ON2A);
	// private static final ON1PO ON1AB = new ON1PO("on1ab", "on1ab", "on1ab",
	// ON2A);
	// private static final DepartmentPO DPT31 = new DepartmentPO("31test",
	// "Haute-Garonne");
	// private static final SiretPO SIRETA = new SiretPO("sireta", "libelle",
	// "6", "voie", "cmpl", "3", "", "31000",
	// "Toulouse", DPT31);
	//
	// private PointOfInterestPO actor;
	// private MissionPO mission;
	// private ElementPerimeterPO elementPerimeterA;
	// private ElementPerimeterPO elementPerimeterB;
	// private Set<ElementPerimeterPO> elements;
	// private Query q;
	//
	// /**
	// * Set some ref table values
	// */
	// @Before
	// public void setupRefTable() {
	// actor = new PointOfInterestPO(CUID, null, null, null);
	// mission = new MissionPO(CODE_MISSION, "libelle", false);
	// elements = new HashSet<ElementPerimeterPO>();
	// elementPerimeterA = new ElementPerimeterPO(ON1AA, null, null, null);
	// elementPerimeterB = new ElementPerimeterPO(ON1AB, null, SIRETA, null);
	// elements.add(elementPerimeterA);
	// elements.add(elementPerimeterB);
	//
	// em.persist(ON2A);
	// em.persist(ON1AA);
	// em.persist(ON1AB);
	// em.persist(DPT31);
	// em.persist(SIRETA);
	// em.persist(mission);
	//
	// em.persist(actor);
	// }
	//
	// @Test
	// public void addMission() {
	// // Add a mission to the actor on the perimeter
	// actor.addMission(mission, elements);
	//
	// em.persist(actor);
	// em.flush();
	//
	// em.clear();
	//
	// // Retrieve actor from DB
	// PointOfInterestPO actor2 = em.find(PointOfInterestPO.class,
	// actor.getCuid());
	// assertEquals(1, actor2.getGivenMissions().size());
	//
	// GivenMissionPO mission = actor2.getGivenMissions().iterator().next();
	// assertEquals(elements.size(),
	// actor2.getMissionElementsPerimeter(mission.getMission()).size());
	// }
	//
	// @Test
	// public void removeElementPerimeterForAMission() {
	// actor.addMission(mission, elements);
	//
	// em.persist(actor);
	// em.flush();
	// // Remove an element for a mission
	// actor.removeElementPerimeterFrom(mission, elementPerimeterA);
	// em.persist(actor);
	// em.flush();
	//
	// em.clear();
	//
	// // Check DB if the Element is removed
	// TypedQuery<ElementPerimeterPO> q = em.createQuery(
	// "FROM ElementPerimeterPO WHERE givenMissionPO=:givenMissionPO",
	// ElementPerimeterPO.class);
	// q.setParameter("givenMissionPO", actor.getGivenMission(mission));
	// assertEquals(1, q.getResultList().size());
	// assertEquals(elementPerimeterB.getCodeElementPerimetre(),
	// q.getResultList().get(0).getCodeElementPerimetre());
	//
	// // Check DB if the given mission is still here
	// TypedQuery<GivenMissionPO> tq2 =
	// em.createQuery("FROM GivenMissionPO WHERE givenMissionId=:givenMissionId",
	// GivenMissionPO.class);
	// tq2.setParameter("givenMissionId",
	// actor.getGivenMission(mission).getGivenMissionId());
	// assertEquals(1, tq2.getResultList().size());
	// }
	//
	// @Test
	// public void removeAllElementPerimeterForAMission() {
	// actor.addMission(mission, elements);
	// em.persist(actor);
	// em.flush();
	//
	// GivenMissionPO givenMission = actor.getGivenMission(mission);
	// Long id = givenMission.getGivenMissionId(); // Id is generated on persist
	//
	// // Remove an element for a mission
	// actor.removeElementPerimeterFrom(mission, elementPerimeterA);
	// actor.removeElementPerimeterFrom(mission, elementPerimeterB);
	// em.persist(actor);
	// em.flush();
	//
	// em.clear();
	//
	// // Check DB if the Element are removed
	// TypedQuery<ElementPerimeterPO> tq1 = em.createQuery(
	// "FROM ElementPerimeterPO WHERE givenMissionPO=:givenMissionPO",
	// ElementPerimeterPO.class);
	// tq1.setParameter("givenMissionPO", givenMission);
	// assertEquals(0, tq1.getResultList().size());
	//
	// // Check DB if the given mission is removed
	// TypedQuery<GivenMissionPO> tq2 =
	// em.createQuery("FROM GivenMissionPO WHERE givenMissionId=:givenMissionId",
	// GivenMissionPO.class);
	// tq2.setParameter("givenMissionId", id);
	// assertEquals(0, tq2.getResultList().size());
	//
	// }
	//
	// @Test
	// public void removeMission() {
	// actor.addMission(mission, elements);
	// em.persist(actor);
	// em.flush();
	// // Remove an element for a mission
	// actor.removeMission(mission);
	// em.persist(actor);
	// em.flush();
	//
	// em.clear();
	//
	// // Check DB if the given mission is removed
	// TypedQuery<GivenMissionPO> tq1 =
	// em.createQuery("FROM GivenMissionPO WHERE givenMissionId=:givenMissionId",
	// GivenMissionPO.class);
	// tq1.setParameter("givenMissionId", actor.getGivenMission(mission));
	// assertEquals(0, tq1.getResultList().size());
	//
	// // Check DB if the Elements are removed
	// TypedQuery<ElementPerimeterPO> tq2 = em.createQuery(
	// "FROM ElementPerimeterPO WHERE givenMissionPO=:givenMissionPO",
	// ElementPerimeterPO.class);
	// tq2.setParameter("givenMissionPO", actor.getGivenMission(mission));
	// assertEquals(0, tq2.getResultList().size());
	// }
}
