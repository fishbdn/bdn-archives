/**
 * 
 */
package com.francetelecom.protosig.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.francetelecom.protosig.bo.po.CityPO;
import com.francetelecom.protosig.dao.CityDaoJpa;

/**
 * @author jcwilk
 * 
 */
@Repository("cityDaoJpa")
public class CityDaoJpaImpl extends
		GenericDaoJpaImpl<CityPO, Long> implements CityDaoJpa {

	/**
	 * @see com.francetelecom.protosig.dao.CityDaoJpa#getPostalCodeFromInseeCode(java.lang.String)
	 */
	@Override
	public String getPostalCodeFromInseeCode(String inseeCode) {
		TypedQuery<String> query = getEntityManager().createNamedQuery(
				"inseeToPostal", String.class);
		// convert to integer to remove potential leading 0
		query.setParameter("inseeCode", String.valueOf(Integer.parseInt(inseeCode)));
		query.setMaxResults(1);

		String result=null;
		try {
			result=query.getSingleResult();
		} catch (NoResultException e) {
			// do nothing. return null
		}
		return result;
	}
}
