/**
 * 
 */
package com.francetelecom.protosig.dao;

/**
 * @author mlaffargue
 * 
 */
public final class DatabaseUtil {
	public static final String DATABASE_WILDCARD = "%";

	/**
	 * Private constructor.
	 */
	private DatabaseUtil() {
	};
}
