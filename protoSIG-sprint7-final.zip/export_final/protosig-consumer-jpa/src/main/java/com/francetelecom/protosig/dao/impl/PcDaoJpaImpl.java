/**
 * 
 */
package com.francetelecom.protosig.dao.impl;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.francetelecom.protosig.bo.po.PcPO;
import com.francetelecom.protosig.dao.PcDaoJpa;

/**
 * @author jcwilk
 * 
 */
@Repository("pcDaoJpa")
public class PcDaoJpaImpl extends
		GenericDaoJpaImpl<PcPO, Long> implements PcDaoJpa {

	/**
	 * @see com.francetelecom.protosig.dao.PcDaoJpa#getClosest(java.lang.String, java.lang.Double, java.lang.Double, int)
	 */
	@Override
	public List<PcPO> getClosest(String dr, Double x, Double y, int number) {
		TypedQuery<PcPO> query=getEntityManager().createNamedQuery("closest",PcPO.class);
		query.setParameter("dr", dr);
		query.setParameter("x", x);
		query.setParameter("y", y);
		query.setMaxResults(number);
		return query.getResultList();
	}
}
