/**
 * 
 */
package com.francetelecom.protosig.dao;

import com.francetelecom.protosig.bo.po.CustomerUpdatePO;

/**
 * @author jcwilk
 * 
 */
public interface CustomerUpdateDaoJpa extends
		GenericDaoJpa<CustomerUpdatePO, String> {
	
	/**
	 * Delete all data from the table
	 */
	void clear();
}
