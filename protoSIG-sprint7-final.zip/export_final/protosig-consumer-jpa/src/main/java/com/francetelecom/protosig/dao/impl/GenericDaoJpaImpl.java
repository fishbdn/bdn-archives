package com.francetelecom.protosig.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.francetelecom.protosig.dao.GenericDaoJpa;

/**
 * Generic DAO JPA implementation. An EntityManager is injected by Spring container. A transaction should be started by
 * container before calling these DAO services.
 * 
 * @author Clara
 * @param <T>
 *            Table
 * @param <P>
 *            Primary Key
 */
@Repository("genericDaoJpa")
public abstract class GenericDaoJpaImpl<T, P> implements GenericDaoJpa<T, P> {

	private Class<T> type = null;

	@PersistenceContext
	private EntityManager em;

	/**
	 * Empty constructor. The real type T is found with generic reflection
	 */
	protected GenericDaoJpaImpl() {
		this.type = this.getParameterizedType(this.getClass());
	}

	/**
	 * Generic reflection. Find and set generic type used
	 */
	@SuppressWarnings("unchecked")
	private Class<T> getParameterizedType(Class<?> clazz) {
		Class<T> specificType = null;
		ParameterizedType parameterizedType = (ParameterizedType) clazz.getGenericSuperclass();
		specificType = (Class<T>) parameterizedType.getActualTypeArguments()[0];
		return specificType;
	}

	@Override
	public void flush() {
		em.flush();
	}

	@Override
	public void persist(T o) {
		em.persist(o);
	}

	@Override
	public void remove(T o) {
		em.remove(o);
	}

	@Override
	public void refresh(T o) {
		em.refresh(o);
	}
	
	@Override
	public void merge(T o) {
		em.merge(o);
	}

	@Override
	public T find(P primaryKey) {
		return em.find(type, primaryKey);
	}

	@Override
	public T getReference(P primaryKey) {
		return em.getReference(type, primaryKey);
	}

	@Override
	public List<T> findAll() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<T> query = cb.createQuery(type);
		Root<T> root = query.from(type);
		query.select(root);
		TypedQuery<T> tq = em.createQuery(query);

		return tq.getResultList();
	}
	
	@Override
	public List<T> findAll(String orderBy, boolean asc) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<T> query = cb.createQuery(type);
		Root<T> root = query.from(type);
		query.select(root);
		if (asc) {
			query.orderBy(cb.asc(root.get(orderBy)));
		} else {
			query.orderBy(cb.desc(root.get(orderBy)));
		}
		
		TypedQuery<T> tq = em.createQuery(query);

		return tq.getResultList();
	}
	
	@Override
	public List<T> findWhereIsNull(String where) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<T> query = cb.createQuery(type);
		Root<T> root = query.from(type);
		
		query.select(root);		
		query.where(root.get(where).isNull());
		
		TypedQuery<T> tq = em.createQuery(query);

		return tq.getResultList();
	}
	
	

	/**
	 * Getter for extending classes
	 * 
	 * @return the Entity Manager
	 */
	protected EntityManager getEntityManager() {
		return em;
	}

}
