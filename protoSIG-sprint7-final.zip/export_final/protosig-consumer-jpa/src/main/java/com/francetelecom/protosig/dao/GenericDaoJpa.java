package com.francetelecom.protosig.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

/**
 * Generic interface for a JPA persistence service
 * <p>
 * All exceptions are RuntimeException (@see
 * org.springframework.dao.DataAccessException)
 * 
 * @author France Telecom - Clara
 * 
 * @param <T,PK>
 *            Table and primary key
 */
public interface GenericDaoJpa<T, PK> {

	/**
	 * Synchronise entityManager objects in database
	 * 
	 * @throws DataAccessException
	 */
	void flush();

	/**
	 * Refresh persistent object
	 * 
	 * @param o
	 * @throws DataAccessException
	 */
	void refresh(T o);

	/**
	 * persist an object in database
	 * 
	 * @param o
	 *            the persistent object to be persisted
	 * @throws DataAccessException
	 */
	void persist(T o);

	/**
	 * Remove an object from database
	 * 
	 * @param o
	 *            the persistent object to be removed
	 * @throws DataAccessException
	 */
	void remove(T o);
	
	
	/** Merge an object from database
	 * @param o
	 */
	void merge (T o);

	/**
	 * load a persistent object with specified id, return null if it does not
	 * exist
	 * 
	 * @param id
	 *            the persistent object id
	 * @return T the persistent object found in database
	 * @throws DataAccessException
	 */
	T find(PK id);

	/**
	 * load a persistent object with specified id, throw an exception if it does
	 * not exist
	 * 
	 * @param id
	 *            the persistent object id
	 * @return T the persistent object found in database
	 * @throws DataAccessException
	 */
	T getReference(PK id);

	/**
	 * load all persistent objects specified by DAO component
	 * 
	 * @return List list of persistent objects
	 * @throws DataAccessException
	 */
	List<T> findAll();

	/**
	 * load all persistent objects specified by DAO component and order by given parameters
	 * 
	 * @param orderBy the column to order by
	 * @param asc should the order by be ascendant.
	 * @return List list of persistent objects
	 * @throws DataAccessException
	 */
	List<T> findAll(String orderBy, boolean asc);
	
	/**
	 * load all persistent objects specified by DAO component and the column is null
	 * 
	 * @param where the column to search by
	 * @return List list of persistent objects
	 * @throws DataAccessException
	 */
	List<T> findWhereIsNull(String where);

}
