/**
 * 
 */
package com.francetelecom.protosig.dao;

import com.francetelecom.protosig.bo.po.PcUpdatePO;

/**
 * @author jcwilk
 * 
 */
public interface PcUpdateDaoJpa extends
		GenericDaoJpa<PcUpdatePO, String> {
	/**
	 * Delete all data from the table
	 */
	void clear();
}
