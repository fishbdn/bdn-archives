/**
 * 
 */
package com.francetelecom.protosig.dao.impl;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.francetelecom.protosig.bo.po.CustomerUpdatePO;
import com.francetelecom.protosig.dao.CustomerUpdateDaoJpa;

/**
 * @author jcwilk
 * 
 */
@Repository("customerUpdateDaoJpa")
public class CustomerUpdateDaoJpaImpl extends
		GenericDaoJpaImpl<CustomerUpdatePO, String> implements CustomerUpdateDaoJpa {
	private static final String CLEAR_QUERY="truncate table sig_customer_updates";
	@Override
	public void clear() {
		Query query=getEntityManager().createNativeQuery(CLEAR_QUERY);
		query.executeUpdate();		
	}
}
