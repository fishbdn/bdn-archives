/**
 * 
 */
package com.francetelecom.protosig.dao;

import com.francetelecom.protosig.bo.po.CityPO;

/**
 * @author jcwilk
 * 
 */
public interface CityDaoJpa extends
		GenericDaoJpa<CityPO, Long> {
	/**
	 * Convert insee code into postal code
	 * @param inseeCode
	 * @return the postal code or null if not found
	 */
	String getPostalCodeFromInseeCode(String inseeCode);
}
