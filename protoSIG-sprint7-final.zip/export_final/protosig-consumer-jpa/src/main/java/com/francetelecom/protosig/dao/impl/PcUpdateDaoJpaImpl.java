/**
 * 
 */
package com.francetelecom.protosig.dao.impl;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.francetelecom.protosig.bo.po.PcUpdatePO;
import com.francetelecom.protosig.dao.PcUpdateDaoJpa;

/**
 * @author jcwilk
 * 
 */
@Repository("pcUpdateDaoJpa")
public class PcUpdateDaoJpaImpl extends
		GenericDaoJpaImpl<PcUpdatePO, String> implements PcUpdateDaoJpa {
	private static final String CLEAR_QUERY="truncate table sig_pc_updates";
	
	@Override
	public void clear() {
		Query query=getEntityManager().createNativeQuery(CLEAR_QUERY);
		query.executeUpdate();		
	}

}
