/**
 * 
 */
package com.francetelecom.protosig.dao;

import java.util.List;

import com.francetelecom.protosig.bo.po.PcPO;

/**
 * @author jcwilk
 * 
 */
public interface PcDaoJpa extends
		GenericDaoJpa<PcPO, Long> {
	/**
	 * Retrieve the closest PC from given coordinates
	 * @param dr search only pc for this dr
	 * @param x,y search pc close to position x,y
	 * @param number return number closest results
	 * @return the list of PC
	 */
	List<PcPO> getClosest(String dr, Double x, Double y, int number);
}
